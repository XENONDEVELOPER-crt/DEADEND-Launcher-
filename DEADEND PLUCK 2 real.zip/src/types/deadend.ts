/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type AppCategory = 'essential' | 'intercepted' | 'utility' | 'system';

export interface AppItem {
  id: string;
  name: string;
  packageName: string;
  category: AppCategory;
  isPinned: boolean;
  isHidden: boolean;
  customLabel?: string;
  dailyBudgetMinutes: number; // e.g. 15 for high friction apps
  timeUsedTodaySeconds: number;
  openCountToday: number;
  lastOpenedAt?: number;
  isEmergencyAllowed: boolean; // Allowed during Deadlock (Phone, SMS)
  description?: string;
  hasPersistentFrictionToday?: boolean; // If opened once, subsequent launches require 5s pause
}

export type FrictionChallenge = 'none' | 'quote' | 'math';

export interface FrictionConfig {
  breathingDurationSeconds: number; // 10, 15, 20, 30
  requireIntentText: boolean;
  frictionChallenge: FrictionChallenge;
  dailyHighFrictionLimitMinutes: number;
  strictLockoutOnExpiry: boolean;
  soundEnabled: boolean;
  hapticEnabled: boolean;
  quickIntents: string[];
}

export interface DeadlockState {
  isActive: boolean;
  startedAt: number | null;
  endsAt: number | null;
  durationMinutes: number;
  reason: string;
}

export interface UsageLogEntry {
  id: string;
  timestamp: number;
  appId: string;
  appName: string;
  packageName: string;
  type: 'intercepted_aborted' | 'session_started' | 'session_completed' | 'deadlock_entered' | 'deadlock_disarmed' | 'budget_exceeded' | 'limit_unlock_queued';
  declaredIntent?: string;
  allocatedMinutes?: number;
  actualDurationSeconds?: number;
  timeSavedSeconds?: number;
}

export interface DayStats {
  date: string; // YYYY-MM-DD
  pickupsCount: number;
  interceptionsAborted: number;
  interceptionsProceeded: number;
  totalScreenTimeSeconds: number;
  distractingTimeSeconds: number;
  timeSavedSeconds: number;
  logs: UsageLogEntry[];
}

export interface ActiveSession {
  app: AppItem;
  declaredIntent: string;
  allocatedMinutes: number;
  remainingSeconds: number;
  startedAt: number;
  isExpired: boolean;
}

export type ThemeStyle = 'oled_pure' | 'slate_minimal' | 'warm_paper' | 'forest_night';

// OEM & Navigation System Types
export type OEMManufacturer = 'google' | 'samsung' | 'xiaomi' | 'oppo' | 'oneplus' | 'other';
export type NavigationMode = 'three_button' | 'two_button' | 'gestural';

export interface SystemHealthState {
  isRoleHomeHeld: boolean;
  isAccessibilityGranted: boolean;
  isNotificationListenerGranted: boolean;
  isUsageStatsGranted: boolean;
  isBatteryOptimizationIgnored: boolean;
  isKeepAliveForegroundActive: boolean;
  detectedManufacturer: OEMManufacturer;
  navigationMode: NavigationMode;
  oemGestureWarningDismissed: boolean;
  roleHomeBannerDismissed: boolean;
}

// Notification Batching & Scheduled Digest
export interface BatchNotification {
  id: string;
  appName: string;
  packageName: string;
  title: string;
  body: string;
  timestamp: number;
  isPriority: boolean;
  category: 'message' | 'social' | 'promo' | 'system';
}

export interface DigestConfig {
  enabled: boolean;
  scheduledTimes: string[]; // e.g. ["12:00", "18:00"]
  whitelistPackages: string[]; // Phone, SMS, Calendar, Alarms
  batchedNotifications: BatchNotification[];
  lastDeliveredAt: number | null;
}

// 15-Minute Anti-Self-Sabotage Limit Unlock
export interface PendingLimitUnlock {
  appId: string;
  appName: string;
  requestedAt: number;
  unlocksAt: number; // 15 minutes after request
  newBudgetMinutes: number;
  actionType: 'increase_budget' | 'remove_friction';
}

// Monetization & Supporter Aesthetics (Core friction remains 100% free)
export type CustomFontFamily = 'jetbrains_mono' | 'space_grotesk' | 'ibm_plex' | 'serif';
export type AccentShade = 'pure_white' | 'amber_sand' | 'tokyo_slate' | 'cyber_cyan' | 'forest_emerald';

export interface SupporterAesthetics {
  isUnlocked: boolean;
  selectedFont: CustomFontFamily;
  selectedAccent: AccentShade;
}

// Permission Onboarding Just-In-Time Rationale
export interface PermissionRationale {
  permissionKey: keyof SystemHealthState;
  title: string;
  subtitle: string;
  rationale: string;
  privacyGuarantee: string;
  actionLabel: string;
}
