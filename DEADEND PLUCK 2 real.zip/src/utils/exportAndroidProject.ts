/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import JSZip from 'jszip';
import { ANDROID_FILES } from '../data/androidSpec';

export const generateAndroidProjectZip = async (): Promise<Blob> => {
  const zip = new JSZip();

  // Add all Android files into zip archive
  for (const file of ANDROID_FILES) {
    zip.file(file.path, file.content);
  }

  // Add a comprehensive setup and home launcher guide
  const readmeContent = `# DEADEND - Minimalist Launcher & Friction Interceptor
Android Studio Project & Home Launcher Setup Guide

## 1. Quick Build & Installation

### Option A: Via Android Studio (Recommended)
1. Unzip this package.
2. Open **Android Studio** (Ladybug / Iguana or later).
3. Select **File -> Open...** and choose this extracted root directory.
4. Allow Gradle Sync to complete (JDK 17+, Android SDK 35).
5. Connect your Android phone via USB with **USB Debugging** enabled.
6. Click the green **Run (Shift+F10)** button to install on your device.

### Option B: Via Command Line (Gradle & ADB)
\`\`\`bash
# Build the Debug APK
./gradlew assembleDebug

# Install to your connected phone
adb install -r app/build/outputs/apk/debug/app-debug.apk
\`\`\`

---

## 2. Setting DEADEND as Your Default Home Launcher

Once installed on your phone:

### Method 1: In Android Settings (UI)
1. Open your phone's **Settings**.
2. Navigate to **Apps** (or **Application Management**).
3. Tap **Default Apps** (usually in advanced or three dots menu).
4. Tap **Home app** (or **Default Launcher**).
5. Select **DEADEND**.
6. Press your phone's Home button or swipe up from the bottom — DEADEND is now your operating system interface!

### Method 2: Via ADB Command (Instant)
\`\`\`bash
adb shell cmd package set-home-activity io.deadend.launcher/.ui.HomeScreen
\`\`\`

---

## 3. Granting Essential Anti-Distraction Permissions

For the **Non-Skippable Breathing Gate** and **Deadlock Mode** to intercept distracting apps before they open:

1. **Display Over Other Apps (Overlay)**:
   - Settings -> Apps -> Special App Access -> Display over other apps -> **DEADEND -> Allow**
2. **Usage Access (Detect App Launches)**:
   - Settings -> Apps -> Special App Access -> Usage Access -> **DEADEND -> Allow**
3. **Accessibility Service (Real-Time Interceptor)**:
   - Settings -> Accessibility -> Downloaded Services -> **DEADEND Interceptor -> Turn On**
4. **Device Admin (Deadlock Emergency Lockdown)**:
   - Prompted automatically in the app when you arm Deadlock for the first time.

---

## 4. ESP32 "DEADEND_PUCK" BLE Hardware Desk Node Integration

DEADEND includes native hardware integration with an external ESP32 Bluetooth Low Energy desk node:
- **Advertised Device Name**: \`DEADEND_PUCK\`
- **BLE Service UUID**: \`4fafc201-1fb5-459e-8fcc-c5c9c331914b\`
- **BLE Characteristic UUID**: \`beb5483e-36e1-4688-b7f5-ea07361b26a8\`
- **Client Characteristic Config Descriptor (CCCD)**: \`00002902-0000-1000-8000-00805f9b34fb\`
- **Expected Trigger Payload**: \`TOGGLE_FOCUS\`
- **Scan Settings**: Starts with \`SCAN_MODE_LOW_LATENCY\` when searching, and drops to \`SCAN_MODE_LOW_POWER\` once paired.
- **Haptic Feedback**: Fires a 100ms tactile vibration upon receiving \`TOGGLE_FOCUS\`.

When you physically tap your RFID/NFC focus puck on The Monolith desk node, it transmits \`TOGGLE_FOCUS\` over BLE. \`FocusNodeBleService\` catches the notification, executes \`repository.toggleDeadlockMode()\`, vibrates the phone for 100ms, and locks down your phone into deep work mode while keeping emergency Phone and SMS calls accessible.

### Automatic Disarm on Bluetooth Disconnect:
When the Bluetooth connection drops (e.g. you walk away from your desk out of BLE range, turn off Bluetooth, or power down the ESP32 node), \`FocusNodeBleService\` catches \`STATE_DISCONNECTED\` or \`ACTION_STATE_CHANGED\` and immediately disarms lockdown mode (\`repository.disarmDeadlock()\` and \`repository.setFocusMode(false)\`). It automatically resumes scanning in \`SCAN_MODE_LOW_LATENCY\` to reconnect as soon as the puck comes back in range. This ensures you never remain stranded in lockdown mode when away from your desk!
`;

  zip.file("SETUP_AND_INSTALL_GUIDE.md", readmeContent);

  return await zip.generateAsync({ type: "blob" });
};

export const downloadAndroidProject = async () => {
  const blob = await generateAndroidProjectZip();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `DEADEND_Android_Launcher_Source.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};
