/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useDeadend } from '../context/DeadendContext';
import { ArrowLeft, Send, Plus, Check } from 'lucide-react';

export const SimulatedAppView: React.FC = () => {
  const {
    activeSimulatedApp,
    closeSimulatedApp,
    activeSession
  } = useDeadend();

  const [inputText, setInputText] = useState('');
  const [items, setItems] = useState<string[]>(['Quick thought: keep device usage intentional', 'Review AndroidManifest HOME category permissions', 'Verify DataStore Preferences']);

  if (!activeSimulatedApp) return null;

  return (
    <div className="fixed inset-0 z-30 bg-black text-neutral-100 font-mono flex flex-col justify-between overflow-hidden select-none animate-in fade-in duration-200">
      {/* App Top Bar */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-900 bg-neutral-950/80 backdrop-blur-md">
        <button
          onClick={closeSimulatedApp}
          className="flex items-center gap-2 text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft size={16} />
          <span>BACK TO DEADEND</span>
        </button>

        <div className="text-center">
          <div className="text-xs font-semibold text-white tracking-wide">
            {activeSimulatedApp.name}
          </div>
          <div className="text-[10px] text-neutral-500 font-mono">
            {activeSimulatedApp.packageName}
          </div>
        </div>

        <div className="w-16 text-right text-[10px] text-neutral-500">
          {activeSession ? (
            <span className="text-amber-400">ACTIVE</span>
          ) : (
            <span>UNLOCKED</span>
          )}
        </div>
      </div>

      {/* App Mock Content based on Category */}
      <div className="flex-1 p-6 overflow-y-auto no-scrollbar space-y-4">
        {activeSimulatedApp.id === 'phone' && (
          <div className="max-w-xs mx-auto space-y-6 pt-4">
            <div className="text-center py-4">
              <div className="text-xs text-neutral-500 uppercase tracking-widest mb-1">EMERGENCY DIALER</div>
              <div className="text-3xl text-white font-light tracking-widest">
                {inputText || "ENTER DIGITS"}
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3 text-center">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map((digit) => (
                <button
                  key={digit}
                  onClick={() => setInputText(prev => (prev + digit).slice(0, 12))}
                  className="py-4 text-xl border border-neutral-900 hover:border-neutral-700 bg-neutral-950 rounded transition-colors"
                >
                  {digit}
                </button>
              ))}
            </div>
            {inputText && (
              <button
                onClick={() => setInputText('')}
                className="w-full py-2 text-xs text-neutral-500 hover:text-neutral-300"
              >
                Clear
              </button>
            )}
          </div>
        )}

        {activeSimulatedApp.id === 'messages' && (
          <div className="max-w-md mx-auto space-y-3">
            <div className="text-[10px] text-neutral-600 uppercase tracking-widest text-center mb-4">
              DIRECT THREADS (ESSENTIAL ACCESS)
            </div>
            <div className="p-3 bg-neutral-950 border border-neutral-900 rounded space-y-1">
              <div className="flex justify-between text-xs text-white">
                <span className="font-semibold">Mom</span>
                <span className="text-neutral-500 text-[10px]">10:14 AM</span>
              </div>
              <div className="text-xs text-neutral-400">Call me when you reach home.</div>
            </div>
            <div className="p-3 bg-neutral-950 border border-neutral-900 rounded space-y-1">
              <div className="flex justify-between text-xs text-white">
                <span className="font-semibold">Emergency Contact: Sarah</span>
                <span className="text-neutral-500 text-[10px]">Yesterday</span>
              </div>
              <div className="text-xs text-neutral-400">Keys are in the lockbox.</div>
            </div>
          </div>
        )}

        {activeSimulatedApp.id === 'notes' && (
          <div className="max-w-md mx-auto space-y-3">
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Capture quick thought..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && inputText.trim()) {
                    setItems([inputText.trim(), ...items]);
                    setInputText('');
                  }
                }}
                className="flex-1 text-xs px-3 py-2 bg-neutral-950 border border-neutral-800 rounded text-white focus:outline-none focus:border-neutral-500"
              />
              <button
                onClick={() => {
                  if (inputText.trim()) {
                    setItems([inputText.trim(), ...items]);
                    setInputText('');
                  }
                }}
                className="px-3 py-2 bg-neutral-900 hover:bg-neutral-800 text-xs rounded border border-neutral-800"
              >
                <Plus size={14} />
              </button>
            </div>
            <div className="space-y-1 pt-2">
              {items.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between p-2.5 bg-neutral-950 border border-neutral-900 rounded text-xs text-neutral-300">
                  <span>{item}</span>
                  <Check size={12} className="text-neutral-600" />
                </div>
              ))}
            </div>
          </div>
        )}

        {activeSimulatedApp.category === 'intercepted' && (
          <div className="max-w-md mx-auto py-8 text-center space-y-4">
            <div className="p-4 bg-neutral-950 border border-neutral-900 rounded space-y-2 text-left">
              <div className="text-xs text-amber-400 font-semibold uppercase tracking-wider">
                Sanctioned Intentional Session
              </div>
              <div className="text-xs text-neutral-300">
                You are currently inside <span className="text-white font-medium">{activeSimulatedApp.name}</span> with a strict timer.
              </div>
              {activeSession && (
                <div className="text-[11px] text-neutral-500 pt-1">
                  Declared Intent: <span className="text-neutral-300">"{activeSession.declaredIntent}"</span>
                </div>
              )}
            </div>

            <div className="text-xs text-neutral-500 leading-relaxed max-w-xs mx-auto">
              Finish your stated purpose promptly. The Deadend Interceptor will lock down this app when your allocated minutes elapse.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
