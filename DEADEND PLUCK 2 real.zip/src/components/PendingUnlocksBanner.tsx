/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useDeadend } from '../context/DeadendContext';
import { Clock, ShieldAlert, CheckCircle2, X } from 'lucide-react';

export const PendingUnlocksBanner: React.FC = () => {
  const {
    pendingLimitUnlocks,
    cancelLimitUnlock,
    applyLimitUnlock
  } = useDeadend();

  const [, setTick] = useState(0);

  useEffect(() => {
    if (pendingLimitUnlocks.length === 0) return;
    const interval = setInterval(() => setTick(t => t + 1), 1000);
    return () => clearInterval(interval);
  }, [pendingLimitUnlocks.length]);

  if (pendingLimitUnlocks.length === 0) return null;

  return (
    <div className="px-6 pt-2 select-none space-y-2 font-mono">
      {pendingLimitUnlocks.map((unlock) => {
        const remainingMs = Math.max(0, unlock.unlocksAt - Date.now());
        const remainingSec = Math.floor(remainingMs / 1000);
        const mins = Math.floor(remainingSec / 60);
        const secs = remainingSec % 60;
        const isReady = remainingSec <= 0;

        return (
          <div
            key={unlock.appId}
            className={`p-3 rounded border text-xs flex items-center justify-between transition-colors ${
              isReady
                ? 'bg-emerald-950/40 border-emerald-900/60 text-emerald-300'
                : 'bg-rose-950/40 border-rose-900/60 text-rose-200'
            }`}
          >
            <div className="space-y-0.5 overflow-hidden pr-2">
              <div className="flex items-center gap-1.5 font-semibold text-[11px]">
                <Clock size={12} className={isReady ? 'text-emerald-400' : 'text-rose-400 animate-pulse'} />
                <span>
                  {isReady
                    ? `Cool-down complete for ${unlock.appName}`
                    : `Limit modification queued for ${unlock.appName}`}
                </span>
              </div>
              <div className="text-[10px] text-neutral-400">
                {isReady ? (
                  "Intentional 15m delay satisfied. You may now apply the change."
                ) : (
                  <span>
                    Unlocks in <strong>{mins}m {secs.toString().padStart(2, '0')}s</strong>. Take a walk.
                  </span>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {isReady ? (
                <button
                  onClick={() => applyLimitUnlock(unlock.appId)}
                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-bold cursor-pointer"
                >
                  Apply Change
                </button>
              ) : (
                <button
                  onClick={() => cancelLimitUnlock(unlock.appId)}
                  className="flex items-center gap-1 px-2 py-1 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 rounded border border-neutral-700 text-[10px] cursor-pointer"
                  title="Cancel request and maintain focus discipline"
                >
                  <X size={11} />
                  <span>Stay Disciplined</span>
                </button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
};
