/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useDeadend } from '../context/DeadendContext';
import { ShieldCheck, Lock, ArrowRight } from 'lucide-react';

export const RationaleModal: React.FC = () => {
  const {
    permissionRationaleModal,
    closeRationaleModal,
    confirmRationaleAction
  } = useDeadend();

  if (!permissionRationaleModal) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 font-mono select-none animate-in fade-in duration-200">
      <div className="max-w-md w-full bg-neutral-950 border border-neutral-800 rounded-xl p-6 space-y-5 text-left text-neutral-200 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-900 pb-3">
          <div className="flex items-center gap-2">
            <ShieldCheck size={16} className="text-amber-400" />
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              Permission Rationale
            </span>
          </div>
          <button
            onClick={closeRationaleModal}
            className="text-neutral-500 hover:text-neutral-300 text-xs cursor-pointer"
          >
            CANCEL [ESC]
          </button>
        </div>

        {/* Content */}
        <div className="space-y-3">
          <div>
            <h3 className="text-sm font-semibold text-white">
              {permissionRationaleModal.title}
            </h3>
            <p className="text-[11px] text-amber-400/90 font-mono mt-0.5">
              {permissionRationaleModal.subtitle}
            </p>
          </div>

          <div className="p-3 bg-black border border-neutral-900 rounded space-y-1.5">
            <div className="text-[10px] text-neutral-500 uppercase tracking-widest font-semibold">
              WHY THIS PERMISSION IS REQUIRED
            </div>
            <p className="text-xs text-neutral-300 leading-relaxed">
              {permissionRationaleModal.rationale}
            </p>
          </div>

          <div className="p-3 bg-neutral-900/60 border border-neutral-800 rounded space-y-1">
            <div className="text-[10px] text-emerald-400 uppercase tracking-widest font-semibold flex items-center gap-1.5">
              <Lock size={11} />
              <span>ON-DEVICE PRIVACY GUARANTEE</span>
            </div>
            <p className="text-[11px] text-neutral-400 leading-relaxed">
              {permissionRationaleModal.privacyGuarantee}
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-2 flex items-center justify-end gap-3">
          <button
            onClick={closeRationaleModal}
            className="px-3.5 py-2 text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            Not Now
          </button>
          <button
            onClick={confirmRationaleAction}
            className="flex items-center gap-1.5 px-4 py-2 bg-white text-black hover:bg-neutral-200 text-xs font-bold rounded transition-colors cursor-pointer"
          >
            <span>{permissionRationaleModal.actionLabel}</span>
            <ArrowRight size={13} />
          </button>
        </div>
      </div>
    </div>
  );
};
