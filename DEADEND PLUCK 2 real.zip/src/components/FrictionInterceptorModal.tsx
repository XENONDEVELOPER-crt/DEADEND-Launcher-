/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useDeadend } from '../context/DeadendContext';
import { audio } from '../utils/audio';
import { Sparkles, ArrowRight, ShieldCheck, Clock, AlertTriangle, MessageSquare } from 'lucide-react';

export const FrictionInterceptorModal: React.FC = () => {
  const {
    interceptorTargetApp,
    frictionConfig,
    cancelInterception,
    abortInterception,
    proceedInterception
  } = useDeadend();

  // Persistent friction check: subsequent launch today uses 5-second mandatory pause
  const isSubsequent = Boolean(interceptorTargetApp?.hasPersistentFrictionToday);
  const totalBreathSeconds = isSubsequent
    ? 5
    : Math.max(10, frictionConfig.breathingDurationSeconds || 10);

  // Breathing countdown state
  const [remainingBreath, setRemainingBreath] = useState<number>(totalBreathSeconds);
  const isBreathComplete = remainingBreath <= 0;
  const [breathPhase, setBreathPhase] = useState<'inhale' | 'exhale'>('inhale');

  // Intent & Budget state
  const [typedIntent, setTypedIntent] = useState<string>('');
  const [allocatedMinutes, setAllocatedMinutes] = useState<number>(5);

  // Intent validation: user must type a short sentence explaining their reason
  const isIntentValid = typedIntent.trim().length >= 4;

  // Breathing timer ticker
  useEffect(() => {
    if (!interceptorTargetApp) return;

    setRemainingBreath(totalBreathSeconds);
    setBreathPhase('inhale');
    audio.playBreathTone(true);

    const interval = setInterval(() => {
      setRemainingBreath(prev => {
        const next = prev - 1;
        if (next === Math.floor(totalBreathSeconds / 2)) {
          setBreathPhase('exhale');
          audio.playBreathTone(false);
        }
        if (next <= 0) {
          clearInterval(interval);
          return 0;
        }
        return next;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [interceptorTargetApp, totalBreathSeconds]);

  if (!interceptorTargetApp) return null;

  // Budget checks
  const timeUsedMinutes = Math.round(interceptorTargetApp.timeUsedTodaySeconds / 60);
  const isBudgetExceeded = interceptorTargetApp.dailyBudgetMinutes > 0 &&
    (timeUsedMinutes + allocatedMinutes) > interceptorTargetApp.dailyBudgetMinutes;

  return (
    <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex flex-col justify-between p-6 overflow-y-auto font-mono text-white select-none animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex items-center justify-between text-xs text-neutral-500 border-b border-neutral-900 pb-3">
        <div className="flex items-center gap-2">
          <span className="text-amber-400 font-bold tracking-widest text-[10px]">
            {isSubsequent ? "[PERSISTENT RE-ENTRY FRICTION]" : "[GRADUATED COST FRICTION GATE]"}
          </span>
          <span>·</span>
          <span className="text-neutral-400">{interceptorTargetApp.name}</span>
        </div>

        <button
          onClick={cancelInterception}
          className="text-neutral-500 hover:text-neutral-300 text-xs cursor-pointer"
        >
          DISMISS [ESC]
        </button>
      </div>

      {/* Main Body */}
      <div className="max-w-md w-full mx-auto my-auto py-6 flex flex-col items-center text-center">
        {/* Breathing Gate Visual */}
        <div className="relative my-6 flex items-center justify-center">
          <div
            className={`w-32 h-32 rounded-full border border-neutral-700 flex items-center justify-center transition-all duration-1000 ${
              breathPhase === 'inhale'
                ? 'scale-115 border-amber-400/50 shadow-[0_0_40px_rgba(251,191,36,0.15)]'
                : 'scale-90 border-neutral-800'
            }`}
          >
            <div className="flex flex-col items-center">
              <span className="text-3xl font-light tracking-tight text-white">
                {isBreathComplete ? (
                  <ShieldCheck size={32} className="text-emerald-400" />
                ) : (
                  `${remainingBreath}s`
                )}
              </span>
              <span className="text-[10px] tracking-widest text-neutral-400 mt-1 uppercase">
                {isBreathComplete
                  ? "INTENT UNLOCKED"
                  : breathPhase === 'inhale'
                  ? "INHALE SLOWLY"
                  : "EXHALE RELEASE"}
              </span>
            </div>
          </div>
        </div>

        {/* Informative Kicker */}
        {!isBreathComplete ? (
          <div className="space-y-2 mb-8">
            <h2 className="text-lg font-medium text-neutral-200">
              {isSubsequent
                ? "Subsequent Launch Re-Entry Pause"
                : "Mandatory Physiological Pause"}
            </h2>
            <p className="text-xs text-neutral-500 max-w-xs mx-auto leading-relaxed">
              {isSubsequent
                ? "You unlocked this app earlier today. Every subsequent launch requires re-centering with a 5-second breath."
                : "Notice the impulse without obeying it immediately. The non-skippable countdown eliminates muscle-memory opening."}
            </p>
            <div className="text-[11px] text-amber-500/80 pt-1 tracking-wider">
              [NON-SKIPPABLE BREATH GATE ACTIVE]
            </div>
          </div>
        ) : (
          /* Intent Declaration & Budget allocation (Unlocked after breathing) */
          <div className="w-full text-left space-y-5 animate-in fade-in duration-300">
            {/* Intent Typing Input */}
            <div>
              <div className="flex items-center justify-between text-[11px] mb-1.5">
                <label className="font-semibold text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
                  <MessageSquare size={12} className="text-amber-400" />
                  <span>1. Type Declared Reason</span>
                </label>
                <span className="text-[10px] text-neutral-500">
                  Short sentence required
                </span>
              </div>

              <input
                type="text"
                autoFocus
                placeholder='e.g., "Checking urgent message from team"'
                value={typedIntent}
                onChange={(e) => setTypedIntent(e.target.value)}
                className="w-full text-xs px-3 py-2.5 bg-neutral-950 border border-neutral-800 focus:border-amber-400 text-neutral-200 rounded focus:outline-none"
              />

              {/* Quick suggestions to click-to-fill */}
              <div className="flex flex-wrap gap-1 mt-2">
                {frictionConfig.quickIntents.slice(0, 3).map((intent) => (
                  <button
                    key={intent}
                    type="button"
                    onClick={() => {
                      setTypedIntent(intent);
                      audio.playClick();
                    }}
                    className="text-[10px] px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white cursor-pointer"
                  >
                    + {intent}
                  </button>
                ))}
              </div>
            </div>

            {/* Minute Budget Selection */}
            <div>
              <div className="flex items-center justify-between text-[11px] mb-2">
                <span className="font-semibold text-neutral-400 uppercase tracking-wider">
                  2. Allocate Time Budget
                </span>
                <span className="text-neutral-500 flex items-center gap-1">
                  <Clock size={11} />
                  <span>Used today: {timeUsedMinutes}m</span>
                </span>
              </div>

              <div className="grid grid-cols-4 gap-2">
                {[3, 5, 10, 15].map((mins) => (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => {
                      setAllocatedMinutes(mins);
                      audio.playClick();
                    }}
                    className={`py-2 text-xs text-center rounded border transition-all cursor-pointer ${
                      allocatedMinutes === mins
                        ? 'border-white bg-neutral-900 text-white font-bold'
                        : 'border-neutral-900 text-neutral-400 hover:border-neutral-700'
                    }`}
                  >
                    {mins}m
                  </button>
                ))}
              </div>

              {isBudgetExceeded && (
                <div className="flex items-center gap-1.5 text-[11px] text-rose-400 mt-2 bg-rose-950/20 border border-rose-900/50 p-2 rounded">
                  <AlertTriangle size={13} className="shrink-0" />
                  <span>
                    Warning: Exceeds your {interceptorTargetApp.dailyBudgetMinutes}m daily budget.
                  </span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Bottom Action Controls: Abort vs. Proceed */}
      <div className="max-w-md w-full mx-auto space-y-2 pt-4 border-t border-neutral-900">
        <button
          onClick={() => abortInterception(interceptorTargetApp, 15)}
          className="w-full py-3.5 px-4 bg-white text-black hover:bg-neutral-200 transition-colors font-mono font-semibold text-xs tracking-wider flex items-center justify-center gap-2 rounded cursor-pointer"
        >
          <Sparkles size={14} className="text-amber-600" />
          <span>ABORT &amp; SAVE MY TIME (+15M RECLAIMED)</span>
        </button>

        <button
          disabled={!isBreathComplete || !isIntentValid}
          onClick={() => proceedInterception(interceptorTargetApp, typedIntent, allocatedMinutes)}
          className={`w-full py-2.5 px-4 text-xs font-mono tracking-wider transition-colors flex items-center justify-center gap-2 rounded ${
            isBreathComplete && isIntentValid
              ? 'text-neutral-400 hover:text-white hover:bg-neutral-900 cursor-pointer'
              : 'text-neutral-700 cursor-not-allowed opacity-50'
          }`}
        >
          <span>
            {!isBreathComplete
              ? `BREATHE (${remainingBreath}s remaining)`
              : !isIntentValid
              ? "TYPE REASON TO PROCEED"
              : `PROCEED WITH ${allocatedMinutes}M SESSION`}
          </span>
          <ArrowRight size={13} />
        </button>
      </div>
    </div>
  );
};
