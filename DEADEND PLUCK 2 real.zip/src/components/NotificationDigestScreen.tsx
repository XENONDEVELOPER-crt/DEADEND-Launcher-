/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useDeadend } from '../context/DeadendContext';
import {
  ArrowLeft,
  Bell,
  BellOff,
  Clock,
  ShieldCheck,
  Send,
  Plus,
  Trash2,
  CheckCircle2,
  Sparkles
} from 'lucide-react';

export const NotificationDigestScreen: React.FC = () => {
  const {
    digestConfig,
    toggleDigestEnabled,
    releaseDigestNow,
    dismissBatchNotification,
    simulateIncomingNotification,
    setViewMode
  } = useDeadend();

  const [newScheduleTime, setNewScheduleTime] = useState('');

  const formatTimestamp = (ts: number) => {
    const d = new Date(ts);
    return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex flex-col flex-1 overflow-hidden px-6 pb-6 text-white font-mono select-none">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-neutral-900 pb-4 mb-4">
        <button
          onClick={() => setViewMode('launcher')}
          className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft size={14} />
          <span>BACK TO LAUNCHER</span>
        </button>

        <span className="text-[10px] text-amber-400 uppercase tracking-widest font-semibold">
          SCHEDULED BATCH DIGEST
        </span>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar space-y-5">
        {/* Master Toggle Banner */}
        <div className="p-4 bg-neutral-950 border border-neutral-900 rounded flex items-center justify-between">
          <div className="space-y-0.5">
            <div className="text-xs font-semibold text-neutral-200">
              Notification Interception Engine
            </div>
            <div className="text-[11px] text-neutral-500">
              {digestConfig.enabled
                ? "Silently suppresses non-essential notifications into batch digests."
                : "Pass-through mode: alerts ring immediately without batching."}
            </div>
          </div>

          <button
            onClick={toggleDigestEnabled}
            className={`px-3 py-1.5 text-xs rounded border transition-colors cursor-pointer ${
              digestConfig.enabled
                ? 'bg-amber-950/40 border-amber-800 text-amber-300 font-bold'
                : 'bg-neutral-900 border-neutral-800 text-neutral-500'
            }`}
          >
            {digestConfig.enabled ? "Active" : "Disabled"}
          </button>
        </div>

        {/* Priority Whitelist (Always bypasses digest) */}
        <div className="p-3.5 bg-neutral-950/80 border border-neutral-900 rounded space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-neutral-200 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck size={13} className="text-emerald-400" />
              <span>Priority Whitelist (Bypasses Digest)</span>
            </span>
            <span className="text-[10px] text-emerald-400">INSTANT DELIVERY</span>
          </div>
          <p className="text-[11px] text-neutral-500">
            Emergency calls, SMS, calendar events, and morning alarms always bypass the digest engine and ring immediately.
          </p>
          <div className="flex flex-wrap gap-1.5 text-[10px] text-neutral-400 pt-1">
            <span className="px-2 py-1 bg-black border border-neutral-900 rounded">Phone (Emergency Dialer)</span>
            <span className="px-2 py-1 bg-black border border-neutral-900 rounded">Direct SMS</span>
            <span className="px-2 py-1 bg-black border border-neutral-900 rounded">System Alarms &amp; Timers</span>
            <span className="px-2 py-1 bg-black border border-neutral-900 rounded">Calendar Reminders</span>
          </div>
        </div>

        {/* Scheduled Delivery Intervals */}
        <div className="p-3.5 bg-neutral-950/80 border border-neutral-900 rounded space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-neutral-200 uppercase tracking-wider flex items-center gap-1.5">
              <Clock size={13} className="text-sky-400" />
              <span>Scheduled Digest Delivery Times</span>
            </span>
          </div>
          <p className="text-[11px] text-neutral-500">
            Batched alerts are delivered simultaneously at these hours:
          </p>
          <div className="flex items-center gap-2 pt-1">
            {digestConfig.scheduledTimes.map((time) => (
              <div
                key={time}
                className="px-3 py-1 bg-neutral-900 border border-neutral-800 rounded text-xs text-white flex items-center gap-2"
              >
                <span>{time}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Current Batched Notifications Pool */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-neutral-300 uppercase tracking-wider">
              Batched Alerts ({digestConfig.batchedNotifications.length})
            </span>

            <div className="flex gap-2">
              <button
                onClick={simulateIncomingNotification}
                className="flex items-center gap-1 text-[10px] text-neutral-400 hover:text-white px-2 py-1 bg-neutral-900 rounded border border-neutral-800 cursor-pointer"
                title="Simulate a background app pushing an alert"
              >
                <Plus size={11} />
                <span>Simulate Alert</span>
              </button>

              {digestConfig.batchedNotifications.length > 0 && (
                <button
                  onClick={releaseDigestNow}
                  className="flex items-center gap-1 text-[10px] text-amber-300 hover:text-amber-200 px-2.5 py-1 bg-amber-950/40 rounded border border-amber-900/60 cursor-pointer font-medium"
                >
                  <Send size={11} />
                  <span>Deliver Now</span>
                </button>
              )}
            </div>
          </div>

          {digestConfig.batchedNotifications.length === 0 ? (
            <div className="p-8 text-center border border-neutral-900 rounded bg-neutral-950/40 space-y-1">
              <CheckCircle2 size={24} className="text-emerald-400 mx-auto mb-2" />
              <div className="text-xs text-neutral-300 font-medium">Distraction Shield Calm</div>
              <p className="text-[11px] text-neutral-600">
                No queued notifications. Incoming alerts from social apps will be silently held here until your next digest.
              </p>
            </div>
          ) : (
            <div className="space-y-1.5">
              {digestConfig.batchedNotifications.map((notif) => (
                <div
                  key={notif.id}
                  className="p-3 bg-neutral-950 border border-neutral-900 rounded flex items-start justify-between text-xs"
                >
                  <div className="space-y-0.5 pr-2">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-white">{notif.appName}</span>
                      <span className="text-[10px] text-neutral-500">
                        {formatTimestamp(notif.timestamp)}
                      </span>
                    </div>
                    <div className="text-neutral-300 font-medium text-[11px]">
                      {notif.title}
                    </div>
                    <div className="text-[11px] text-neutral-500">
                      {notif.body}
                    </div>
                  </div>

                  <button
                    onClick={() => dismissBatchNotification(notif.id)}
                    className="text-neutral-600 hover:text-neutral-300 p-1 cursor-pointer"
                    title="Dismiss notification"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
