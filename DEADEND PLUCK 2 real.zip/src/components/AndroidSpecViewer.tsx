/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useDeadend } from '../context/DeadendContext';
import { ANDROID_FILES, CodeFileSpec } from '../data/androidSpec';
import { downloadAndroidProject } from '../utils/exportAndroidProject';
import {
  ArrowLeft,
  Copy,
  Check,
  FileCode,
  Shield,
  Layers,
  Cpu,
  Download,
  HelpCircle,
  ExternalLink,
  Terminal,
  Smartphone
} from 'lucide-react';

export const AndroidSpecViewer: React.FC = () => {
  const { setViewMode } = useDeadend();
  const [selectedFile, setSelectedFile] = useState<CodeFileSpec>(ANDROID_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [showGuideModal, setShowGuideModal] = useState(false);
  const [copiedAdb, setCopiedAdb] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportZip = async () => {
    try {
      setIsExporting(true);
      await downloadAndroidProject();
    } finally {
      setIsExporting(false);
    }
  };

  const adbCommand = "adb shell cmd package set-home-activity io.deadend.launcher/.ui.HomeScreen";

  const handleCopyAdb = () => {
    navigator.clipboard.writeText(adbCommand);
    setCopiedAdb(true);
    setTimeout(() => setCopiedAdb(false), 2000);
  };

  return (
    <div className="flex flex-col flex-1 overflow-hidden px-6 pb-6 text-white font-mono select-none relative">
      {/* Top Bar */}
      <div className="flex items-center justify-between border-b border-neutral-900 pb-4 mb-4">
        <button
          onClick={() => setViewMode('launcher')}
          className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft size={14} />
          <span>BACK TO LAUNCHER</span>
        </button>

        <div className="flex items-center gap-2">
          {/* Setup Guide Button */}
          <button
            onClick={() => setShowGuideModal(true)}
            className="flex items-center gap-1.5 text-xs text-neutral-300 hover:text-white px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 rounded border border-neutral-800 transition-colors cursor-pointer"
          >
            <HelpCircle size={13} className="text-amber-400" />
            <span>How to Set as Home Launcher</span>
          </button>

          {/* 1-Click Export Zip Button */}
          <button
            onClick={handleExportZip}
            disabled={isExporting}
            className="flex items-center gap-1.5 text-xs font-semibold text-black bg-white hover:bg-neutral-200 px-3 py-1.5 rounded transition-colors cursor-pointer"
          >
            <Download size={13} />
            <span>{isExporting ? "Bundling ZIP..." : "Download Android Project (.ZIP)"}</span>
          </button>
        </div>
      </div>

      {/* Architecture Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-4 text-xs">
        <div className="p-2.5 bg-neutral-950 border border-neutral-900 rounded space-y-0.5">
          <div className="flex items-center gap-1.5 text-neutral-300 font-semibold text-[11px]">
            <Cpu size={12} className="text-amber-400" />
            <span>Target SDK 35 (Android 15)</span>
          </div>
          <div className="text-[10px] text-neutral-500">
            Min SDK 26 · Jetpack Compose BOM · Kotlin 2.0
          </div>
        </div>

        <div className="p-2.5 bg-neutral-950 border border-neutral-900 rounded space-y-0.5">
          <div className="flex items-center gap-1.5 text-neutral-300 font-semibold text-[11px]">
            <Shield size={12} className="text-emerald-400" />
            <span>Permissions Architecture</span>
          </div>
          <div className="text-[10px] text-neutral-500">
            HOME Intent · USAGE_STATS · SYSTEM_ALERT_WINDOW
          </div>
        </div>

        <div className="p-2.5 bg-neutral-950 border border-neutral-900 rounded space-y-0.5">
          <div className="flex items-center gap-1.5 text-neutral-300 font-semibold text-[11px]">
            <Layers size={12} className="text-sky-400" />
            <span>Data Persistence</span>
          </div>
          <div className="text-[10px] text-neutral-500">
            Preferences DataStore + Room DB + AlarmManager
          </div>
        </div>
      </div>

      {/* File Selector Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto no-scrollbar pb-2 mb-3 border-b border-neutral-900 text-xs">
        {ANDROID_FILES.map((file) => (
          <button
            key={file.path}
            onClick={() => setSelectedFile(file)}
            className={`px-3 py-1.5 rounded transition-all shrink-0 flex items-center gap-1.5 cursor-pointer ${
              selectedFile.path === file.path
                ? 'bg-neutral-800 text-white font-medium border border-neutral-700'
                : 'text-neutral-500 hover:text-neutral-300'
            }`}
          >
            <FileCode size={12} />
            <span>{file.path.split('/').pop()}</span>
          </button>
        ))}
      </div>

      {/* File Details & Copy Bar */}
      <div className="flex items-center justify-between text-xs py-2 px-3 bg-neutral-950 border border-neutral-900 rounded-t">
        <div className="truncate pr-2">
          <span className="text-neutral-400 font-medium">{selectedFile.path}</span>
          <span className="text-neutral-600 mx-2">·</span>
          <span className="text-[11px] text-neutral-500 hidden sm:inline">
            {selectedFile.description}
          </span>
        </div>

        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white px-2.5 py-1 bg-neutral-900 hover:bg-neutral-800 rounded border border-neutral-800 transition-colors shrink-0 cursor-pointer"
        >
          {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
          <span>{copied ? "Copied" : "Copy Code"}</span>
        </button>
      </div>

      {/* Code Display */}
      <div className="flex-1 overflow-y-auto no-scrollbar bg-black border-x border-b border-neutral-900 p-4 font-mono text-[11px] leading-relaxed text-neutral-300 select-text">
        <pre className="overflow-x-auto whitespace-pre font-mono">
          <code>{selectedFile.content}</code>
        </pre>
      </div>

      {/* Setup Guide Modal */}
      {showGuideModal && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-xl w-full bg-neutral-950 border border-neutral-800 rounded-xl p-6 space-y-5 text-left max-h-[85vh] overflow-y-auto font-mono text-neutral-200">
            <div className="flex items-center justify-between border-b border-neutral-900 pb-3">
              <div className="flex items-center gap-2">
                <Smartphone size={16} className="text-amber-400" />
                <h3 className="text-sm font-semibold text-white uppercase tracking-wider">
                  How to Set DEADEND as Default Home Launcher
                </h3>
              </div>
              <button
                onClick={() => setShowGuideModal(false)}
                className="text-neutral-500 hover:text-neutral-300 text-xs cursor-pointer"
              >
                CLOSE [ESC]
              </button>
            </div>

            <div className="space-y-4 text-xs leading-relaxed text-neutral-300">
              {/* Step 1 */}
              <div className="p-3 bg-black border border-neutral-900 rounded space-y-1.5">
                <div className="font-semibold text-white flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-neutral-800 text-[11px] flex items-center justify-center">1</span>
                  <span>Export &amp; Build APK</span>
                </div>
                <p className="text-neutral-400 text-[11px] pl-7">
                  Click <strong>Download Android Project (.ZIP)</strong> above, unzip it, and open it in <strong>Android Studio</strong>.
                  Then run:
                </p>
                <div className="ml-7 p-2 bg-neutral-950 border border-neutral-800 text-[11px] rounded text-neutral-300">
                  <code>./gradlew assembleDebug</code>
                </div>
              </div>

              {/* Step 2 */}
              <div className="p-3 bg-black border border-neutral-900 rounded space-y-1.5">
                <div className="font-semibold text-white flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-neutral-800 text-[11px] flex items-center justify-center">2</span>
                  <span>Set as Default Home Launcher in Android Settings</span>
                </div>
                <div className="text-neutral-400 text-[11px] pl-7 space-y-1">
                  <p>On your phone:</p>
                  <ol className="list-decimal pl-4 space-y-1 text-neutral-300">
                    <li>Go to <strong>Settings</strong> → <strong>Apps</strong> (or <strong>Apps &amp; Notifications</strong>).</li>
                    <li>Tap <strong>Default Apps</strong> → <strong>Home app</strong>.</li>
                    <li>Select <strong>DEADEND</strong>.</li>
                    <li>Press your Home button or swipe up — DEADEND is now your permanent launcher!</li>
                  </ol>
                </div>
              </div>

              {/* Step 3 */}
              <div className="p-3 bg-black border border-neutral-900 rounded space-y-1.5">
                <div className="font-semibold text-white flex items-center gap-2">
                  <Terminal size={14} className="text-emerald-400" />
                  <span>Instant Setup via ADB Command</span>
                </div>
                <p className="text-neutral-400 text-[11px]">
                  Alternatively, if your phone is plugged in via USB debugging, set it instantly with one terminal command:
                </p>
                <div className="flex items-center justify-between p-2 bg-neutral-950 border border-neutral-800 rounded text-[11px]">
                  <code className="text-emerald-400 select-all truncate pr-2">
                    {adbCommand}
                  </code>
                  <button
                    onClick={handleCopyAdb}
                    className="shrink-0 text-xs px-2 py-1 bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 rounded text-neutral-200 cursor-pointer"
                  >
                    {copiedAdb ? "Copied" : "Copy"}
                  </button>
                </div>
              </div>

              {/* Step 4 */}
              <div className="p-3 bg-black border border-neutral-900 rounded space-y-1.5">
                <div className="font-semibold text-white flex items-center gap-2">
                  <Shield size={14} className="text-sky-400" />
                  <span>Grant Anti-Distraction Permissions</span>
                </div>
                <p className="text-neutral-400 text-[11px] pl-2">
                  For the <strong>Breathing Gate</strong> to intercept opening apps before they display:
                </p>
                <ul className="list-disc pl-6 text-[11px] space-y-1 text-neutral-300">
                  <li><strong>Display over other apps:</strong> Settings → Special App Access → Display over other apps → DEADEND → Allow</li>
                  <li><strong>Usage Access:</strong> Settings → Special App Access → Usage Access → DEADEND → Allow</li>
                  <li><strong>Accessibility:</strong> Settings → Accessibility → DEADEND Interceptor → Enable</li>
                </ul>
              </div>
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                onClick={() => setShowGuideModal(false)}
                className="px-4 py-2 bg-white text-black hover:bg-neutral-200 text-xs font-semibold rounded cursor-pointer"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
