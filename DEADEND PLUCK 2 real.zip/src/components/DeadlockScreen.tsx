/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useDeadend } from '../context/DeadendContext';
import {
  Phone,
  MessageSquare,
  AlertOctagon,
  Unlock,
  ShieldAlert,
  Bluetooth,
  PhoneCall,
  PhoneOff,
  Radio,
  X,
  Volume2
} from 'lucide-react';

export const DeadlockScreen: React.FC = () => {
  const {
    deadlockState,
    disarmDeadlock,
    apps,
    handleAppClick,
    setMonolithBleConnected
  } = useDeadend();

  const [showExitChallenge, setShowExitChallenge] = useState<boolean>(false);
  const [typedExitPledge, setTypedExitPledge] = useState<string>('');

  // Interactive Incoming Call Simulation state
  const [simulatedCall, setSimulatedCall] = useState<{
    caller: string;
    number: string;
    status: 'ringing' | 'in_call' | null;
    durationSeconds: number;
  }>({
    caller: 'Mom (Emergency Whitelist)',
    number: '+1 (555) 019-2834',
    status: null,
    durationSeconds: 0
  });

  // Simulated Incoming Urgent SMS
  const [incomingSmsToast, setIncomingSmsToast] = useState<{
    sender: string;
    message: string;
    time: string;
  } | null>(null);

  // Active in-call timer
  useEffect(() => {
    if (simulatedCall.status !== 'in_call') return;
    const interval = setInterval(() => {
      setSimulatedCall(prev => ({
        ...prev,
        durationSeconds: prev.durationSeconds + 1
      }));
    }, 1000);
    return () => clearInterval(interval);
  }, [simulatedCall.status]);

  if (!deadlockState.isActive || !deadlockState.endsAt) return null;

  const remainingMs = Math.max(0, deadlockState.endsAt - Date.now());
  const totalSeconds = Math.floor(remainingMs / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  const emergencyPhone = apps.find(a => a.id === 'phone') || {
    id: 'phone',
    name: 'Phone',
    packageName: 'com.google.android.dialer',
    category: 'essential',
    dailyBudgetMinutes: 0,
    timeUsedTodaySeconds: 0,
    openCountToday: 0,
    isPinned: true,
    isHidden: false,
    isEmergencyAllowed: true
  };

  const emergencySms = apps.find(a => a.id === 'messages') || {
    id: 'messages',
    name: 'Messages',
    packageName: 'com.google.android.apps.messaging',
    category: 'essential',
    dailyBudgetMinutes: 0,
    timeUsedTodaySeconds: 0,
    openCountToday: 0,
    isPinned: true,
    isHidden: false,
    isEmergencyAllowed: true
  };

  const exitPledgeText = "EMERGENCY EXIT";
  const isPledgeValid = typedExitPledge.trim().toUpperCase() === exitPledgeText;

  // Trigger simulated incoming call
  const triggerIncomingCall = () => {
    setSimulatedCall({
      caller: 'Family Contact (Priority)',
      number: '+1 (555) 234-8901',
      status: 'ringing',
      durationSeconds: 0
    });
  };

  // Trigger simulated incoming urgent SMS
  const triggerIncomingSms = () => {
    setIncomingSmsToast({
      sender: 'Dr. Harris / Medical Clinic',
      message: 'Urgent: Your prescription update is confirmed for pickup.',
      time: 'Just now'
    });
    setTimeout(() => {
      setIncomingSmsToast(null);
    }, 7000);
  };

  const formatCallTime = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  return (
    <div className="absolute inset-0 z-50 bg-black text-white font-mono flex flex-col justify-between p-5 select-none overflow-y-auto animate-in fade-in duration-300">
      {/* 1. Header: Lockdown Hardware Protocol Notice */}
      <div className="flex flex-col gap-2 border-b border-rose-950/60 pb-3">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            <ShieldAlert size={14} className="text-rose-500" />
            <span className="tracking-widest uppercase font-bold text-[11px] text-rose-400">
              DEADLOCK LOCKDOWN MODE
            </span>
          </div>
          <span className="text-[10px] text-rose-500/80 bg-rose-950/50 px-2 py-0.5 rounded border border-rose-900/60 font-semibold tracking-wider">
            ALL APPS BLOCKED
          </span>
        </div>

        {/* ESP32 DEADEND_PUCK Telemetry */}
        <div className="flex items-center justify-between text-[10px] text-neutral-400 bg-neutral-950 px-2.5 py-1.5 rounded border border-neutral-900">
          <div className="flex items-center gap-1.5">
            <Bluetooth size={12} className="text-amber-400 animate-pulse" />
            <span className="text-amber-300 font-semibold">DEADEND_PUCK LINKED</span>
            <span className="text-neutral-600">·</span>
            <span className="text-neutral-500 font-mono text-[9px]">UUID 4fafc201</span>
          </div>
          <span className="text-neutral-500 text-[9px] uppercase tracking-wider">
            HARDWARE TETHER ACTIVE
          </span>
        </div>
      </div>

      {/* 2. Simulated Urgent SMS Toast Overlay (if triggered) */}
      {incomingSmsToast && (
        <div className="my-2 p-3 bg-neutral-950 border border-sky-900/80 rounded-md shadow-lg animate-in slide-in-from-top duration-200">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-1.5 text-sky-400 text-xs font-semibold">
              <MessageSquare size={13} />
              <span>INCOMING WHITELIST SMS</span>
            </div>
            <button
              onClick={() => setIncomingSmsToast(null)}
              className="text-neutral-500 hover:text-neutral-300 text-xs"
            >
              <X size={13} />
            </button>
          </div>
          <div className="mt-1 text-xs text-white font-medium">{incomingSmsToast.sender}</div>
          <p className="text-[11px] text-neutral-300 mt-0.5">{incomingSmsToast.message}</p>
          <div className="mt-2 flex gap-2">
            <button
              onClick={() => {
                setIncomingSmsToast(null);
                handleAppClick(emergencySms);
              }}
              className="text-[10px] px-2.5 py-1 bg-sky-950 border border-sky-800 text-sky-200 rounded hover:bg-sky-900 transition-colors cursor-pointer"
            >
              Open in Messages
            </button>
          </div>
        </div>
      )}

      {/* 3. Main Center: Countdown Timer & Hardware Status */}
      <div className="my-auto py-4 text-center space-y-4">
        <div className="inline-flex p-3 rounded-full bg-rose-950/30 border border-rose-900/60 shadow-[0_0_24px_rgba(244,63,94,0.15)]">
          <AlertOctagon size={36} className="text-rose-500 stroke-1 animate-pulse" />
        </div>

        <div className="space-y-1">
          <div className="text-[10px] text-rose-400 tracking-widest uppercase font-semibold">
            DEVICE LOCKED TO MONOLITH DESK NODE
          </div>
          <h1 className="text-5xl sm:text-6xl font-light tracking-tight text-white font-mono">
            {hours.toString().padStart(2, '0')}:{minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')}
          </h1>
          <p className="text-xs text-neutral-400 max-w-xs mx-auto pt-1 leading-relaxed">
            All distraction apps, social feeds, and browser interactions are suppressed on-device.
          </p>
        </div>

        {/* Emergency Communication Whitelist Buttons */}
        <div className="pt-2 border-t border-neutral-900">
          <div className="text-[10px] text-neutral-500 uppercase tracking-widest mb-2.5 flex items-center justify-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>EMERGENCY ACCESS ONLY</span>
          </div>

          <div className="grid grid-cols-2 gap-2 max-w-xs mx-auto">
            <button
              onClick={() => handleAppClick(emergencyPhone)}
              className="flex items-center justify-center gap-2 px-3 py-2.5 bg-neutral-950 border border-emerald-900/60 hover:border-emerald-500 hover:bg-emerald-950/30 rounded text-xs text-neutral-200 transition-all cursor-pointer shadow-sm group"
            >
              <Phone size={14} className="text-emerald-400 group-hover:scale-110 transition-transform" />
              <span className="font-semibold text-neutral-200">Phone Calls</span>
            </button>

            <button
              onClick={() => handleAppClick(emergencySms)}
              className="flex items-center justify-center gap-2 px-3 py-2.5 bg-neutral-950 border border-sky-900/60 hover:border-sky-500 hover:bg-sky-950/30 rounded text-xs text-neutral-200 transition-all cursor-pointer shadow-sm group"
            >
              <MessageSquare size={14} className="text-sky-400 group-hover:scale-110 transition-transform" />
              <span className="font-semibold text-neutral-200">Messages</span>
            </button>
          </div>
        </div>

        {/* Whitelist Verification: Test Incoming Calls & Messages */}
        <div className="pt-2 border-t border-neutral-900/80">
          <div className="text-[9px] text-neutral-600 uppercase tracking-wider mb-2">
            TEST INCOMING CALLS & MESSAGES BYPASS
          </div>
          <div className="flex items-center justify-center gap-2">
            <button
              onClick={triggerIncomingCall}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-[10px] text-emerald-400 rounded transition-colors cursor-pointer"
              title="Test incoming phone call penetrating deadlock"
            >
              <PhoneCall size={11} />
              <span>Simulate Call</span>
            </button>

            <button
              onClick={triggerIncomingSms}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-[10px] text-sky-400 rounded transition-colors cursor-pointer"
              title="Test incoming priority SMS penetrating deadlock"
            >
              <Radio size={11} />
              <span>Simulate SMS</span>
            </button>
          </div>
        </div>

        {/* 4. Remove Puck from Desk Action (UUID turns off) */}
        <div className="pt-3 border-t border-neutral-900">
          <button
            onClick={() => setMonolithBleConnected(false)}
            className="w-full max-w-xs mx-auto flex items-center justify-center gap-2 py-2 px-3 bg-amber-950/30 hover:bg-amber-900/40 border border-amber-800/80 text-amber-300 rounded text-xs transition-colors cursor-pointer group"
            title="Remove ESP32 DEADEND_PUCK from desk. UUID turns off and turns off deadlock, restoring the launcher."
          >
            <Bluetooth size={13} className="text-amber-400 group-hover:animate-pulse" />
            <span className="font-semibold">Remove Puck (UUID Off) & Restore Launcher</span>
          </button>
          <div className="text-[9px] text-neutral-500 mt-1">
            Lifting puck automatically disarms lockdown and returns to home
          </div>
        </div>

        {/* 5. Emergency Exit Challenge Panel */}
        {showExitChallenge && (
          <div className="bg-neutral-950 border border-rose-900/60 p-4 rounded text-left space-y-3 animate-in slide-in-from-bottom duration-200 max-w-xs mx-auto">
            <div className="flex items-center justify-between">
              <span className="text-xs text-rose-400 font-semibold flex items-center gap-1.5">
                <AlertOctagon size={13} />
                EMERGENCY OVERRIDE
              </span>
              <button
                onClick={() => setShowExitChallenge(false)}
                className="text-neutral-500 hover:text-neutral-300 text-xs"
              >
                <X size={12} />
              </button>
            </div>
            <div className="text-[11px] text-neutral-400">
              Type <span className="text-white font-bold select-text">EMERGENCY EXIT</span> to confirm conscious disarm:
            </div>
            <input
              type="text"
              value={typedExitPledge}
              onChange={(e) => setTypedExitPledge(e.target.value)}
              placeholder="EMERGENCY EXIT"
              className="w-full text-xs px-3 py-2 bg-black border border-neutral-800 focus:border-rose-500 text-white rounded focus:outline-none uppercase tracking-wider"
              autoFocus
            />
            <div className="flex gap-2">
              <button
                disabled={!isPledgeValid}
                onClick={() => {
                  disarmDeadlock();
                  setShowExitChallenge(false);
                }}
                className={`flex-1 py-2 text-xs font-mono rounded font-semibold transition-colors ${
                  isPledgeValid
                    ? 'bg-rose-600 text-white hover:bg-rose-500 cursor-pointer'
                    : 'bg-neutral-900 text-neutral-600 cursor-not-allowed'
                }`}
              >
                Confirm Disarm
              </button>
              <button
                onClick={() => setShowExitChallenge(false)}
                className="px-3 py-2 text-xs text-neutral-500 hover:text-neutral-300"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 6. Bottom Emergency Override Toggle */}
      <div className="border-t border-neutral-900 pt-3 flex items-center justify-between text-xs">
        {!showExitChallenge ? (
          <button
            onClick={() => setShowExitChallenge(true)}
            className="flex items-center gap-1.5 text-xs text-neutral-600 hover:text-rose-400 transition-colors cursor-pointer mx-auto"
          >
            <Unlock size={12} />
            <span>Emergency Exit Override</span>
          </button>
        ) : (
          <span className="text-[10px] text-neutral-600 text-center w-full">
            Intentional pledge gate active
          </span>
        )}
      </div>

      {/* 7. Realistic Full-Screen / Modal Incoming Call HUD */}
      {simulatedCall.status && (
        <div className="absolute inset-0 z-60 bg-black/95 flex flex-col justify-between p-6 animate-in zoom-in-95 duration-200">
          <div className="text-center pt-8 space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-950/40 border border-emerald-800/60 rounded-full text-emerald-400 text-xs font-semibold">
              <PhoneCall size={12} className="animate-bounce" />
              <span>INCOMING CALL · WHITELIST BYPASS</span>
            </div>
            <h2 className="text-2xl font-light text-white pt-4">{simulatedCall.caller}</h2>
            <p className="text-xs text-neutral-400 font-mono">{simulatedCall.number}</p>
            {simulatedCall.status === 'in_call' ? (
              <div className="pt-4 text-emerald-400 font-mono text-xl tracking-wider animate-pulse">
                {formatCallTime(simulatedCall.durationSeconds)}
              </div>
            ) : (
              <div className="pt-4 text-neutral-500 text-xs font-mono tracking-widest uppercase flex items-center justify-center gap-1">
                <Volume2 size={13} className="text-emerald-400 animate-pulse" />
                <span>Ringing...</span>
              </div>
            )}
          </div>

          <div className="pb-8 flex items-center justify-around max-w-xs mx-auto w-full">
            {simulatedCall.status === 'ringing' ? (
              <>
                <button
                  onClick={() => setSimulatedCall(prev => ({ ...prev, status: null }))}
                  className="w-14 h-14 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-lg transition-transform hover:scale-105 cursor-pointer"
                  title="Decline Call"
                >
                  <PhoneOff size={22} />
                </button>
                <button
                  onClick={() => setSimulatedCall(prev => ({ ...prev, status: 'in_call' }))}
                  className="w-14 h-14 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-lg transition-transform hover:scale-105 cursor-pointer animate-pulse"
                  title="Answer Call"
                >
                  <Phone size={22} />
                </button>
              </>
            ) : (
              <button
                onClick={() => setSimulatedCall(prev => ({ ...prev, status: null, durationSeconds: 0 }))}
                className="w-14 h-14 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-lg transition-transform hover:scale-105 cursor-pointer"
                title="End Call"
              >
                <PhoneOff size={22} />
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
