/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useDeadend } from '../context/DeadendContext';
import { CheckCircle2, Lock } from 'lucide-react';

export const ActiveSessionOverlay: React.FC = () => {
  const { activeSession, endActiveSession } = useDeadend();

  if (!activeSession) return null;

  const minutes = Math.floor(activeSession.remainingSeconds / 60);
  const seconds = activeSession.remainingSeconds % 60;
  const timeFormatted = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

  const isLowTime = activeSession.remainingSeconds <= 60 && activeSession.remainingSeconds > 0;

  // Session has hit zero: Hard Lockout Overlay!
  if (activeSession.isExpired) {
    return (
      <div className="fixed inset-0 z-50 bg-black text-white font-mono flex flex-col items-center justify-center p-6 text-center select-none animate-in fade-in duration-300">
        <div className="p-4 rounded-full bg-rose-950/40 border border-rose-900/60 mb-6">
          <Lock size={48} className="text-rose-500" />
        </div>

        <h1 className="text-2xl sm:text-3xl font-light tracking-tight mb-2">
          SESSION EXPIRED
        </h1>
        <p className="text-xs text-neutral-400 max-w-xs mb-8 leading-relaxed">
          Your allocated {activeSession.allocatedMinutes}m for {activeSession.app.name} has concluded.
          Step away from the screen and return to reality.
        </p>

        <button
          onClick={() => endActiveSession(false)}
          className="py-3 px-8 bg-white text-black hover:bg-neutral-200 text-xs font-mono font-semibold tracking-wider rounded transition-colors cursor-pointer"
        >
          RETURN TO STILLNESS
        </button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-4 left-4 right-4 z-40 max-w-sm mx-auto bg-neutral-950/95 backdrop-blur-md border border-neutral-800 rounded-lg p-3 shadow-2xl font-mono text-white flex items-center justify-between animate-in slide-in-from-bottom duration-300">
      <div className="flex items-center gap-3 overflow-hidden">
        <div
          className={`text-base font-light tracking-tight shrink-0 ${
            isLowTime ? 'text-rose-400 animate-pulse font-bold' : 'text-amber-400'
          }`}
        >
          {timeFormatted}
        </div>

        <div className="overflow-hidden text-left">
          <div className="text-xs text-neutral-200 truncate font-medium">
            {activeSession.app.name}
          </div>
          <div className="text-[10px] text-neutral-500 truncate">
            {activeSession.declaredIntent || "Intentional Session"}
          </div>
        </div>
      </div>

      <button
        onClick={() => endActiveSession(true)}
        className="shrink-0 flex items-center gap-1.5 px-2.5 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white text-xs rounded border border-neutral-800 transition-colors cursor-pointer"
      >
        <CheckCircle2 size={13} className="text-emerald-400" />
        <span>Done</span>
      </button>
    </div>
  );
};
