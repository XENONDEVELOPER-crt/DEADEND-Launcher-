/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useDeadend } from '../context/DeadendContext';
import { StatusHeader } from './StatusHeader';
import { AppDrawer } from './AppDrawer';
import { FrictionInterceptorModal } from './FrictionInterceptorModal';
import { DeadlockScreen } from './DeadlockScreen';
import { ActiveSessionOverlay } from './ActiveSessionOverlay';
import { SimulatedAppView } from './SimulatedAppView';
import { UsageDashboard } from './UsageDashboard';
import { AndroidSpecViewer } from './AndroidSpecViewer';
import { SettingsModal } from './SettingsModal';
import { HealthCheckScreen } from './HealthCheckScreen';
import { NotificationDigestScreen } from './NotificationDigestScreen';
import { HomeBanner } from './HomeBanner';
import { PendingUnlocksBanner } from './PendingUnlocksBanner';
import { RationaleModal } from './RationaleModal';
import { MetricsComponent } from './MetricsComponent';
import {
  Maximize2,
  Minimize2,
  BarChart2,
  Code2,
  Settings,
  Home,
  ShieldAlert,
  RotateCcw,
  Activity,
  Bell,
  Bluetooth
} from 'lucide-react';

export const PhoneContainer: React.FC = () => {
  const {
    viewMode,
    setViewMode,
    phoneFrameMode,
    setPhoneFrameMode,
    deadlockState,
    armDeadlock,
    disarmDeadlock,
    simulateMidnightReset,
    supporterAesthetics,
    isMonolithBleConnected,
    toggleMonolithBle
  } = useDeadend();

  // Font family class from supporter aesthetics
  const getFontClass = () => {
    if (!supporterAesthetics.isUnlocked) return 'font-mono';
    switch (supporterAesthetics.selectedFont) {
      case 'space_grotesk': return 'font-sans';
      case 'ibm_plex': return 'font-sans';
      case 'serif': return 'font-serif';
      default: return 'font-mono';
    }
  };

  return (
    <div className={`min-h-screen w-full bg-neutral-950 flex flex-col items-center justify-between text-neutral-100 select-none ${getFontClass()}`}>
      {/* Top Studio Control Bar */}
      <header className="w-full bg-black border-b border-neutral-900 px-4 py-2.5 flex items-center justify-between text-xs z-20">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
            <span className="font-bold tracking-widest text-white text-[11px]">
              DEADEND
            </span>
          </div>
          <span className="text-neutral-700 hidden sm:inline">|</span>
          <span className="text-[11px] text-neutral-500 hidden sm:inline">
            ZERO-INTERNET ON-DEVICE LAUNCHER
          </span>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex items-center gap-1 bg-neutral-900/80 p-0.5 rounded border border-neutral-800 text-[11px] overflow-x-auto no-scrollbar">
          <button
            onClick={() => setViewMode('launcher')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded transition-colors cursor-pointer shrink-0 ${
              viewMode === 'launcher'
                ? 'bg-neutral-800 text-white font-medium shadow-xs'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Home size={12} />
            <span className="hidden md:inline">Launcher</span>
          </button>

          <button
            onClick={() => setViewMode('health-check')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded transition-colors cursor-pointer shrink-0 ${
              viewMode === 'health-check'
                ? 'bg-neutral-800 text-amber-300 font-medium shadow-xs'
                : 'text-neutral-400 hover:text-white'
            }`}
            title="OEM Health Check & Background Resilience Diagnostics"
          >
            <Activity size={12} />
            <span className="hidden md:inline">Diagnostics</span>
          </button>

          <button
            onClick={() => setViewMode('digest')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded transition-colors cursor-pointer shrink-0 ${
              viewMode === 'digest'
                ? 'bg-neutral-800 text-sky-300 font-medium shadow-xs'
                : 'text-neutral-400 hover:text-white'
            }`}
            title="Scheduled Notification Batch Digest"
          >
            <Bell size={12} />
            <span className="hidden md:inline">Digest</span>
          </button>

          <button
            onClick={() => setViewMode('dashboard')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded transition-colors cursor-pointer shrink-0 ${
              viewMode === 'dashboard'
                ? 'bg-neutral-800 text-white font-medium shadow-xs'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <BarChart2 size={12} />
            <span className="hidden md:inline">Metrics</span>
          </button>

          <button
            onClick={() => setViewMode('android-spec')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded transition-colors cursor-pointer shrink-0 ${
              viewMode === 'android-spec'
                ? 'bg-neutral-800 text-amber-300 font-medium shadow-xs'
                : 'text-neutral-400 hover:text-amber-300'
            }`}
            title="Review Zero-Internet Manifest, RoleManager, and Kotlin architecture"
          >
            <Code2 size={12} />
            <span className="hidden md:inline">Android Spec</span>
          </button>

          <button
            onClick={() => setViewMode('settings')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded transition-colors cursor-pointer shrink-0 ${
              viewMode === 'settings'
                ? 'bg-neutral-800 text-white font-medium shadow-xs'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Settings size={12} />
            <span className="hidden md:inline">Config</span>
          </button>
        </div>

        {/* Quick Action Tools */}
        <div className="flex items-center gap-2">
          {!deadlockState.isActive ? (
            <button
              onClick={() => armDeadlock(60, "Instant 1-Hour Deadlock Focus")}
              className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 text-[11px] bg-rose-950/40 border border-rose-900/60 hover:bg-rose-900/50 text-rose-300 rounded transition-colors cursor-pointer"
              title="Arm Deadlock Mode immediately"
            >
              <ShieldAlert size={12} />
              <span>Arm Deadlock</span>
            </button>
          ) : (
            <div className="flex items-center gap-1 text-[11px] text-rose-400 font-bold animate-pulse px-2">
              <ShieldAlert size={12} />
              <span>DEADLOCK ACTIVE</span>
            </div>
          )}

          {/* Physical ESP32 DEADEND_PUCK Detection & Removal Triggers */}
          <div className="hidden sm:flex items-center gap-1.5">
            <button
              onClick={() => {
                if (typeof window !== 'undefined' && 'vibrate' in navigator) {
                  try {
                    navigator.vibrate(100);
                  } catch (e) {
                    // Ignore if vibration not permitted in iframe
                  }
                }
                toggleMonolithBle();
              }}
              className={`flex items-center gap-1.5 px-2.5 py-1 text-[11px] rounded transition-colors cursor-pointer border ${
                !isMonolithBleConnected
                  ? 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:text-white hover:border-neutral-700'
                  : 'bg-rose-950/50 border-rose-800 text-rose-300 hover:bg-rose-900/60'
              }`}
              title={
                !isMonolithBleConnected
                  ? "Detect ESP32 DEADEND_PUCK (UUID: 4fafc201-1fb5-459e-8fcc-c5c9c331914b). Directly triggers Deadlock mode."
                  : "Remove DEADEND_PUCK (UUID turns off). Automatically disarms Deadlock mode and restores launcher."
              }
            >
              <Bluetooth
                size={12}
                className={isMonolithBleConnected ? 'text-rose-400 animate-pulse' : 'text-neutral-400'}
              />
              <span className="hidden xl:inline">
                {!isMonolithBleConnected ? 'Detect DEADEND_PUCK (UUID On)' : 'Remove Puck (UUID Off)'}
              </span>
              <span className="xl:hidden">
                {!isMonolithBleConnected ? 'Detect Puck' : 'Remove Puck'}
              </span>
            </button>
          </div>

          <button
            onClick={simulateMidnightReset}
            className="hidden sm:flex items-center gap-1 px-2 py-1 text-[11px] bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white rounded border border-neutral-800 transition-colors cursor-pointer"
            title="Simulate daily midnight reset (clears today's counters and archives to Room DB)"
          >
            <RotateCcw size={11} />
            <span className="hidden xl:inline">Midnight Reset</span>
          </button>

          <button
            onClick={() => setPhoneFrameMode(!phoneFrameMode)}
            className="flex items-center gap-1 px-2.5 py-1 text-[11px] bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white rounded border border-neutral-800 transition-colors cursor-pointer"
            title={phoneFrameMode ? "Expand to Fullscreen View" : "Switch to Phone Frame Mockup"}
          >
            {phoneFrameMode ? <Maximize2 size={12} /> : <Minimize2 size={12} />}
            <span className="hidden sm:inline">{phoneFrameMode ? "Fullscreen" : "Phone Frame"}</span>
          </button>
        </div>
      </header>

      {/* State-Backed MetricsComponent rendered at the top of PhoneContainer */}
      <div className="w-full max-w-xl mx-auto z-10 px-2 sm:px-4 pt-1">
        <MetricsComponent />
      </div>

      {/* Main Content Area */}
      <main className="flex-1 w-full flex items-center justify-center p-0 sm:p-4 overflow-hidden relative">
        <div
          className={`relative bg-black transition-all duration-300 flex flex-col overflow-hidden ${
            phoneFrameMode
              ? 'w-full max-w-[400px] h-[780px] sm:h-[840px] rounded-[44px] border-[10px] border-neutral-800 shadow-[0_0_80px_rgba(0,0,0,0.9)] ring-1 ring-neutral-700/50'
              : 'w-full h-full max-w-full rounded-none border-none'
          }`}
        >
          {/* Phone Hardware Details */}
          {phoneFrameMode && (
            <div className="absolute top-2 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2 pointer-events-none">
              <div className="w-12 h-1 bg-neutral-800 rounded-full" />
              <div className="w-2.5 h-2.5 rounded-full bg-neutral-900 border border-neutral-800" />
            </div>
          )}

          {/* Device Screen Content */}
          <div className="flex-1 flex flex-col overflow-hidden relative pt-2">
            {viewMode === 'launcher' && (
              <>
                <StatusHeader />
                <HomeBanner />
                <PendingUnlocksBanner />
                <AppDrawer />
              </>
            )}

            {viewMode === 'health-check' && <HealthCheckScreen />}
            {viewMode === 'digest' && <NotificationDigestScreen />}
            {viewMode === 'dashboard' && <UsageDashboard />}
            {viewMode === 'android-spec' && <AndroidSpecViewer />}
            {viewMode === 'settings' && <SettingsModal />}

            {/* Simulated Active App Screen */}
            <SimulatedAppView />

            {/* Friction Interceptor Modal */}
            <FrictionInterceptorModal />

            {/* Deadlock Screen */}
            <DeadlockScreen />

            {/* Active Session Overlay */}
            <ActiveSessionOverlay />

            {/* Dynamic Permission Onboarding Rationale Modal */}
            <RationaleModal />
          </div>

          {/* Android Navigation Gesture Pill */}
          <div className="w-full py-2 flex justify-center items-center shrink-0">
            <div
              onClick={() => setViewMode('launcher')}
              className="w-32 h-1 bg-neutral-800 hover:bg-neutral-600 rounded-full cursor-pointer transition-colors"
              title="Home Gesture"
            />
          </div>
        </div>
      </main>
    </div>
  );
};
