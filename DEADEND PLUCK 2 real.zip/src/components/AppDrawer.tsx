/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useDeadend } from '../context/DeadendContext';
import { AppItem } from '../types/deadend';
import {
  Search,
  Pin,
  Shield,
  EyeOff,
  MoreHorizontal,
  X,
  Plus,
  Info,
  ArrowUpDown,
  Check
} from 'lucide-react';

export const AppDrawer: React.FC = () => {
  const {
    apps,
    handleAppClick,
    searchQuery,
    setSearchQuery,
    togglePinApp,
    toggleInterceptApp,
    toggleHideApp,
    mostRecentApp
  } = useDeadend();

  const [activeTab, setActiveTab] = useState<'all' | 'favorites' | 'friction'>('all');
  const [selectedAppMenu, setSelectedAppMenu] = useState<string | null>(null);
  const [isAddAppSheetOpen, setIsAddAppSheetOpen] = useState(false);
  const [addAppSearch, setAddAppSearch] = useState('');
  const [infoApp, setInfoApp] = useState<AppItem | null>(null);

  const searchInputRef = useRef<HTMLInputElement>(null);

  // Alphabet jump rail
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");

  // Pinned favorites (unlimited)
  const pinnedApps = useMemo(() => {
    return apps.filter(app => app.isPinned && !app.isHidden);
  }, [apps]);

  // Unpinned apps available to pin in bottom sheet
  const unpinnedApps = useMemo(() => {
    return apps.filter(app => !app.isPinned && !app.isHidden).filter(app => {
      if (!addAppSearch.trim()) return true;
      const q = addAppSearch.toLowerCase().trim();
      return app.name.toLowerCase().includes(q) || app.packageName.toLowerCase().includes(q);
    });
  }, [apps, addAppSearch]);

  // Filtered Apps for main list
  const filteredApps = useMemo(() => {
    let result = apps.filter(a => !a.isHidden);

    if (activeTab === 'favorites') {
      result = result.filter(a => a.isPinned);
    } else if (activeTab === 'friction') {
      result = result.filter(a => a.category === 'intercepted');
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(a =>
        a.name.toLowerCase().includes(q) ||
        (a.customLabel && a.customLabel.toLowerCase().includes(q)) ||
        a.description?.toLowerCase().includes(q)
      );
    }

    // Sort alphabetically
    return [...result].sort((a, b) => a.name.localeCompare(b.name));
  }, [apps, activeTab, searchQuery]);

  // Group by first letter for jump anchors
  const appsByLetter = useMemo(() => {
    const map = new Map<string, AppItem[]>();
    for (const app of filteredApps) {
      const firstLetter = app.name[0].toUpperCase();
      if (!map.has(firstLetter)) {
        map.set(firstLetter, []);
      }
      map.get(firstLetter)!.push(app);
    }
    return map;
  }, [filteredApps]);

  const scrollToLetter = (letter: string) => {
    const el = document.getElementById(`letter-group-${letter}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Keyboard Enter handler
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && filteredApps.length > 0) {
      handleAppClick(filteredApps[0]);
    } else if (e.key === 'Escape') {
      setSearchQuery('');
      searchInputRef.current?.blur();
    }
  };

  // Close context menu on outside click
  useEffect(() => {
    const handleDocumentClick = () => setSelectedAppMenu(null);
    window.addEventListener('click', handleDocumentClick);
    return () => window.removeEventListener('click', handleDocumentClick);
  }, []);

  return (
    <div className="flex flex-col flex-1 overflow-hidden px-6 pb-6 select-none relative font-mono">
      {/* Search Input Bar */}
      <div className="relative mb-3">
        <div className="flex items-center gap-2 border-b border-neutral-800 pb-2 focus-within:border-neutral-500 transition-colors">
          <Search size={15} className="text-neutral-500 shrink-0" />
          <input
            ref={searchInputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type to filter apps..."
            className="w-full bg-transparent text-sm text-neutral-200 placeholder-neutral-600 font-mono focus:outline-none"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="text-neutral-500 hover:text-neutral-300 p-0.5 cursor-pointer"
            >
              <X size={14} />
            </button>
          )}
        </div>
      </div>

      {/* Filter Tabs (Segmented functional controls) */}
      <div className="flex items-center gap-1 mb-3 text-xs font-mono">
        <button
          onClick={() => setActiveTab('all')}
          className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
            activeTab === 'all'
              ? 'bg-neutral-800 text-white font-medium'
              : 'text-neutral-500 hover:text-neutral-300'
          }`}
        >
          All ({apps.filter(a => !a.isHidden).length})
        </button>
        <button
          onClick={() => setActiveTab('favorites')}
          className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
            activeTab === 'favorites'
              ? 'bg-neutral-800 text-white font-medium'
              : 'text-neutral-500 hover:text-neutral-300'
          }`}
        >
          Pinned ({pinnedApps.length})
        </button>
        <button
          onClick={() => setActiveTab('friction')}
          className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
            activeTab === 'friction'
              ? 'bg-neutral-800 text-amber-300 font-medium'
              : 'text-neutral-500 hover:text-neutral-300'
          }`}
        >
          Intercepted ({apps.filter(a => a.category === 'intercepted').length})
        </button>
      </div>

      {/* Main Drawer Scrollable List & Letter Navigation */}
      <div className="flex-1 overflow-hidden relative flex">
        <div className="flex-1 overflow-y-auto pr-6 no-scrollbar space-y-5">
          {/* Quick Pinned Row if no search query and tab is all */}
          {activeTab === 'all' && !searchQuery.trim() && (
            <div className="mb-2">
              <div className="flex items-center justify-between text-[10px] tracking-widest text-neutral-600 uppercase mb-2">
                <span>PINNED ESSENTIALS ({pinnedApps.length})</span>
                <span className="text-neutral-700 font-mono">LONG-PRESS FOR OPTIONS</span>
              </div>

              <div className="flex flex-col space-y-0.5">
                {pinnedApps.map((app) => (
                  <div
                    key={`pinned-${app.id}`}
                    onClick={() => handleAppClick(app)}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      setSelectedAppMenu(`pinned-${app.id}`);
                    }}
                    className="group relative flex items-center justify-between py-2 px-1 hover:bg-neutral-900/60 rounded text-left transition-all cursor-pointer"
                  >
                    <span className="text-base tracking-tight text-white group-hover:text-amber-200 transition-colors font-medium">
                      {app.name}
                    </span>

                    <div className="flex items-center gap-2 text-xs text-neutral-600">
                      {mostRecentApp?.id === app.id && (
                        <span className="text-[10px] font-mono text-amber-400 font-bold bg-amber-950/40 border border-amber-900/60 px-1.5 py-0.5 rounded" title={`Most recent app: ${app.openCountToday} opens today`}>
                          {app.openCountToday}x
                        </span>
                      )}
                      {app.category === 'intercepted' && (
                        <span className="text-[10px] text-amber-400">· INT</span>
                      )}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedAppMenu(selectedAppMenu === `pinned-${app.id}` ? null : `pinned-${app.id}`);
                        }}
                        className="opacity-0 group-hover:opacity-100 text-neutral-500 hover:text-white p-1 transition-opacity cursor-pointer"
                        title="Pinned App Menu"
                      >
                        <MoreHorizontal size={14} />
                      </button>
                    </div>

                    {/* Pinned App Menu */}
                    {selectedAppMenu === `pinned-${app.id}` && (
                      <div
                        onClick={(e) => e.stopPropagation()}
                        className="absolute right-0 top-8 z-30 bg-neutral-950 border border-neutral-800 rounded-md shadow-xl py-1 px-1 text-xs text-neutral-300 min-w-[150px]"
                      >
                        <button
                          onClick={() => {
                            togglePinApp(app.id);
                            setSelectedAppMenu(null);
                          }}
                          className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-neutral-900 text-left text-neutral-300 cursor-pointer rounded"
                        >
                          <Pin size={12} className="rotate-45" />
                          <span>Unpin App</span>
                        </button>
                        <button
                          onClick={() => {
                            setInfoApp(app);
                            setSelectedAppMenu(null);
                          }}
                          className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-neutral-900 text-left text-neutral-300 cursor-pointer rounded"
                        >
                          <Info size={12} />
                          <span>App Info</span>
                        </button>
                        <button
                          onClick={() => {
                            toggleInterceptApp(app.id);
                            setSelectedAppMenu(null);
                          }}
                          className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-neutral-900 text-left text-neutral-300 cursor-pointer rounded"
                        >
                          <Shield size={12} />
                          <span>{app.category === 'intercepted' ? "Disable Friction" : "Enable Friction"}</span>
                        </button>
                      </div>
                    )}
                  </div>
                ))}

                {/* + Add App Button (at bottom of pinned list) */}
                <button
                  onClick={() => setIsAddAppSheetOpen(true)}
                  className="flex items-center gap-2 py-2 px-1 text-xs text-neutral-500 hover:text-amber-300 transition-colors cursor-pointer font-medium tracking-wide"
                >
                  <Plus size={14} />
                  <span>+ Add App to Pinned Essentials</span>
                </button>
              </div>

              <div className="border-b border-neutral-900 mt-3 mb-1" />
            </div>
          )}

          {/* Grouped Alphabetical List */}
          {filteredApps.length === 0 ? (
            <div className="py-12 text-center text-xs text-neutral-600">
              No applications found matching "{searchQuery}"
            </div>
          ) : (
            Array.from(appsByLetter.entries()).map(([letter, groupApps]) => (
              <div key={letter} id={`letter-group-${letter}`} className="space-y-1">
                <div className="text-[11px] font-semibold text-neutral-600 sticky top-0 bg-black/90 py-0.5 backdrop-blur-sm">
                  {letter}
                </div>
                <div className="flex flex-col space-y-0.5">
                  {groupApps.map((app) => (
                    <div
                      key={app.id}
                      className="group relative flex items-center justify-between py-2 px-1 hover:bg-neutral-900/60 rounded transition-all cursor-pointer"
                      onClick={() => handleAppClick(app)}
                      onContextMenu={(e) => {
                        e.preventDefault();
                        setSelectedAppMenu(app.id);
                      }}
                    >
                      <div className="flex items-baseline gap-2 overflow-hidden">
                        <span className="text-sm sm:text-base text-neutral-200 group-hover:text-white transition-colors truncate">
                          {app.name}
                        </span>
                        {app.description && (
                          <span className="text-[10px] text-neutral-600 truncate hidden sm:inline">
                            {app.description}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {app.category === 'intercepted' && (
                          <span className="text-[10px] text-amber-400/90 tracking-wider">
                            FRICTION
                          </span>
                        )}

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedAppMenu(selectedAppMenu === app.id ? null : app.id);
                          }}
                          className="opacity-0 group-hover:opacity-100 text-neutral-500 hover:text-neutral-200 p-1 transition-opacity cursor-pointer"
                          title="App Actions"
                        >
                          <MoreHorizontal size={14} />
                        </button>
                      </div>

                      {/* App context menu */}
                      {selectedAppMenu === app.id && (
                        <div
                          onClick={(e) => e.stopPropagation()}
                          className="absolute right-0 top-8 z-30 bg-neutral-950 border border-neutral-800 rounded-md shadow-xl py-1 px-1 text-xs text-neutral-300 min-w-[160px]"
                        >
                          <button
                            onClick={() => {
                              togglePinApp(app.id);
                              setSelectedAppMenu(null);
                            }}
                            className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-neutral-900 text-left cursor-pointer rounded"
                          >
                            <Pin size={12} />
                            <span>{app.isPinned ? "Unpin from top" : "Pin to top"}</span>
                          </button>
                          <button
                            onClick={() => {
                              setInfoApp(app);
                              setSelectedAppMenu(null);
                            }}
                            className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-neutral-900 text-left cursor-pointer rounded"
                          >
                            <Info size={12} />
                            <span>App Info</span>
                          </button>
                          <button
                            onClick={() => {
                              toggleInterceptApp(app.id);
                              setSelectedAppMenu(null);
                            }}
                            className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-neutral-900 text-left cursor-pointer rounded"
                          >
                            <Shield size={12} />
                            <span>
                              {app.category === 'intercepted'
                                ? "Disable Interception"
                                : "Enable Interception"}
                            </span>
                          </button>
                          <button
                            onClick={() => {
                              toggleHideApp(app.id);
                              setSelectedAppMenu(null);
                            }}
                            className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-neutral-900 text-left text-neutral-400 hover:text-rose-400 cursor-pointer rounded"
                          >
                            <EyeOff size={12} />
                            <span>Hide App</span>
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Alphabet Rail Fast-Scrub */}
        <div className="absolute right-0 top-0 bottom-0 flex flex-col justify-between py-1 text-[9px] text-neutral-600 select-none">
          {alphabet.map((letter) => {
            const hasApps = appsByLetter.has(letter);
            return (
              <button
                key={letter}
                onClick={() => scrollToLetter(letter)}
                disabled={!hasApps}
                className={`w-4 text-center cursor-pointer transition-colors ${
                  hasApps
                    ? "text-neutral-400 hover:text-white hover:font-bold"
                    : "text-neutral-800 cursor-default"
                }`}
              >
                {letter}
              </button>
            );
          })}
        </div>
      </div>

      {/* + Add App Searchable Bottom Sheet */}
      {isAddAppSheetOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end justify-center p-0 sm:p-4">
          <div className="w-full max-w-md bg-neutral-950 border border-neutral-800 rounded-t-2xl sm:rounded-2xl p-5 space-y-4 max-h-[80vh] flex flex-col shadow-2xl animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center justify-between border-b border-neutral-900 pb-3">
              <span className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Pin size={13} className="text-amber-400" />
                <span>Pin App to Essentials (Unlimited)</span>
              </span>
              <button
                onClick={() => setIsAddAppSheetOpen(false)}
                className="text-neutral-500 hover:text-neutral-300 text-xs cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Search Input */}
            <div className="relative">
              <input
                type="text"
                autoFocus
                placeholder="Search installed applications..."
                value={addAppSearch}
                onChange={(e) => setAddAppSearch(e.target.value)}
                className="w-full bg-black border border-neutral-800 text-xs px-3 py-2 rounded focus:border-amber-400 text-white focus:outline-none"
              />
            </div>

            {/* List of Apps to Pin */}
            <div className="flex-1 overflow-y-auto no-scrollbar space-y-1 pr-1 max-h-64">
              {unpinnedApps.length === 0 ? (
                <div className="py-8 text-center text-xs text-neutral-600">
                  No unpinned apps found matching "{addAppSearch}"
                </div>
              ) : (
                unpinnedApps.map((app) => (
                  <div
                    key={`sheet-${app.id}`}
                    onClick={() => {
                      togglePinApp(app.id);
                    }}
                    className="flex items-center justify-between p-2.5 bg-black hover:bg-neutral-900 border border-neutral-900 rounded cursor-pointer transition-colors"
                  >
                    <div>
                      <div className="text-xs font-medium text-white">{app.name}</div>
                      <div className="text-[10px] text-neutral-500">{app.packageName}</div>
                    </div>
                    <button
                      className="px-2.5 py-1 text-[10px] bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 rounded flex items-center gap-1"
                    >
                      <Plus size={11} />
                      <span>Pin</span>
                    </button>
                  </div>
                ))
              )}
            </div>

            <div className="pt-2 border-t border-neutral-900 flex justify-end">
              <button
                onClick={() => setIsAddAppSheetOpen(false)}
                className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-xs text-white rounded cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* App Info Modal */}
      {infoApp && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-xs w-full bg-neutral-950 border border-neutral-800 rounded-xl p-5 space-y-3 text-left">
            <div className="flex items-center justify-between border-b border-neutral-900 pb-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                App Details
              </span>
              <button
                onClick={() => setInfoApp(null)}
                className="text-neutral-500 hover:text-neutral-300 text-xs"
              >
                ✕
              </button>
            </div>

            <div className="space-y-1.5 text-xs text-neutral-300">
              <div>
                <span className="text-neutral-500 text-[10px] block uppercase">App Label</span>
                <span className="font-semibold text-white">{infoApp.name}</span>
              </div>
              <div>
                <span className="text-neutral-500 text-[10px] block uppercase">Package Name</span>
                <span className="text-[11px] text-neutral-400 break-all">{infoApp.packageName}</span>
              </div>
              <div>
                <span className="text-neutral-500 text-[10px] block uppercase">Category</span>
                <span className="capitalize">{infoApp.category}</span>
              </div>
              <div>
                <span className="text-neutral-500 text-[10px] block uppercase">Daily Usage Today</span>
                <span>{Math.round(infoApp.timeUsedTodaySeconds / 60)} minutes ({infoApp.openCountToday} launches)</span>
              </div>
              <div>
                <span className="text-neutral-500 text-[10px] block uppercase">Friction Status</span>
                <span className={infoApp.category === 'intercepted' ? 'text-amber-400' : 'text-neutral-400'}>
                  {infoApp.category === 'intercepted' ? 'Cost-Based Friction Shield Active' : 'Direct Launch (No Friction)'}
                </span>
              </div>
            </div>

            <button
              onClick={() => setInfoApp(null)}
              className="w-full mt-3 py-2 bg-neutral-900 hover:bg-neutral-800 text-xs text-white rounded cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
