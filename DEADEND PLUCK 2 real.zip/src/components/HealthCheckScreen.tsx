/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useDeadend } from '../context/DeadendContext';
import { OEMManufacturer, NavigationMode } from '../types/deadend';
import {
  ArrowLeft,
  ShieldCheck,
  ShieldAlert,
  BatteryCharging,
  Cpu,
  Layers,
  ExternalLink,
  Smartphone,
  RefreshCw,
  BellRing
} from 'lucide-react';

export const HealthCheckScreen: React.FC = () => {
  const {
    systemHealth,
    setSystemHealth,
    toggleSystemPermissionWithRationale,
    setViewMode
  } = useDeadend();

  const [simulatedFeedback, setSimulatedFeedback] = useState<string | null>(null);

  const triggerOemDeepLink = (actionName: string, componentTarget: string) => {
    setSimulatedFeedback(`Deep-link fired: Intent(Component="${componentTarget}")`);
    setTimeout(() => setSimulatedFeedback(null), 3500);
  };

  const handleSimulateRevocation = () => {
    setSystemHealth(prev => ({
      ...prev,
      isAccessibilityGranted: false,
      isBatteryOptimizationIgnored: false
    }));
    setSimulatedFeedback("Simulated OS Revocation Alert: Accessibility service was killed by OEM battery manager.");
    setTimeout(() => setSimulatedFeedback(null), 4000);
  };

  const subsystems = [
    {
      key: 'isRoleHomeHeld' as const,
      name: 'Default Home Launcher (ROLE_HOME)',
      desc: 'Handles system home button and swipe-up intents',
      granted: systemHealth.isRoleHomeHeld,
      api: 'RoleManager (API 29+)'
    },
    {
      key: 'isAccessibilityGranted' as const,
      name: 'Foreground App Detector',
      desc: 'Listens for TYPE_WINDOW_STATE_CHANGED to trigger friction gates',
      granted: systemHealth.isAccessibilityGranted,
      api: 'AccessibilityService'
    },
    {
      key: 'isNotificationListenerGranted' as const,
      name: 'Notification Batch Interceptor',
      desc: 'Suppresses distracting alerts and caches for scheduled digest',
      granted: systemHealth.isNotificationListenerGranted,
      api: 'NotificationListenerService'
    },
    {
      key: 'isUsageStatsGranted' as const,
      name: 'Usage Statistics Permission',
      desc: 'Tracks on-device minute limits and screen pickups',
      granted: systemHealth.isUsageStatsGranted,
      api: 'UsageStatsManager'
    },
    {
      key: 'isBatteryOptimizationIgnored' as const,
      name: 'Battery Optimization Whitelist',
      desc: 'Prevents aggressive OEM background process termination',
      granted: systemHealth.isBatteryOptimizationIgnored,
      api: 'PowerManager'
    }
  ];

  return (
    <div className="flex flex-col flex-1 overflow-hidden px-6 pb-6 text-white font-mono select-none">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-neutral-900 pb-4 mb-4">
        <button
          onClick={() => setViewMode('launcher')}
          className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft size={14} />
          <span>BACK TO LAUNCHER</span>
        </button>

        <span className="text-[10px] text-amber-400 uppercase tracking-widest font-semibold">
          OEM HEALTH DIAGNOSTICS
        </span>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar space-y-5">
        {/* Subsystems Overview Banner */}
        <div className="p-3.5 bg-neutral-950 border border-neutral-900 rounded space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-neutral-200 uppercase tracking-wider">
              Zero-Internet Process Integrity
            </span>
            <span className="text-[10px] text-emerald-400 font-bold">100% ON-DEVICE</span>
          </div>
          <p className="text-[11px] text-neutral-500 leading-relaxed">
            DEADEND never uses <code>android.permission.INTERNET</code>. All friction gates, batch digests, and analytics remain strictly on your physical hardware.
          </p>
        </div>

        {/* Feedback message banner if triggered */}
        {simulatedFeedback && (
          <div className="p-3 bg-amber-950/40 border border-amber-900/60 rounded text-xs text-amber-300 animate-in fade-in duration-200">
            {simulatedFeedback}
          </div>
        )}

        {/* Subsystem Health Grid */}
        <div className="space-y-2">
          <div className="text-[11px] text-neutral-500 uppercase tracking-wider">
            Required Android Subsystems
          </div>

          <div className="space-y-2">
            {subsystems.map((sub) => (
              <div
                key={sub.key}
                className="p-3 bg-neutral-950/80 border border-neutral-900 rounded flex items-center justify-between"
              >
                <div className="space-y-0.5 overflow-hidden pr-3">
                  <div className="flex items-center gap-2">
                    {sub.granted ? (
                      <ShieldCheck size={14} className="text-emerald-400 shrink-0" />
                    ) : (
                      <ShieldAlert size={14} className="text-rose-400 shrink-0" />
                    )}
                    <span className="text-xs text-neutral-200 font-medium truncate">
                      {sub.name}
                    </span>
                  </div>
                  <div className="text-[10px] text-neutral-500">
                    {sub.desc}
                  </div>
                </div>

                <button
                  onClick={() => toggleSystemPermissionWithRationale(sub.key)}
                  className={`text-[10px] px-2.5 py-1.5 rounded border transition-colors shrink-0 cursor-pointer ${
                    sub.granted
                      ? 'border-emerald-900/60 bg-emerald-950/30 text-emerald-400 hover:bg-emerald-900/40'
                      : 'border-rose-900/60 bg-rose-950/30 text-rose-300 hover:bg-rose-900/40'
                  }`}
                >
                  {sub.granted ? 'Active [Tap to revoke]' : 'Grant Just-in-Time'}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* OEM Deep-Linking Engine */}
        <div className="p-4 bg-neutral-950 border border-neutral-900 rounded space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-neutral-200 uppercase tracking-wider flex items-center gap-1.5">
              <Cpu size={13} className="text-amber-400" />
              <span>OEM Background Resilience Deep-Links</span>
            </span>
          </div>
          <p className="text-[11px] text-neutral-500">
            Targeted intents bypass aggressive battery killer routines on customized Android ROMs.
          </p>

          {/* OEM Selector */}
          <div className="flex flex-wrap gap-1.5 text-xs pt-1">
            {(['xiaomi', 'samsung', 'oppo', 'oneplus', 'google'] as OEMManufacturer[]).map((oem) => (
              <button
                key={oem}
                onClick={() => setSystemHealth(prev => ({ ...prev, detectedManufacturer: oem }))}
                className={`px-2.5 py-1 rounded border uppercase text-[10px] transition-colors cursor-pointer ${
                  systemHealth.detectedManufacturer === oem
                    ? 'border-white bg-neutral-900 text-white font-bold'
                    : 'border-neutral-800 text-neutral-500 hover:text-neutral-300'
                }`}
              >
                {oem}
              </button>
            ))}
          </div>

          {/* Deep link action buttons based on selected OEM */}
          <div className="pt-2 space-y-2">
            {systemHealth.detectedManufacturer === 'xiaomi' && (
              <div className="space-y-1.5">
                <button
                  onClick={() => triggerOemDeepLink("Xiaomi AutoStart", "com.miui.securitycenter/com.miui.permcenter.autostart.AutoStartManagementActivity")}
                  className="w-full flex items-center justify-between p-2 bg-black border border-neutral-800 hover:border-neutral-600 rounded text-xs text-neutral-300 cursor-pointer"
                >
                  <span>Open MIUI / HyperOS AutoStart Settings</span>
                  <ExternalLink size={12} className="text-amber-400" />
                </button>
                <button
                  onClick={() => triggerOemDeepLink("MIUI PowerKeeper", "com.miui.powerkeeper/com.miui.powerkeeper.ui.HiddenAppsConfigActivity")}
                  className="w-full flex items-center justify-between p-2 bg-black border border-neutral-800 hover:border-neutral-600 rounded text-xs text-neutral-300 cursor-pointer"
                >
                  <span>Configure No Restrictions in PowerKeeper</span>
                  <ExternalLink size={12} className="text-amber-400" />
                </button>
              </div>
            )}

            {systemHealth.detectedManufacturer === 'samsung' && (
              <button
                onClick={() => triggerOemDeepLink("Samsung Device Care", "com.samsung.android.lool/com.samsung.android.sm.battery.ui.BatteryActivity")}
                className="w-full flex items-center justify-between p-2 bg-black border border-neutral-800 hover:border-neutral-600 rounded text-xs text-neutral-300 cursor-pointer"
              >
                <span>Open Samsung One UI Battery Optimization</span>
                <ExternalLink size={12} className="text-amber-400" />
              </button>
            )}

            {systemHealth.detectedManufacturer === 'oppo' && (
              <button
                onClick={() => triggerOemDeepLink("ColorOS SafeCenter", "com.coloros.safecenter/com.coloros.safecenter.permission.startup.StartupAppListActivity")}
                className="w-full flex items-center justify-between p-2 bg-black border border-neutral-800 hover:border-neutral-600 rounded text-xs text-neutral-300 cursor-pointer"
              >
                <span>Open ColorOS / Realme Startup App Whitelist</span>
                <ExternalLink size={12} className="text-amber-400" />
              </button>
            )}

            {systemHealth.detectedManufacturer === 'oneplus' && (
              <button
                onClick={() => triggerOemDeepLink("OxygenOS ChainLaunch", "com.oneplus.security/com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity")}
                className="w-full flex items-center justify-between p-2 bg-black border border-neutral-800 hover:border-neutral-600 rounded text-xs text-neutral-300 cursor-pointer"
              >
                <span>Open OxygenOS Chain Launch Protection</span>
                <ExternalLink size={12} className="text-amber-400" />
              </button>
            )}

            {systemHealth.detectedManufacturer === 'google' && (
              <div className="p-2 bg-black border border-neutral-900 rounded text-[11px] text-neutral-400">
                Stock Android / Pixel OS: Uses standard AOSP battery optimization without aggressive OEM task killers.
              </div>
            )}
          </div>
        </div>

        {/* Foreground Keep-Alive & Revocation Test */}
        <div className="p-3.5 bg-neutral-950 border border-neutral-900 rounded flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-neutral-200">
              Low-RAM KeepAlive Foreground Service
            </div>
            <div className="text-[10px] text-neutral-500">
              Persistent notification: "DEADEND Guard Active"
            </div>
          </div>

          <button
            onClick={handleSimulateRevocation}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs bg-neutral-900 hover:bg-neutral-800 text-rose-300 rounded border border-neutral-800 cursor-pointer"
          >
            <RefreshCw size={11} />
            <span>Test OS Revocation Alert</span>
          </button>
        </div>
      </div>
    </div>
  );
};
