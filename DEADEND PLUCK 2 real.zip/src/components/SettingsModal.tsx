/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useDeadend } from '../context/DeadendContext';
import { CustomFontFamily, AccentShade } from '../types/deadend';
import {
  ArrowLeft,
  Volume2,
  VolumeX,
  Type,
  Palette,
  Clock,
  ShieldCheck,
  Check
} from 'lucide-react';

export const SettingsModal: React.FC = () => {
  const {
    frictionConfig,
    updateFrictionConfig,
    setViewMode,
    apps,
    toggleInterceptApp,
    supporterAesthetics,
    updateSupporterAesthetics
  } = useDeadend();

  const fonts: { key: CustomFontFamily; label: string; desc: string }[] = [
    { key: 'jetbrains_mono', label: 'JetBrains Mono', desc: 'Raw developer brutalism' },
    { key: 'space_grotesk', label: 'Space Grotesk', desc: 'Minimalist industrial sans' },
    { key: 'ibm_plex', label: 'IBM Plex Sans', desc: 'Modernist corporate neutrality' },
    { key: 'serif', label: 'Editorial Serif', desc: 'Literary quiet' }
  ];

  const accents: { key: AccentShade; label: string; colorClass: string }[] = [
    { key: 'pure_white', label: 'Pure Titanium', colorClass: 'bg-white' },
    { key: 'amber_sand', label: 'Cyber Amber', colorClass: 'bg-amber-400' },
    { key: 'tokyo_slate', label: 'Tokyo Slate', colorClass: 'bg-slate-400' },
    { key: 'cyber_cyan', label: 'Neon Cyan', colorClass: 'bg-cyan-400' },
    { key: 'forest_emerald', label: 'Nordic Forest', colorClass: 'bg-emerald-400' }
  ];

  return (
    <div className="flex flex-col flex-1 overflow-hidden px-6 pb-6 text-white font-mono select-none">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-neutral-900 pb-4 mb-4">
        <button
          onClick={() => setViewMode('launcher')}
          className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft size={14} />
          <span>BACK TO LAUNCHER</span>
        </button>

        <span className="text-[10px] text-neutral-500 uppercase tracking-widest">
          SYSTEM CONFIGURATION
        </span>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar space-y-5">
        {/* 100% Free & Open Promise */}
        <div className="p-3 bg-neutral-950 border border-neutral-900 rounded space-y-1">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400">
            <ShieldCheck size={13} />
            <span>100% Free &amp; Unrestricted Architecture</span>
          </div>
          <p className="text-[11px] text-neutral-500 leading-relaxed">
            No paywalls, subscriptions, or feature locks. Unlimited pinned apps, all friction gates, and full aesthetic customizations are completely free forever.
          </p>
        </div>

        {/* Breathing countdown duration (10 to 30 seconds) */}
        <div className="border border-neutral-900 bg-neutral-950/60 p-4 rounded space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-neutral-200">
              Mandatory Breath Delay (10-30s)
            </span>
            <span className="text-xs text-amber-400 font-bold">
              {frictionConfig.breathingDurationSeconds} Seconds
            </span>
          </div>
          <p className="text-[11px] text-neutral-500">
            Non-skippable countdown that halts unconscious impulse before unlocking intent dialog.
          </p>
          <div className="flex gap-2 pt-1">
            {[10, 15, 20, 30].map((sec) => (
              <button
                key={sec}
                onClick={() => updateFrictionConfig({ breathingDurationSeconds: sec })}
                className={`flex-1 py-1.5 text-xs rounded border transition-colors cursor-pointer ${
                  frictionConfig.breathingDurationSeconds === sec
                    ? 'border-white bg-neutral-900 text-white font-bold'
                    : 'border-neutral-800 text-neutral-400 hover:border-neutral-700'
                }`}
              >
                {sec}s
              </button>
            ))}
          </div>
        </div>

        {/* Typography Styling (100% Free) */}
        <div className="border border-neutral-900 bg-neutral-950/60 p-4 rounded space-y-2">
          <span className="text-xs font-semibold text-neutral-200 flex items-center gap-1.5">
            <Type size={13} className="text-amber-400" />
            <span>Monochrome Typeface Styling</span>
          </span>
          <div className="grid grid-cols-2 gap-2 pt-1">
            {fonts.map((f) => {
              const isSelected = supporterAesthetics.selectedFont === f.key;
              return (
                <button
                  key={f.key}
                  onClick={() => updateSupporterAesthetics({ selectedFont: f.key, isUnlocked: true })}
                  className={`p-2.5 rounded border text-left text-xs transition-colors cursor-pointer ${
                    isSelected
                      ? 'border-white bg-neutral-900 text-white font-medium'
                      : 'border-neutral-800 text-neutral-400 hover:border-neutral-700'
                  }`}
                >
                  <div className="font-semibold text-[11px]">{f.label}</div>
                  <div className="text-[9px] text-neutral-500 mt-0.5">{f.desc}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* OLED Accent Shades (100% Free) */}
        <div className="border border-neutral-900 bg-neutral-950/60 p-4 rounded space-y-2">
          <span className="text-xs font-semibold text-neutral-200 flex items-center gap-1.5">
            <Palette size={13} className="text-sky-400" />
            <span>OLED Accent Highlights</span>
          </span>
          <div className="flex items-center gap-2 pt-1">
            {accents.map((acc) => {
              const isSelected = supporterAesthetics.selectedAccent === acc.key;
              return (
                <button
                  key={acc.key}
                  onClick={() => updateSupporterAesthetics({ selectedAccent: acc.key, isUnlocked: true })}
                  className={`w-9 h-9 rounded-full border-2 flex items-center justify-center transition-all cursor-pointer ${
                    isSelected
                      ? 'border-white scale-110 shadow-sm'
                      : 'border-transparent hover:border-neutral-700'
                  } ${acc.colorClass}`}
                  title={acc.label}
                >
                  {isSelected && <Check size={14} className="text-black" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* 15-Minute Anti-Self-Sabotage Time Lock */}
        <div className="border border-neutral-900 bg-neutral-950/60 p-4 rounded space-y-1.5">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-rose-300">
            <Clock size={13} className="text-rose-400" />
            <span>15-Minute Anti-Self-Sabotage Lock</span>
          </div>
          <p className="text-[11px] text-neutral-400 leading-relaxed">
            Removing an app from the friction list or increasing its minute budget queues a strict 15-minute cool-down delay before the change takes effect.
          </p>
        </div>

        {/* Sound & Haptics */}
        <div className="border border-neutral-900 bg-neutral-950/60 p-4 rounded flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-neutral-200">
              Web Audio &amp; Tactile Feedback
            </div>
            <div className="text-[11px] text-neutral-500">
              Resonant breath bowls, mechanical clicks, and warning chimes.
            </div>
          </div>
          <button
            onClick={() => updateFrictionConfig({ soundEnabled: !frictionConfig.soundEnabled })}
            className="p-2 bg-neutral-900 border border-neutral-800 rounded hover:text-white text-neutral-400 cursor-pointer"
          >
            {frictionConfig.soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>
        </div>

        {/* Intercepted Apps Manager with 15-Minute Lockout Warning */}
        <div className="border border-neutral-900 bg-neutral-950/60 p-4 rounded space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-neutral-200">
              Manage Intercepted Apps ({apps.filter(a => a.category === 'intercepted').length})
            </span>
          </div>
          <p className="text-[11px] text-neutral-500">
            Toggling off friction triggers the intentional 15-minute cool-down delay to stop impulsive surrender.
          </p>

          <div className="space-y-1.5 max-h-48 overflow-y-auto no-scrollbar pr-1">
            {apps.map((app) => (
              <div
                key={app.id}
                className="flex items-center justify-between p-2 bg-black border border-neutral-900 rounded text-xs"
              >
                <div className="flex items-center gap-2">
                  <span className={app.category === 'intercepted' ? "text-amber-400 font-medium" : "text-neutral-400"}>
                    {app.name}
                  </span>
                  <span className="text-[10px] text-neutral-600">
                    {app.category}
                  </span>
                </div>

                <button
                  onClick={() => toggleInterceptApp(app.id)}
                  className={`text-[10px] px-2.5 py-1 rounded border transition-colors cursor-pointer ${
                    app.category === 'intercepted'
                      ? 'border-amber-500/50 bg-amber-950/30 text-amber-300'
                      : 'border-neutral-800 text-neutral-500 hover:text-neutral-300'
                  }`}
                >
                  {app.category === 'intercepted' ? 'Intercepting' : 'No Friction'}
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
