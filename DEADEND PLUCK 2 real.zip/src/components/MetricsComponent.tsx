/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useDeadend } from '../context/DeadendContext';
import { audio } from '../utils/audio';
import { ShieldCheck, Clock, Zap } from 'lucide-react';

export const MetricsComponent: React.FC = () => {
  const { dayStats, setViewMode } = useDeadend();

  const minutesSaved = Math.round(dayStats.timeSavedSeconds / 60);
  const pickups = dayStats.pickupsCount;
  const urgesIntercepted = dayStats.interceptionsAborted;

  const handleMetricClick = () => {
    audio.playClick();
    setViewMode('dashboard');
  };

  return (
    <div
      onClick={handleMetricClick}
      title="Tap to open detailed daily metrics dashboard"
      className="w-full bg-black border-b border-neutral-900/80 px-4 py-2 flex items-center justify-between text-xs font-mono select-none hover:bg-neutral-950/60 transition-colors cursor-pointer"
    >
      {/* 1. PICKUPS */}
      <div className="flex items-center gap-1.5 flex-1 justify-center sm:justify-start">
        <Zap size={11} className="text-neutral-500 shrink-0" />
        <span className="text-[10px] text-neutral-500 uppercase tracking-widest font-semibold">
          PICKUPS:
        </span>
        <span className="text-xs font-semibold text-white tracking-tight">
          {pickups}
        </span>
      </div>

      <span className="text-neutral-800 hidden sm:inline" aria-hidden="true">|</span>

      {/* 2. MINUTES SAVED */}
      <div className="flex items-center gap-1.5 flex-1 justify-center">
        <Clock size={11} className="text-emerald-400 shrink-0" />
        <span className="text-[10px] text-neutral-500 uppercase tracking-widest font-semibold">
          MINUTES SAVED:
        </span>
        <span className="text-xs font-semibold text-emerald-400 tracking-tight">
          +{minutesSaved}M
        </span>
      </div>

      <span className="text-neutral-800 hidden sm:inline" aria-hidden="true">|</span>

      {/* 3. URGES INTERCEPTED */}
      <div className="flex items-center gap-1.5 flex-1 justify-center sm:justify-end">
        <ShieldCheck size={11} className="text-amber-400 shrink-0" />
        <span className="text-[10px] text-neutral-500 uppercase tracking-widest font-semibold">
          URGES INTERCEPTED:
        </span>
        <span className="text-xs font-semibold text-amber-300 tracking-tight">
          {urgesIntercepted}
        </span>
      </div>
    </div>
  );
};
