/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useDeadend } from '../context/DeadendContext';
import { ShieldAlert, Volume2, VolumeX, Moon } from 'lucide-react';

export const StatusHeader: React.FC = () => {
  const {
    dayStats,
    deadlockState,
    frictionConfig,
    updateFrictionConfig,
    armDeadlock,
    mostRecentApp,
    handleAppClick,
    isMonolithBleConnected,
    toggleMonolithBle
  } = useDeadend();

  const [time, setTime] = useState<Date>(new Date());
  const [batteryLevel] = useState<number>(87);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const hours = time.getHours().toString().padStart(2, '0');
  const minutes = time.getMinutes().toString().padStart(2, '0');
  const seconds = time.getSeconds().toString().padStart(2, '0');

  const days = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
  const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
  const dateString = `${days[time.getDay()]}, ${time.getDate()} ${months[time.getMonth()]}`;

  const minutesSaved = Math.round(dayStats.timeSavedSeconds / 60);

  return (
    <header className="px-6 pt-6 pb-4 select-none">
      {/* Top minimal status bar */}
      <div className="flex items-center justify-between text-[11px] font-mono tracking-wider text-neutral-500 mb-6">
        <div className="flex items-center gap-2">
          <span className="text-neutral-300 font-semibold tracking-wider">DEADEND</span>
          <span>·</span>
          <span className="text-neutral-500 text-[10px] tracking-widest uppercase">END YOUR ADDICTIONS</span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => updateFrictionConfig({ soundEnabled: !frictionConfig.soundEnabled })}
            className="text-neutral-500 hover:text-neutral-200 transition-colors cursor-pointer"
            title={frictionConfig.soundEnabled ? "Mute haptics & audio" : "Enable haptics & audio"}
          >
            {frictionConfig.soundEnabled ? <Volume2 size={13} /> : <VolumeX size={13} />}
          </button>

          {!deadlockState.isActive ? (
            <button
              onClick={() => armDeadlock(60, "Instant Focus Session")}
              className="flex items-center gap-1 text-neutral-500 hover:text-amber-400 transition-colors text-[10px] tracking-widest cursor-pointer"
              title="Arm Deadlock Emergency Mode"
            >
              <Moon size={11} />
              <span>LOCK</span>
            </button>
          ) : (
            <div className="flex items-center gap-1 text-rose-400 animate-pulse text-[10px]">
              <ShieldAlert size={12} />
              <span>DEADLOCK</span>
            </div>
          )}

          <span className="text-neutral-400">{batteryLevel}%</span>
        </div>
      </div>

      {/* DEADEND_PUCK BLE Desk Node Status line */}
      <div className="flex items-center justify-between text-[10px] font-mono tracking-wider mb-4 px-0.5">
        <div
          onClick={toggleMonolithBle}
          className="flex items-center gap-1.5 cursor-pointer hover:opacity-80 transition-opacity"
          title={
            isMonolithBleConnected
              ? "DEADEND_PUCK is DETECTED (UUID Active). Tap to remove puck (turns off UUID & disarms lockdown)."
              : "DEADEND_PUCK is REMOVED (UUID Off). Tap to place/detect puck on desk (directly enters Deadlock mode)."
          }
        >
          <span
            className={`w-1.5 h-1.5 rounded-full ${
              !isMonolithBleConnected
                ? 'bg-neutral-600'
                : deadlockState.isActive
                ? 'bg-rose-500 animate-pulse'
                : 'bg-emerald-400'
            }`}
          />
          <span
            className={
              !isMonolithBleConnected
                ? 'text-neutral-400 font-medium'
                : deadlockState.isActive
                ? 'text-rose-400 font-semibold'
                : 'text-emerald-400 font-medium'
            }
          >
            {!isMonolithBleConnected
              ? 'DEADEND_PUCK: REMOVED (UUID OFF)'
              : deadlockState.isActive
              ? 'DEADEND_PUCK: DETECTED [DEADLOCK ACTIVE]'
              : 'DEADEND_PUCK: DETECTED'}
          </span>
          <span className="text-neutral-700">·</span>
          <span className="text-neutral-500 hover:text-amber-300 transition-colors">
            {!isMonolithBleConnected ? 'TAP TO DETECT PUCK' : 'UUID 4fafc201 (TAP TO REMOVE)'}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {!isMonolithBleConnected ? (
            <span className="text-[9px] text-neutral-500 font-mono tracking-tighter">DESK NODE STANDBY</span>
          ) : (
            <span className="text-[9px] text-amber-500/90 font-mono tracking-tighter">HARDWARE TETHER</span>
          )}
          <span className="text-emerald-500/80">ZERO-INTERNET</span>
        </div>
      </div>

      {/* Hero Minimalist Clock */}
      <div className="flex flex-col">
        <div className="flex items-baseline gap-2">
          <h1 className="text-6xl sm:text-7xl font-light tracking-tighter text-white font-mono">
            {hours}:{minutes}
          </h1>
          <span className="text-xs font-mono text-neutral-600 font-light tracking-widest">
            :{seconds}
          </span>
        </div>

        {/* Date and Anti-dopamine metric row */}
        <div className="flex items-center flex-wrap gap-x-2 gap-y-1 mt-2 text-xs font-mono tracking-wide text-neutral-400">
          <span className="text-neutral-300 font-medium">{dateString}</span>
          <span className="text-neutral-600">·</span>
          <span>{dayStats.pickupsCount} PICKUPS</span>
          {minutesSaved > 0 && (
            <>
              <span className="text-neutral-600">·</span>
              <span className="text-emerald-400">+{minutesSaved}M SAVED</span>
            </>
          )}
          {dayStats.interceptionsAborted > 0 && (
            <>
              <span className="text-neutral-600">·</span>
              <span className="text-neutral-300">{dayStats.interceptionsAborted} URGES INTERCEPTED</span>
            </>
          )}
        </div>

        {/* Small number showing how many times you had opened the most recent app */}
        {mostRecentApp && (
          <div
            onClick={() => handleAppClick(mostRecentApp)}
            title={`Most recent: ${mostRecentApp.name} (${mostRecentApp.openCountToday} opens today) · Tap to launch`}
            className="inline-flex items-center gap-1.5 mt-3 py-1 px-2.5 bg-neutral-950 border border-neutral-900 rounded hover:border-neutral-700 transition-colors cursor-pointer text-xs font-mono w-fit"
          >
            <span className="text-[10px] text-neutral-500 uppercase tracking-widest">RECENT APP:</span>
            <span className="text-neutral-200 font-medium">{mostRecentApp.name}</span>
            <span className="text-neutral-700">·</span>
            <span className="text-amber-400 font-bold">{mostRecentApp.openCountToday}x</span>
            <span className="text-neutral-500 text-[10px]">opened today</span>
          </div>
        )}
      </div>
    </header>
  );
};
