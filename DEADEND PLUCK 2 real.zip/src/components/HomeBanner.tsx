/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useDeadend } from '../context/DeadendContext';
import { ShieldAlert, AlertTriangle, ArrowRight, X, Smartphone, Bluetooth } from 'lucide-react';

export const HomeBanner: React.FC = () => {
  const {
    systemHealth,
    requestHomeRole,
    dismissHomeBanner,
    dismissOemGestureWarning,
    setViewMode,
    autoDisarmedNotice,
    clearAutoDisarmedNotice
  } = useDeadend();

  const [showGestureGuide, setShowGestureGuide] = useState(false);

  const isRoleMissing = !systemHealth.isRoleHomeHeld && !systemHealth.roleHomeBannerDismissed;
  const isGestureRisk = (systemHealth.detectedManufacturer === 'xiaomi' || systemHealth.detectedManufacturer === 'oppo') &&
    systemHealth.navigationMode === 'gestural' &&
    !systemHealth.oemGestureWarningDismissed;

  return (
    <div className="px-6 pt-2 select-none space-y-2 font-mono">
      {/* Auto-Disarm on BLE Disconnect Banner */}
      {autoDisarmedNotice && (
        <div className="bg-emerald-950/40 border border-emerald-900/60 p-3 rounded text-xs flex items-center justify-between text-neutral-200 animate-in fade-in duration-200">
          <div className="flex items-center gap-2 overflow-hidden pr-2">
            <Bluetooth size={14} className="text-emerald-400 shrink-0 animate-pulse" />
            <span className="truncate text-[11px] text-emerald-300">
              {autoDisarmedNotice}
            </span>
          </div>
          <button
            onClick={clearAutoDisarmedNotice}
            className="text-neutral-500 hover:text-neutral-300 p-0.5 cursor-pointer shrink-0"
            title="Dismiss notice"
          >
            <X size={13} />
          </button>
        </div>
      )}

      {/* 1. RoleManager Handshake Alert Banner */}
      {isRoleMissing && (
        <div className="bg-amber-950/40 border border-amber-900/60 p-3 rounded text-xs flex items-center justify-between text-neutral-200 animate-in fade-in duration-200">
          <div className="flex items-center gap-2 overflow-hidden pr-2">
            <ShieldAlert size={15} className="text-amber-400 shrink-0" />
            <span className="truncate text-[11px]">
              DEADEND is not your default launcher.
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={requestHomeRole}
              className="text-[11px] font-bold text-amber-400 hover:text-amber-300 underline underline-offset-2 cursor-pointer"
            >
              RESTORE
            </button>
            <button
              onClick={dismissHomeBanner}
              className="text-neutral-500 hover:text-neutral-300 p-0.5 cursor-pointer"
              title="Dismiss banner"
            >
              <X size={13} />
            </button>
          </div>
        </div>
      )}

      {/* 2. OEM Gesture Navigation Glitch Warning (MIUI / HyperOS / ColorOS) */}
      {isGestureRisk && (
        <div className="bg-neutral-900/80 border border-neutral-800 p-3 rounded text-xs flex items-center justify-between text-neutral-300 animate-in fade-in duration-200">
          <div className="flex items-center gap-2 overflow-hidden pr-2">
            <AlertTriangle size={14} className="text-neutral-400 shrink-0" />
            <span className="truncate text-[11px]">
              {systemHealth.detectedManufacturer.toUpperCase()} gesture navigation can cause recents freezes.
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setShowGestureGuide(true)}
              className="text-[10px] text-neutral-400 hover:text-white underline cursor-pointer"
            >
              TIP
            </button>
            <button
              onClick={dismissOemGestureWarning}
              className="text-neutral-500 hover:text-neutral-300 p-0.5 cursor-pointer"
            >
              <X size={13} />
            </button>
          </div>
        </div>
      )}

      {/* Gesture Navigation Helper Modal */}
      {showGestureGuide && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-sm w-full bg-neutral-950 border border-neutral-800 rounded-lg p-5 space-y-4 text-left">
            <div className="flex items-center justify-between border-b border-neutral-900 pb-2">
              <span className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Smartphone size={13} className="text-amber-400" />
                <span>OEM Navigation Recommendation</span>
              </span>
              <button
                onClick={() => setShowGestureGuide(false)}
                className="text-neutral-500 hover:text-neutral-300 text-xs cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-neutral-400 leading-relaxed">
              Third-party Android launchers on Xiaomi (MIUI/HyperOS), Oppo, and Realme sometimes experience animation stutter or recents freezes with full gesture mode.
            </p>

            <div className="p-3 bg-black border border-neutral-900 rounded space-y-1.5 text-xs text-neutral-300">
              <div className="font-semibold text-neutral-200 text-[11px]">Recommended Fix:</div>
              <p className="text-[11px] text-neutral-400">
                1. Open Phone Settings → Display &amp; Gestures.<br />
                2. Set System Navigation to <strong>3-Button Navigation</strong> for fluid 120Hz transitions.
              </p>
            </div>

            <div className="flex justify-between items-center pt-2">
              <button
                onClick={() => {
                  setShowGestureGuide(false);
                  setViewMode('health-check');
                }}
                className="text-xs text-amber-400 hover:underline flex items-center gap-1"
              >
                <span>Open Health Diagnostics</span>
                <ArrowRight size={12} />
              </button>
              <button
                onClick={() => setShowGestureGuide(false)}
                className="px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-xs rounded text-white"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
