/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useDeadend } from '../context/DeadendContext';
import { RotateCcw, ShieldCheck, Clock, Zap, ArrowLeft, ArrowUpRight } from 'lucide-react';

export const UsageDashboard: React.FC = () => {
  const {
    dayStats,
    simulateMidnightReset,
    setViewMode
  } = useDeadend();

  const [filterType, setFilterType] = useState<'all' | 'aborted' | 'sessions'>('all');
  const [resetConfirm, setResetConfirm] = useState(false);

  const minutesSaved = Math.round(dayStats.timeSavedSeconds / 60);
  const minutesDistracted = Math.round(dayStats.distractingTimeSeconds / 60);

  const totalInterceptions = dayStats.interceptionsAborted + dayStats.interceptionsProceeded;
  const willpowerRatio = totalInterceptions > 0
    ? Math.round((dayStats.interceptionsAborted / totalInterceptions) * 100)
    : 100;

  const filteredLogs = dayStats.logs.filter(log => {
    if (filterType === 'aborted') return log.type === 'intercepted_aborted';
    if (filterType === 'sessions') return log.type === 'session_started' || log.type === 'session_completed';
    return true;
  });

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex flex-col flex-1 overflow-hidden px-6 pb-6 text-white font-mono select-none">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-neutral-900 pb-4 mb-6">
        <button
          onClick={() => setViewMode('launcher')}
          className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft size={14} />
          <span>BACK TO LAUNCHER</span>
        </button>

        <div className="text-right">
          <span className="text-[10px] text-neutral-500 uppercase tracking-widest">
            PERSISTENT METRICS
          </span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar space-y-6">
        {/* Core KPI metrics - zero pill formatting */}
        <div className="grid grid-cols-2 gap-4">
          <div className="border border-neutral-900 bg-neutral-950/60 p-4 rounded">
            <div className="text-[10px] tracking-widest text-neutral-500 uppercase mb-1">
              TIME RECLAIMED
            </div>
            <div className="text-3xl font-light text-emerald-400">
              +{minutesSaved}m
            </div>
            <div className="text-[11px] text-neutral-500 mt-1">
              via non-skippable friction
            </div>
          </div>

          <div className="border border-neutral-900 bg-neutral-950/60 p-4 rounded">
            <div className="text-[10px] tracking-widest text-neutral-500 uppercase mb-1">
              WILLPOWER INDEX
            </div>
            <div className="text-3xl font-light text-white">
              {willpowerRatio}%
            </div>
            <div className="text-[11px] text-neutral-500 mt-1">
              {dayStats.interceptionsAborted} impulses aborted
            </div>
          </div>

          <div className="border border-neutral-900 bg-neutral-950/60 p-4 rounded">
            <div className="text-[10px] tracking-widest text-neutral-500 uppercase mb-1">
              DEVICE PICKUPS
            </div>
            <div className="text-3xl font-light text-white">
              {dayStats.pickupsCount}
            </div>
            <div className="text-[11px] text-neutral-500 mt-1">
              screen wake sessions
            </div>
          </div>

          <div className="border border-neutral-900 bg-neutral-950/60 p-4 rounded">
            <div className="text-[10px] tracking-widest text-neutral-500 uppercase mb-1">
              SANCTIONED TIME
            </div>
            <div className="text-3xl font-light text-amber-300">
              {minutesDistracted}m
            </div>
            <div className="text-[11px] text-neutral-500 mt-1">
              spent under strict intent
            </div>
          </div>
        </div>

        {/* Midnight Reset Callout */}
        <div className="border border-neutral-900 bg-neutral-950/40 p-4 rounded flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-neutral-200">
              Midnight Reset Scheduler
            </div>
            <div className="text-[11px] text-neutral-500 mt-0.5">
              Room DB archives day stats at 00:00:00 &amp; wipes daily counters.
            </div>
          </div>

          {!resetConfirm ? (
            <button
              onClick={() => setResetConfirm(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 text-xs rounded border border-neutral-800 transition-colors cursor-pointer"
            >
              <RotateCcw size={12} />
              <span>Simulate Reset</span>
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  simulateMidnightReset();
                  setResetConfirm(false);
                }}
                className="px-2.5 py-1 bg-rose-700 hover:bg-rose-600 text-white text-xs rounded cursor-pointer"
              >
                Confirm Reset
              </button>
              <button
                onClick={() => setResetConfirm(false)}
                className="text-xs text-neutral-500 hover:text-neutral-300"
              >
                Cancel
              </button>
            </div>
          )}
        </div>

        {/* Chronological Event Timeline */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <div className="text-xs font-semibold text-neutral-300 uppercase tracking-wider">
              Intervention Timeline
            </div>

            {/* Filter buttons */}
            <div className="flex gap-1 text-[11px]">
              <button
                onClick={() => setFilterType('all')}
                className={`px-2 py-0.5 rounded cursor-pointer ${
                  filterType === 'all' ? 'bg-neutral-800 text-white' : 'text-neutral-500 hover:text-neutral-300'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilterType('aborted')}
                className={`px-2 py-0.5 rounded cursor-pointer ${
                  filterType === 'aborted' ? 'bg-neutral-800 text-emerald-400' : 'text-neutral-500 hover:text-neutral-300'
                }`}
              >
                Aborted Urges
              </button>
              <button
                onClick={() => setFilterType('sessions')}
                className={`px-2 py-0.5 rounded cursor-pointer ${
                  filterType === 'sessions' ? 'bg-neutral-800 text-amber-300' : 'text-neutral-500 hover:text-neutral-300'
                }`}
              >
                Sessions
              </button>
            </div>
          </div>

          {filteredLogs.length === 0 ? (
            <div className="py-8 text-center text-xs text-neutral-600 border border-neutral-950 rounded">
              No logged events in this view.
            </div>
          ) : (
            <div className="space-y-2">
              {filteredLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-3 bg-neutral-950/70 border border-neutral-900 rounded flex items-start justify-between text-xs"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-neutral-500 font-mono text-[10px]">
                        {formatTime(log.timestamp)}
                      </span>
                      <span className="text-neutral-600">·</span>
                      <span className="font-medium text-neutral-200">
                        {log.appName}
                      </span>
                      <span className="text-neutral-600">·</span>

                      {log.type === 'intercepted_aborted' && (
                        <span className="text-emerald-400 flex items-center gap-1 text-[10px]">
                          <ShieldCheck size={11} />
                          <span>URGE ABORTED</span>
                        </span>
                      )}
                      {log.type === 'session_started' && (
                        <span className="text-amber-400 text-[10px]">
                          BUDGETED ({log.allocatedMinutes}m)
                        </span>
                      )}
                      {log.type === 'session_completed' && (
                        <span className="text-neutral-400 text-[10px]">
                          COMPLETED ({Math.round((log.actualDurationSeconds || 0) / 60)}m)
                        </span>
                      )}
                      {log.type === 'deadlock_entered' && (
                        <span className="text-rose-400 text-[10px]">
                          DEADLOCK ARMED
                        </span>
                      )}
                    </div>

                    {log.declaredIntent && (
                      <div className="text-[11px] text-neutral-400 pl-4 border-l border-neutral-800 italic">
                        "{log.declaredIntent}"
                      </div>
                    )}
                  </div>

                  {log.timeSavedSeconds ? (
                    <span className="text-[11px] text-emerald-400 shrink-0 font-medium">
                      +{Math.round(log.timeSavedSeconds / 60)}m
                    </span>
                  ) : log.allocatedMinutes ? (
                    <span className="text-[11px] text-neutral-500 shrink-0">
                      {log.allocatedMinutes}m max
                    </span>
                  ) : null}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
