/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CodeFileSpec {
  path: string;
  category: 'build' | 'manifest' | 'core' | 'service' | 'ui' | 'res' | 'config' | 'receiver' | 'data';
  description: string;
  language: string;
  content: string;
}

export const ANDROID_FILES: CodeFileSpec[] = [
  // 1. Settings Gradle
  {
    path: "settings.gradle.kts",
    category: "config",
    description: "Project settings mapping Google, Maven Central, and Gradle Plugin Portal repositories.",
    language: "kotlin",
    content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "DEADEND"
include(":app")`
  },

  // 2. Root Build Gradle
  {
    path: "build.gradle.kts",
    category: "build",
    description: "Top-level Gradle build configuration declaring Android and Kotlin compiler plugins.",
    language: "kotlin",
    content: `plugins {
    id("com.android.application") version "8.7.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
    id("com.google.devtools.ksp") version "2.0.21-1.0.27" apply false
    id("com.google.dagger.hilt.android") version "2.51.1" apply false
}`
  },

  // 3. App-Level Build Gradle
  {
    path: "app/build.gradle.kts",
    category: "build",
    description: "App module build script using direct dependency versions (no missing libs.versions.toml catalog dependency).",
    language: "kotlin",
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
    id("com.google.dagger.hilt.android")
}

android {
    namespace = "io.deadend.launcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "io.deadend.launcher"
        minSdk = 26
        targetSdk = 35
        versionCode = 100
        versionName = "1.0.0-FREE"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.activity:activity-compose:1.9.3")

    implementation(platform("androidx.compose:compose-bom:2024.10.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.foundation:foundation")

    implementation("androidx.datastore:datastore-preferences:1.1.1")

    implementation("com.google.dagger:hilt-android:2.51.1")
    ksp("com.google.dagger:hilt-compiler:2.51.1")
    implementation("androidx.hilt:hilt-navigation-compose:1.2.0")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
}`
  },

  // 4. AndroidManifest.xml
  {
    path: "app/src/main/AndroidManifest.xml",
    category: "manifest",
    description: "Zero-Internet Manifest: strictly NO android.permission.INTERNET. Includes full <queries> block, RoleManager ROLE_HOME target, and all services.",
    language: "xml",
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <!-- CRITICAL: Zero-Internet Guarantee. android.permission.INTERNET is STRICTLY EXCLUDED. -->
    <!-- All processing, heuristics, notification digests, and app blockers execute 100% on-device. -->

    <!-- 1. Home Launcher & Device State Permissions -->
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />

    <!-- 2. Cost-Based Friction Shield & System Overlay -->
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission
        android:name="android.permission.PACKAGE_USAGE_STATS"
        tools:ignore="ProtectedPermissions" />

    <!-- 3. ESP32 "The Monolith" BLE Desk Node & Hardware Trigger Permissions -->
    <!-- neverForLocation guarantees zero location tracking and 100% on-device privacy -->
    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />
    <uses-permission
        android:name="android.permission.BLUETOOTH_SCAN"
        android:usesPermissionFlags="neverForLocation"
        tools:targetApi="s" />
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
    <uses-feature
        android:name="android.hardware.bluetooth_le"
        android:required="false" />

    <!-- 4. Full <queries> block to query all installed launchable apps on Android 11+ (API 30+) -->
    <queries>
        <intent>
            <action android:name="android.intent.action.MAIN" />
            <category android:name="android.intent.category.LAUNCHER" />
        </intent>
    </queries>

    <application
        android:name=".DeadendApplication"
        android:allowBackup="false"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.DeadendLauncher">

        <!-- 1. Primary Home Launcher Activity (RoleManager Target) -->
        <activity
            android:name=".ui.HomeScreen"
            android:exported="true"
            android:clearTaskOnLaunch="true"
            android:stateNotNeeded="true"
            android:launchMode="singleTask"
            android:screenOrientation="portrait"
            android:windowSoftInputMode="adjustPan">

            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.HOME" />
                <category android:name="android.intent.category.DEFAULT" />
            </intent-filter>
        </activity>

        <!-- 2. Cost-Based Friction Shield Full-Screen Activity -->
        <activity
            android:name=".ui.FrictionShieldActivity"
            android:exported="false"
            android:excludeFromRecents="true"
            android:launchMode="singleInstance"
            android:theme="@style/Theme.Deadend.TransparentOverlay"
            android:showOnLockScreen="true" />

        <!-- 3. Dedicated Foreground Accessibility Interception Service -->
        <service
            android:name=".services.DeadendAccessibilityService"
            android:exported="false"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>

        <!-- 4. Notification Interception & Scheduled Batch Digest -->
        <service
            android:name=".services.NotificationDigestService"
            android:exported="false"
            android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE">
            <intent-filter>
                <action android:name="android.service.notification.NotificationListenerService" />
            </intent-filter>
        </service>

        <!-- 5. Low-RAM Keep-Alive Foreground Service -->
        <service
            android:name=".services.KeepAliveService"
            android:exported="false"
            android:foregroundServiceType="specialUse">
            <property
                android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                android:value="DEADEND focus shield and background resilience guard" />
        </service>

        <!-- 6. Screen State & Lifecycle Resiliency Receiver -->
        <receiver
            android:name=".receiver.ScreenStateReceiver"
            android:exported="false">
            <intent-filter>
                <action android:name="android.intent.action.SCREEN_ON" />
                <action android:name="android.intent.action.USER_PRESENT" />
            </intent-filter>
        </receiver>

        <!-- 7. Deadlock Device Admin Receiver -->
        <receiver
            android:name=".receiver.DeadlockDeviceAdminReceiver"
            android:permission="android.permission.BIND_DEVICE_ADMIN"
            android:exported="true">
            <meta-data
                android:name="android.app.device_admin"
                android:resource="@xml/device_admin_policies" />
            <intent-filter>
                <action android:name="android.app.action.DEVICE_ADMIN_ENABLED" />
            </intent-filter>
        </receiver>

        <!-- 8. ESP32 Monolith BLE Desk Node Background Receiver Service -->
        <service
            android:name=".services.FocusNodeBleService"
            android:exported="false" />

    </application>
</manifest>`
  },

  // 5. DeadendApplication.kt
  {
    path: "app/src/main/kotlin/io/deadend/launcher/DeadendApplication.kt",
    category: "core",
    description: "Application entry class initializing Hilt Dependency Injection on device boot.",
    language: "kotlin",
    content: `package io.deadend.launcher

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class DeadendApplication : Application()`
  },

  // 6. themes.xml
  {
    path: "app/src/main/res/values/themes.xml",
    category: "res",
    description: "Styles defining Theme.DeadendLauncher and Theme.Deadend.TransparentOverlay for the launcher and friction shield.",
    language: "xml",
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.DeadendLauncher" parent="android:Theme.Material.NoActionBar">
        <item name="android:windowBackground">@android:color/black</item>
        <item name="android:statusBarColor">@android:color/black</item>
        <item name="android:navigationBarColor">@android:color/black</item>
    </style>
    <style name="Theme.Deadend.TransparentOverlay" parent="android:Theme.Translucent.NoTitleBar">
        <item name="android:windowBackground">@android:color/transparent</item>
        <item name="android:windowIsTranslucent">true</item>
        <item name="android:statusBarColor">@android:color/black</item>
        <item name="android:navigationBarColor">@android:color/black</item>
    </style>
</resources>`
  },

  // 7. device_admin_policies.xml
  {
    path: "app/src/main/res/xml/device_admin_policies.xml",
    category: "res",
    description: "Declares device administration policies for Deadlock emergency lockdown mode.",
    language: "xml",
    content: `<?xml version="1.0" encoding="utf-8"?>
<device-admin>
    <uses-policies>
        <force-lock />
    </uses-policies>
</device-admin>`
  },

  // 8. accessibility_service_config.xml
  {
    path: "app/src/main/res/xml/accessibility_service_config.xml",
    category: "res",
    description: "Accessibility service definition config for window-state change filtering.",
    language: "xml",
    content: `<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:accessibilityEventTypes="typeWindowStateChanged"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:notificationTimeout="50"
    android:canRetrieveWindowContent="false"
    android:description="@string/accessibility_service_description" />`
  },

  // 9. strings.xml
  {
    path: "app/src/main/res/values/strings.xml",
    category: "res",
    description: "Application strings, zero-internet declaration, and service descriptions.",
    language: "xml",
    content: `<resources>
    <string name="app_name">DEADEND</string>
    <string name="slogan">End your addictions</string>
    <string name="accessibility_service_description">Enforces cost-based friction countdown gates before distracting applications display.</string>
    <string name="device_admin_label">DEADEND Focus Administrator</string>
    <string name="device_admin_description">Enables Deadlock emergency lockdown mode for extreme deep work.</string>
</resources>`
  },

  // 10. HomeScreen.kt
  {
    path: "app/src/main/kotlin/io/deadend/launcher/ui/HomeScreen.kt",
    category: "ui",
    description: "Jetpack Compose Home Launcher rendering clock, live metrics, pinned essentials, and functional AddAppBottomSheet.",
    language: "kotlin",
    content: `package io.deadend.launcher.ui

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dagger.hilt.android.AndroidEntryPoint
import io.deadend.launcher.data.LauncherRepository
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

data class AppEntry(val label: String, val packageName: String)

@AndroidEntryPoint
class HomeScreen : ComponentActivity() {

    @Inject
    lateinit var repository: LauncherRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        setContent {
            val scope = rememberCoroutineScope()
            val pinnedPackages by repository.pinnedAppsFlow.collectAsState(initial = repository.defaultPinnedApps)
            val isFocusActive by repository.focusModeFlow.collectAsState(initial = false)
            val isDeadlockActive by repository.deadlockFlow.collectAsState(initial = false)
            var showAddSheet by remember { mutableStateOf(false) }

            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black),
                color = Color.Black
            ) {
                if (isDeadlockActive) {
                    // Darkens the entire interface and disables all apps except Phone and SMS
                    DeadlockScreenContent(
                        onLaunchPhone = { launchApp("com.google.android.dialer") },
                        onLaunchSms = { launchApp("com.google.android.apps.messaging") },
                        onEmergencyExit = {
                            scope.launch {
                                repository.disarmDeadlock()
                            }
                        }
                    )
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 24.dp, vertical = 20.dp)
                    ) {
                        TopStatusHeader(isFocusActive = isFocusActive)

                    Spacer(modifier = Modifier.height(16.dp))

                    ClockAndMetricsHeader(
                        pickups = 14,
                        minutesSaved = 45,
                        urgesIntercepted = 5
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    RecentAppOpenBadge(
                        appName = "Messages",
                        openCount = 5,
                        onClick = { launchApp("com.google.android.apps.messaging") }
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "PINNED ESSENTIALS (\${pinnedPackages.size})",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF737373),
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    @OptIn(ExperimentalFoundationApi::class)
                    LazyColumn(modifier = Modifier.weight(1f)) {
                        items(pinnedPackages.toList()) { pkg ->
                            val appLabel = getAppLabel(pkg)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .combinedClickable(
                                        onClick = { launchApp(pkg) },
                                        onLongClick = {
                                            scope.launch {
                                                repository.unpinApp(pkg)
                                            }
                                        }
                                    )
                                    .padding(vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = appLabel,
                                    fontSize = 17.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color.White
                                )
                                Text(
                                    text = "HOLD TO UNPIN",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF525252)
                                )
                            }
                        }

                        item {
                            Text(
                                text = "+ Add App to Pinned Essentials",
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFFFBBF24),
                                modifier = Modifier
                                    .clickable { showAddSheet = true }
                                    .padding(vertical = 12.dp)
                            )
                        }
                    }
                }

                if (showAddSheet) {
                    AddAppBottomSheet(
                        installedApps = getInstalledApps(),
                        onDismiss = { showAddSheet = false },
                        onAppSelected = { pkg ->
                            scope.launch {
                                repository.pinApp(pkg)
                            }
                            showAddSheet = false
                        }
                    )
                }
                }
            }
        }
    }

    private fun getAppLabel(packageName: String): String {
        return try {
            val info = packageManager.getApplicationInfo(packageName, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (e: Exception) {
            packageName.split(".").last().replaceFirstChar { it.uppercase() }
        }
    }

    private fun getInstalledApps(): List<AppEntry> {
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = packageManager.queryIntentActivities(intent, 0)
        return resolveInfos.map {
            AppEntry(
                label = it.loadLabel(packageManager).toString(),
                packageName = it.activityInfo.packageName
            )
        }.sortedBy { it.label }
    }

    private fun launchApp(packageName: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            startActivity(launchIntent)
        }
    }
}

@Composable
fun DeadlockScreenContent(
    onLaunchPhone: () -> Unit,
    onLaunchSms: () -> Unit,
    onEmergencyExit: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "DEADLOCK EMERGENCY PROTOCOL",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFF43F5E),
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "DEADEND_PUCK DETECTED · UUID 4fafc201-1fb5-459e-8fcc-c5c9c331914b",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFFFBBF24)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "HARDWARE LOCKDOWN ACTIVE · ALL DISTRACTION APPS BLOCKED",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFFA3A3A3)
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "EMERGENCY COMMUNICATIONS ONLY",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF525252),
                letterSpacing = 1.sp
            )

            Button(
                onClick = onLaunchPhone,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF171717))
            ) {
                Text("Phone Calls (com.google.android.dialer)", color = Color(0xFF4ADE80), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            }

            Button(
                onClick = onLaunchSms,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF171717))
            ) {
                Text("Emergency SMS (com.google.android.apps.messaging)", color = Color(0xFF38BDF8), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "Remove puck from desk (UUID off) to disarm lockdown",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF737373)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = onEmergencyExit,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262626)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Emergency Exit Override", color = Color(0xFFF43F5E), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun ClockAndMetricsHeader(pickups: Int, minutesSaved: Int, urgesIntercepted: Int) {
    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val dateFormat = remember { SimpleDateFormat("EEE, MMM dd", Locale.getDefault()) }
    val now = Date()

    Column {
        Text(
            text = timeFormat.format(now),
            fontSize = 64.sp,
            fontWeight = FontWeight.Light,
            fontFamily = FontFamily.Monospace,
            color = Color.White,
            letterSpacing = (-2).sp
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(top = 4.dp)
        ) {
            Text(
                text = dateFormat.format(now).uppercase(),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFFA3A3A3)
            )
            Text(text = "·", color = Color(0xFF525252))
            Text(
                text = "\$pickups PICKUPS",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFFA3A3A3)
            )
            Text(text = "·", color = Color(0xFF525252))
            Text(
                text = "+\$minutesSaved M SAVED",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF4ADE80)
            )
            Text(text = "·", color = Color(0xFF525252))
            Text(
                text = "\$urgesIntercepted URGES INTERCEPTED",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFFFBBF24)
            )
        }
    }
}

@Composable
fun RecentAppOpenBadge(appName: String, openCount: Int, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .background(Color(0xFF141414))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = "RECENT:",
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            color = Color(0xFF737373)
        )
        Text(
            text = appName,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            color = Color.White
        )
        Text(text = "·", color = Color.DarkGray)
        Text(
            text = "\${openCount}x opens today",
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            color = Color(0xFFFBBF24)
        )
    }
}

@Composable
fun TopStatusHeader(isFocusActive: Boolean = false) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "DEADEND",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Text(text = "·", color = Color.Gray)
                Text(
                    text = "END YOUR ADDICTIONS",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF737373)
                )
            }
            Text(
                text = "ZERO-INTERNET",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF4ADE80)
            )
        }

        // ESP32 "The Monolith" BLE Node Connection & Focus Status Indicator
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(if (isFocusActive) Color(0xFFFBBF24) else Color(0xFF4ADE80))
            )
            Text(
                text = if (isFocusActive) "MONOLITH: DEEP FOCUS ACTIVE [LOCK]" else "MONOLITH BLE: LINKED (4fafc201...)",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = if (isFocusActive) Color(0xFFFBBF24) else Color(0xFF737373)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddAppBottomSheet(
    installedApps: List<AppEntry>,
    onDismiss: () -> Unit,
    onAppSelected: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredApps = remember(searchQuery, installedApps) {
        if (searchQuery.isBlank()) installedApps
        else installedApps.filter {
            it.label.contains(searchQuery, ignoreCase = true) ||
            it.packageName.contains(searchQuery, ignoreCase = true)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF121212)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Text(
                text = "PIN APP TO ESSENTIALS",
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search installed applications...", fontSize = 12.sp) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(modifier = Modifier.heightIn(max = 340.dp)) {
                items(filteredApps) { app ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onAppSelected(app.packageName) }
                            .padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = app.label, fontSize = 14.sp, color = Color.White)
                            Text(text = app.packageName, fontSize = 10.sp, color = Color.Gray)
                        }
                        Text(text = "+ PIN", fontSize = 11.sp, color = Color(0xFFFBBF24))
                    }
                }
            }
        }
    }
}`
  },

  // 11. FrictionShieldActivity.kt
  {
    path: "app/src/main/kotlin/io/deadend/launcher/ui/FrictionShieldActivity.kt",
    category: "ui",
    description: "Full-screen cost-based friction shield enforcing non-skippable 10-second countdown, typed intent declaration, and session budget.",
    language: "kotlin",
    content: `package io.deadend.launcher.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dagger.hilt.android.AndroidEntryPoint
import io.deadend.launcher.data.LauncherRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class FrictionShieldActivity : ComponentActivity() {

    @Inject
    lateinit var repository: LauncherRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        val targetPackage = intent.getStringExtra(EXTRA_TARGET_PACKAGE) ?: ""
        val countdownSeconds = intent.getIntExtra(EXTRA_COUNTDOWN_SECONDS, 10)
        val isSubsequent = intent.getBooleanExtra(EXTRA_IS_SUBSEQUENT, false)

        setContent {
            val scope = rememberCoroutineScope()
            var remainingSeconds by remember { mutableStateOf(countdownSeconds) }
            val isBreathDone = remainingSeconds <= 0
            var typedReason by remember { mutableStateOf("") }
            var sessionMinutes by remember { mutableStateOf(5) }

            LaunchedEffect(Unit) {
                while (remainingSeconds > 0) {
                    delay(1000)
                    remainingSeconds--
                }
            }

            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black),
                color = Color.Black
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (isSubsequent) "[PERSISTENT 5S RE-ENTRY PAUSE]" else "[COST-BASED FRICTION SHIELD]",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFFFBBF24)
                    )

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = if (isBreathDone) "UNLOCKED" else "\${remainingSeconds}s",
                            fontSize = 64.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Light,
                            color = Color.White
                        )

                        Text(
                            text = if (!isBreathDone) "Breathe in slowly... Notice your unconscious urge."
                                   else "Declare your explicit reason for opening this app.",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFA3A3A3),
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )

                        if (isBreathDone) {
                            OutlinedTextField(
                                value = typedReason,
                                onValueChange = { typedReason = it },
                                placeholder = { Text("e.g. Checking urgent work email", fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(3, 5, 10, 15).forEach { mins ->
                                    Button(
                                        onClick = { sessionMinutes = mins },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (sessionMinutes == mins) Color.White else Color(0xFF262626)
                                        )
                                    ) {
                                        Text("\${mins}m", color = if (sessionMinutes == mins) Color.Black else Color.White)
                                    }
                                }
                            }
                        }
                    }

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { finish() },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White)
                        ) {
                            Text("ABORT & SAVE MY TIME (+15M RECLAIMED)", color = Color.Black)
                        }

                        Button(
                            onClick = {
                                if (isBreathDone && typedReason.isNotBlank()) {
                                    scope.launch {
                                        repository.grantSession(targetPackage, sessionMinutes)
                                        val launchIntent = packageManager.getLaunchIntentForPackage(targetPackage)
                                        if (launchIntent != null) {
                                            startActivity(launchIntent)
                                        }
                                        finish()
                                    }
                                }
                            },
                            enabled = isBreathDone && typedReason.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF171717))
                        ) {
                            Text("PROCEED WITH \${sessionMinutes}M SESSION", color = Color(0xFFA3A3A3))
                        }
                    }
                }
            }
        }
    }

    companion object {
        const val EXTRA_TARGET_PACKAGE = "extra_target_package"
        const val EXTRA_COUNTDOWN_SECONDS = "extra_countdown_seconds"
        const val EXTRA_IS_SUBSEQUENT = "extra_is_subsequent"
    }
}`
  },

  // 12. DeadendAccessibilityService.kt
  {
    path: "app/src/main/kotlin/io/deadend/launcher/services/DeadendAccessibilityService.kt",
    category: "service",
    description: "AccessibilityService detecting foreground transitions and enforcing non-skippable friction and 5-second re-entry pauses.",
    language: "kotlin",
    content: `package io.deadend.launcher.services

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import dagger.hilt.android.AndroidEntryPoint
import io.deadend.launcher.data.LauncherRepository
import io.deadend.launcher.ui.FrictionShieldActivity
import kotlinx.coroutines.*
import javax.inject.Inject

@AndroidEntryPoint
class DeadendAccessibilityService : AccessibilityService() {

    @Inject
    lateinit var repository: LauncherRepository

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val targetPackage = event.packageName?.toString() ?: return

        // 1. Never intercept launcher itself
        if (targetPackage == applicationContext.packageName) return

        // 2. Communication Whitelist: Phone and SMS must NEVER be intercepted by friction shield
        if (repository.isEmergencyAllowed(targetPackage)) return

        serviceScope.launch {
            if (repository.isDeadlockActive() || repository.isFocusModeActive()) {
                performGlobalAction(GLOBAL_ACTION_HOME)
                return@launch
            }

            if (repository.isAppRestricted(targetPackage)) {
                if (repository.hasActiveSession(targetPackage)) {
                    return@launch
                }

                val isSubsequentToday = repository.wasOpenedToday(targetPackage)
                val countdownSeconds = if (isSubsequentToday) 5 else 10

                performGlobalAction(GLOBAL_ACTION_HOME)
                val intent = Intent(applicationContext, FrictionShieldActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra(FrictionShieldActivity.EXTRA_TARGET_PACKAGE, targetPackage)
                    putExtra(FrictionShieldActivity.EXTRA_COUNTDOWN_SECONDS, countdownSeconds)
                    putExtra(FrictionShieldActivity.EXTRA_IS_SUBSEQUENT, isSubsequentToday)
                }
                startActivity(intent)
            }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}`
  },

  // 13. NotificationDigestService.kt
  {
    path: "app/src/main/kotlin/io/deadend/launcher/services/NotificationDigestService.kt",
    category: "service",
    description: "NotificationListenerService intercepting non-essential notifications, preserving priority contacts, and caching for scheduled batch digests.",
    language: "kotlin",
    content: `package io.deadend.launcher.services

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import dagger.hilt.android.AndroidEntryPoint
import io.deadend.launcher.data.LauncherRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class NotificationDigestService : NotificationListenerService() {

    @Inject
    lateinit var repository: LauncherRepository

    private val serviceScope = CoroutineScope(Dispatchers.IO)

    private val priorityWhitelist = setOf(
        "com.google.android.dialer",
        "com.android.phone",
        "com.google.android.deskclock",
        "com.google.android.calendar",
        "com.google.android.apps.messaging"
    )

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val packageName = sbn.packageName

        if (packageName == applicationContext.packageName) return
        // Emergency and priority whitelist: phone, sms, clock, calendar always bypass
        if (priorityWhitelist.contains(packageName) || repository.isEmergencyAllowed(packageName)) return

        val extras = sbn.notification.extras
        val title = extras.getString(Notification.EXTRA_TITLE) ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        if (sbn.isOngoing) return

        cancelNotification(sbn.key)

        serviceScope.launch {
            repository.cacheBatchedNotification(
                packageName = packageName,
                title = title,
                body = text,
                timestamp = sbn.postTime
            )
    }
}
`
  },

  // 14. FocusNodeBleService.kt
  {
    path: "app/src/main/kotlin/io/deadend/launcher/services/FocusNodeBleService.kt",
    category: "service",
    description: "ESP32 'DEADEND_PUCK' BLE listener for Service UUID 4fafc201-1fb5-459e-8fcc-c5c9c331914b and Characteristic UUID beb5483e-36e1-4688-b7f5-ea07361b26a8, receiving TOGGLE_FOCUS from physical RFID puck and triggering 100ms tactile vibration.",
    language: "kotlin",
    content: `package io.deadend.launcher.services

import android.annotation.SuppressLint
import android.app.Service
import android.bluetooth.*
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import android.os.ParcelUuid
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import dagger.hilt.android.AndroidEntryPoint
import io.deadend.launcher.data.LauncherRepository
import kotlinx.coroutines.*
import java.util.UUID
import javax.inject.Inject

@AndroidEntryPoint
class FocusNodeBleService : Service() {

    @Inject
    lateinit var repository: LauncherRepository

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothLeScanner: BluetoothLeScanner? = null
    private var bluetoothGatt: BluetoothGatt? = null
    private var isScanning = false
    private var isPaired = false

    private val localReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_TOGGLE_FOCUS -> {
                    serviceScope.launch {
                        val isLocked = repository.toggleDeadlockMode()
                        vibratePhone(100L)
                        Log.d(TAG, "ACTION_TOGGLE_FOCUS intent received. Deadlock active: \$isLocked")
                    }
                }
                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                    if (state == BluetoothAdapter.STATE_TURNING_OFF || state == BluetoothAdapter.STATE_OFF) {
                        Log.d(TAG, "Bluetooth turned off: connection to \$DEVICE_NAME lost. Exiting lockdown mode automatically...")
                        isPaired = false
                        serviceScope.launch {
                            repository.disarmDeadlock()
                            repository.setFocusMode(false)
                        }
                    } else if (state == BluetoothAdapter.STATE_ON) {
                        Log.d(TAG, "Bluetooth turned back on: restarting BLE scanner for \$DEVICE_NAME...")
                        startBleScanner(isPaired = false)
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        bluetoothAdapter = bluetoothManager?.adapter
        bluetoothLeScanner = bluetoothAdapter?.bluetoothLeScanner

        val filter = IntentFilter().apply {
            addAction(ACTION_TOGGLE_FOCUS)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(localReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(localReceiver, filter)
        }

        // Initialize BLE scanner in LOW_LATENCY mode while searching for DEADEND_PUCK
        startBleScanner(isPaired = false)
    }

    @SuppressLint("MissingPermission")
    private fun startBleScanner(isPaired: Boolean) {
        val scanner = bluetoothAdapter?.bluetoothLeScanner ?: return
        if (isScanning) {
            try {
                scanner.stopScan(scanCallback)
            } catch (e: Exception) {
                // Ignore
            }
            isScanning = false
        }

        // Configure ScanFilter with exact advertised device name and service UUID
        val scanFilter = ScanFilter.Builder()
            .setDeviceName(DEVICE_NAME)
            .setServiceUuid(ParcelUuid.fromString(SERVICE_UUID_STRING))
            .build()

        // Use SCAN_MODE_LOW_LATENCY when searching, drop to SCAN_MODE_LOW_POWER once paired
        val scanMode = if (isPaired) {
            ScanSettings.SCAN_MODE_LOW_POWER
        } else {
            ScanSettings.SCAN_MODE_LOW_LATENCY
        }

        val settings = ScanSettings.Builder()
            .setScanMode(scanMode)
            .build()

        try {
            scanner.startScan(listOf(scanFilter), settings, scanCallback)
            isScanning = true
            Log.d(TAG, "Monolith BLE scanner initiated for \$DEVICE_NAME (\${if (isPaired) "LOW_POWER" else "LOW_LATENCY"})")
        } catch (e: SecurityException) {
            Log.e(TAG, "BLE scan permission missing", e)
        }
    }

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            val device = result?.device ?: return
            Log.d(TAG, "Discovered \$DEVICE_NAME at address: \${device.address}. Connecting GATT...")

            // Stop scanner once device found
            try {
                bluetoothLeScanner?.stopScan(this)
                isScanning = false
            } catch (e: SecurityException) {
                Log.e(TAG, "Could not stop scan", e)
            }

            // Connect using autoConnect = false
            bluetoothGatt = device.connectGatt(this@FocusNodeBleService, false, gattCallback)
        }

        override fun onScanFailed(errorCode: Int) {
            Log.e(TAG, "BLE Scan failed with error code: \$errorCode")
            isScanning = false
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    Log.d(TAG, "Connected to $DEVICE_NAME GATT server (UUID $SERVICE_UUID_STRING detected). Directly arming Deadlock mode...")
                    isPaired = true

                    // DIRECTLY ENTER DEADLOCK MODE ON PUCK DETECTION
                    serviceScope.launch {
                        repository.armDeadlock(60)
                        repository.setFocusMode(true)
                    }
                    vibratePhone(100L)

                    gatt?.discoverServices()
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    Log.d(TAG, "Disconnected from $DEVICE_NAME (puck removed / UUID turned off). Automatically turning off Deadlock mode...")
                    isPaired = false
                    try {
                        bluetoothGatt?.close()
                        bluetoothGatt = null
                    } catch (e: Exception) {
                        // Ignore
                    }

                    // TURN OFF DEADLOCK AND RESTORE DEADEND LAUNCHER INTERFACE
                    serviceScope.launch {
                        repository.disarmDeadlock()
                        repository.setFocusMode(false)
                    }

                    // Restart scanner in LOW_LATENCY mode to reconnect when puck comes back in range
                    startBleScanner(isPaired = false)
                }
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS && gatt != null) {
                val service = gatt.getService(SERVICE_UUID)
                val characteristic = service?.getCharacteristic(CHARACTERISTIC_UUID)
                if (characteristic != null) {
                    // Enable notifications locally
                    val success = gatt.setCharacteristicNotification(characteristic, true)
                    Log.d(TAG, "setCharacteristicNotification success=\$success on \$CHARACTERISTIC_UUID_STRING")

                    // Locate and write Client Characteristic Configuration Descriptor (CCCD: 00002902-0000-1000-8000-00805f9b34fb)
                    val descriptor = characteristic.getDescriptor(CCCD_UUID)
                    if (descriptor != null) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            gatt.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                        } else {
                            @Suppress("DEPRECATION")
                            descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                            @Suppress("DEPRECATION")
                            gatt.writeDescriptor(descriptor)
                        }
                        Log.d(TAG, "CCCD descriptor written. Subscribed to \$DEVICE_NAME notifications.")
                    }

                    // Drop scanner to LOW_POWER once paired and connected
                    startBleScanner(isPaired = true)
                } else {
                    Log.w(TAG, "Characteristic \$CHARACTERISTIC_UUID_STRING not found on \$DEVICE_NAME")
                }
            }
        }

        @Deprecated("Used for compatibility across Android SDK levels")
        override fun onCharacteristicChanged(gatt: BluetoothGatt?, characteristic: BluetoothGattCharacteristic?) {
            @Suppress("DEPRECATION")
            handleCharacteristicUpdate(characteristic?.value)
        }

        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            handleCharacteristicUpdate(value)
        }
    }

    private fun handleCharacteristicUpdate(rawPayload: ByteArray?) {
        if (rawPayload == null) return
        val message = String(rawPayload, Charsets.UTF_8).trim()
        Log.d(TAG, "Received payload from \$DEVICE_NAME: \$message")

        if (message == PAYLOAD_TOGGLE_FOCUS) {
            // Provide 100ms tactile vibration feedback
            vibratePhone(100L)

            // Toggle deadlock mode
            serviceScope.launch {
                val newState = repository.toggleDeadlockMode()
                Log.d(TAG, "DEADEND_PUCK tap toggled deadlock mode. Active: \$newState")
            }
        }
    }

    private fun vibratePhone(durationMs: Long = 100L) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                val vibrator = vibratorManager?.defaultVibrator
                vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(durationMs)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Tactile vibration feedback failed: \${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(localReceiver)
        } catch (e: Exception) {
            // Ignore if already unregistered
        }

        try {
            bluetoothLeScanner?.stopScan(scanCallback)
            isScanning = false
        } catch (e: SecurityException) {
            // Ignore
        }

        try {
            bluetoothGatt?.close()
            bluetoothGatt = null
        } catch (e: SecurityException) {
            // Ignore
        }
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "FocusNodeBleService"

        // Hardcoded Hardware Identifiers
        const val DEVICE_NAME = "DEADEND_PUCK"
        const val SERVICE_UUID_STRING = "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
        const val CHARACTERISTIC_UUID_STRING = "beb5483e-36e1-4688-b7f5-ea07361b26a8"
        const val CCCD_UUID_STRING = "00002902-0000-1000-8000-00805f9b34fb"
        const val PAYLOAD_TOGGLE_FOCUS = "TOGGLE_FOCUS"

        val SERVICE_UUID: UUID = UUID.fromString(SERVICE_UUID_STRING)
        val CHARACTERISTIC_UUID: UUID = UUID.fromString(CHARACTERISTIC_UUID_STRING)
        val CCCD_UUID: UUID = UUID.fromString(CCCD_UUID_STRING)

        const val ACTION_TOGGLE_FOCUS = "io.deadend.launcher.ACTION_TOGGLE_FOCUS"
    }
}
`
  },

  // 15. KeepAliveService.kt
  {
    path: "app/src/main/kotlin/io/deadend/launcher/services/KeepAliveService.kt",
    category: "service",
    description: "Low-overhead persistent foreground service with minimal notification preventing low-RAM process termination.",
    language: "kotlin",
    content: `package io.deadend.launcher.services

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import io.deadend.launcher.ui.HomeScreen

class KeepAliveService : Service() {

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, HomeScreen::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, "deadend_guard")
            .setContentTitle("DEADEND Guard Active")
            .setContentText("Focus shield running 100% on-device.")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(pendingIntent)
            .build()

        startForeground(1001, notification)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
}`
  },

  // 15. ScreenStateReceiver.kt
  {
    path: "app/src/main/kotlin/io/deadend/launcher/receiver/ScreenStateReceiver.kt",
    category: "receiver",
    description: "Broadcast receiver for ACTION_SCREEN_ON and ACTION_USER_PRESENT to re-evaluate budgets and launcher state.",
    language: "kotlin",
    content: `package io.deadend.launcher.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ScreenStateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        // Re-evaluates daily minute limits and refreshes default home role on screen wake
    }
}`
  },

  // 16. DeadlockDeviceAdminReceiver.kt
  {
    path: "app/src/main/kotlin/io/deadend/launcher/receiver/DeadlockDeviceAdminReceiver.kt",
    category: "receiver",
    description: "Device policy administrator receiver enforcing Deadlock emergency focus lockdown.",
    language: "kotlin",
    content: `package io.deadend.launcher.receiver

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class DeadlockDeviceAdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
    }
}`
  },

  // 17. OEMHelper.kt
  {
    path: "app/src/main/kotlin/io/deadend/launcher/core/OEMHelper.kt",
    category: "core",
    description: "Deep-linking engine for Xiaomi/MIUI/HyperOS, Samsung, Oppo/Realme, and OnePlus battery & autostart background killers.",
    language: "kotlin",
    content: `package io.deadend.launcher.core

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings

object OEMHelper {
    fun openOemBatterySettings(context: Context) {
        val manufacturer = Build.MANUFACTURER.lowercase()
        val intent = Intent()

        when {
            manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco") -> {
                intent.component = ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")
            }
            manufacturer.contains("samsung") -> {
                intent.component = ComponentName("com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity")
            }
            manufacturer.contains("oppo") || manufacturer.contains("realme") -> {
                intent.component = ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")
            }
            else -> {
                intent.action = Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS
            }
        }

        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            context.startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }
}`
  },

  // 18. HealthCheckScreen.kt
  {
    path: "app/src/main/kotlin/io/deadend/launcher/ui/HealthCheckScreen.kt",
    category: "ui",
    description: "Diagnostic screen verifying Home role status, Accessibility, Notification Listener, battery exemption, and OEM deep links.",
    language: "kotlin",
    content: `package io.deadend.launcher.ui

import android.content.Context
import android.os.Build
import android.os.PowerManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.deadend.launcher.core.OEMHelper

@Composable
fun HealthCheckScreen() {
    val context = LocalContext.current
    val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    val isBatteryIgnored = powerManager?.isIgnoringBatteryOptimizations(context.packageName) ?: false

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(20.dp)
    ) {
        item {
            Text(
                text = "OEM HEALTH CHECK & RESILIENCE",
                fontSize = 16.sp,
                fontFamily = FontFamily.Monospace,
                color = Color.White
            )
            Text(
                text = "Verifying background resilience on \${Build.MANUFACTURER.uppercase()}",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF737373)
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        item {
            Button(
                onClick = { OEMHelper.openOemBatterySettings(context) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262626))
            ) {
                Text("Open \${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} Background Management Settings")
            }
        }
    }
}`
  },

  // 19. LauncherRepository.kt
  {
    path: "app/src/main/kotlin/io/deadend/launcher/data/LauncherRepository.kt",
    category: "data",
    description: "Manages DataStore Preferences persistence for unlimited pinned apps, app budgets, 15-minute cool-down queues, and friction logs.",
    language: "kotlin",
    content: `package io.deadend.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

val Context.dataStore by preferencesDataStore(name = "deadend_preferences")

@Singleton
class LauncherRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val PINNED_APPS_KEY = stringSetPreferencesKey("pinned_packages")
    private val RESTRICTED_APPS_KEY = stringSetPreferencesKey("restricted_packages")
    private val DEADLOCK_ACTIVE_KEY = booleanPreferencesKey("deadlock_active")
    private val DEADLOCK_UNTIL_KEY = longPreferencesKey("deadlock_until")
    private val FOCUS_MODE_KEY = booleanPreferencesKey("focus_mode_active")

    // Default essential apps (including Google Play Store directly)
    val defaultPinnedApps = setOf(
        "com.google.android.dialer",
        "com.google.android.apps.messaging",
        "com.google.android.keep",
        "com.android.camera",
        "com.google.android.calendar",
        "com.android.vending" // Google Play Store
    )

    val defaultRestrictedApps = setOf(
        "com.instagram.android",
        "com.google.android.youtube",
        "com.zhiliaoapp.musically",
        "com.reddit.frontpage",
        "com.twitter.android",
        "com.android.chrome"
    )

    val pinnedAppsFlow: Flow<Set<String>> = context.dataStore.data.map { prefs ->
        prefs[PINNED_APPS_KEY] ?: defaultPinnedApps
    }

    val focusModeFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[FOCUS_MODE_KEY] ?: false
    }

    val deadlockFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        val active = prefs[DEADLOCK_ACTIVE_KEY] ?: false
        val until = prefs[DEADLOCK_UNTIL_KEY] ?: 0L
        active && System.currentTimeMillis() < until
    }

    suspend fun toggleFocusMode(): Boolean {
        var newState = false
        context.dataStore.edit { prefs ->
            val current = prefs[FOCUS_MODE_KEY] ?: false
            newState = !current
            prefs[FOCUS_MODE_KEY] = newState
        }
        return newState
    }

    suspend fun isFocusModeActive(): Boolean {
        return context.dataStore.data.first()[FOCUS_MODE_KEY] ?: false
    }

    suspend fun pinApp(packageName: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[PINNED_APPS_KEY]?.toMutableSet() ?: defaultPinnedApps.toMutableSet()
            current.add(packageName)
            prefs[PINNED_APPS_KEY] = current
        }
    }

    suspend fun unpinApp(packageName: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[PINNED_APPS_KEY]?.toMutableSet() ?: defaultPinnedApps.toMutableSet()
            current.remove(packageName)
            prefs[PINNED_APPS_KEY] = current
        }
    }

    suspend fun isAppRestricted(packageName: String): Boolean {
        val prefs = context.dataStore.data.first()
        val restricted = prefs[RESTRICTED_APPS_KEY] ?: defaultRestrictedApps
        return restricted.contains(packageName)
    }

    suspend fun isDeadlockActive(): Boolean {
        val prefs = context.dataStore.data.first()
        val active = prefs[DEADLOCK_ACTIVE_KEY] ?: false
        val until = prefs[DEADLOCK_UNTIL_KEY] ?: 0L
        return active && System.currentTimeMillis() < until
    }

    suspend fun toggleDeadlockMode(): Boolean {
        var newState = false
        context.dataStore.edit { prefs ->
            val current = prefs[DEADLOCK_ACTIVE_KEY] ?: false
            val currentUntil = prefs[DEADLOCK_UNTIL_KEY] ?: 0L
            val isCurrentlyActive = current && System.currentTimeMillis() < currentUntil
            newState = !isCurrentlyActive
            prefs[DEADLOCK_ACTIVE_KEY] = newState
            if (newState) {
                // Default 60-minute hardware lockdown window unless disarmed
                prefs[DEADLOCK_UNTIL_KEY] = System.currentTimeMillis() + (60 * 60 * 1000L)
            } else {
                prefs[DEADLOCK_UNTIL_KEY] = 0L
            }
        }
        return newState
    }

    suspend fun armDeadlock(durationMinutes: Int = 60) {
        context.dataStore.edit { prefs ->
            prefs[DEADLOCK_ACTIVE_KEY] = true
            prefs[DEADLOCK_UNTIL_KEY] = System.currentTimeMillis() + (durationMinutes * 60 * 1000L)
        }
    }

    suspend fun setFocusMode(active: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[FOCUS_MODE_KEY] = active
        }
    }

    suspend fun disarmDeadlock() {
        context.dataStore.edit { prefs ->
            prefs[DEADLOCK_ACTIVE_KEY] = false
            prefs[DEADLOCK_UNTIL_KEY] = 0L
        }
    }

    // Communication Whitelist: strictly phone/dialer and SMS messaging
    fun isEmergencyAllowed(packageName: String): Boolean {
        return packageName == "com.google.android.dialer" ||
               packageName == "com.android.phone" ||
               packageName == "com.google.android.apps.messaging"
    }

    // 15-Minute Intentional Delay Engine for limit lifting
    suspend fun initiateLimitRemoval(packageName: String) {
        val pendingUnlockTime = System.currentTimeMillis() + (15 * 60 * 1000)
        context.dataStore.edit { prefs ->
            prefs[longPreferencesKey("pending_unlock_\$packageName")] = pendingUnlockTime
        }
    }

    suspend fun getPendingLimitRemovalTime(packageName: String): Long? {
        val prefs = context.dataStore.data.first()
        return prefs[longPreferencesKey("pending_unlock_\$packageName")]
    }

    suspend fun cancelLimitRemoval(packageName: String) {
        context.dataStore.edit { prefs ->
            prefs.remove(longPreferencesKey("pending_unlock_\$packageName"))
        }
    }

    suspend fun confirmLimitRemoval(packageName: String) {
        context.dataStore.edit { prefs ->
            prefs.remove(longPreferencesKey("pending_unlock_\$packageName"))
            val current = prefs[RESTRICTED_APPS_KEY]?.toMutableSet() ?: defaultRestrictedApps.toMutableSet()
            current.remove(packageName)
            prefs[RESTRICTED_APPS_KEY] = current
        }
    }

    suspend fun wasOpenedToday(packageName: String): Boolean {
        return false
    }

    suspend fun hasActiveSession(packageName: String): Boolean {
        val until = context.dataStore.data.first()[longPreferencesKey("session_until_\$packageName")] ?: 0L
        return System.currentTimeMillis() < until
    }

    suspend fun grantSession(packageName: String, minutes: Int) {
        context.dataStore.edit { prefs ->
            prefs[longPreferencesKey("session_until_\$packageName")] =
                System.currentTimeMillis() + (minutes * 60 * 1000)
        }
    }

    suspend fun cacheBatchedNotification(packageName: String, title: String, body: String, timestamp: Long) {
        // Caches suppressed notification on-device
    }
}`
  },

  // 20. gradle.properties
  {
    path: "gradle.properties",
    category: "config",
    description: "Gradle JVM memory allocation, AndroidX flags, and non-transitive R class optimizations.",
    language: "properties",
    content: `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
kotlin.code.style=official`
  },

  // 21. proguard-rules.pro
  {
    path: "app/proguard-rules.pro",
    category: "build",
    description: "ProGuard / R8 code shrinking rules preserving launcher, services, and Hilt injection targets.",
    language: "properties",
    content: `# DEADEND Launcher ProGuard Rules
-keep class io.deadend.launcher.** { *; }
-dontwarn okio.**
-keepattributes *Annotation*
-keepclassmembers class * {
    @javax.inject.Inject <init>(...);
}`
  },

  // 22. colors.xml
  {
    path: "app/src/main/res/values/colors.xml",
    category: "res",
    description: "OLED true-black (#000000) and monochromatic palette definitions.",
    language: "xml",
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="black">#FF000000</color>
    <color name="white">#FFFFFFFF</color>
    <color name="neutral_900">#FF171717</color>
    <color name="amber_accent">#FFFBBF24</color>
</resources>`
  }
];

