/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AppItem, FrictionConfig } from '../types/deadend';

export const DEFAULT_APPS: AppItem[] = [
  // Essential Communication (Never blocked, pinned by default)
  {
    id: 'phone',
    name: 'Phone',
    packageName: 'com.google.android.dialer',
    category: 'essential',
    isPinned: true,
    isHidden: false,
    dailyBudgetMinutes: 0,
    timeUsedTodaySeconds: 140,
    openCountToday: 3,
    isEmergencyAllowed: true,
    description: 'Emergency and voice calls'
  },
  {
    id: 'messages',
    name: 'Messages',
    packageName: 'com.google.android.apps.messaging',
    category: 'essential',
    isPinned: true,
    isHidden: false,
    dailyBudgetMinutes: 0,
    timeUsedTodaySeconds: 320,
    openCountToday: 5,
    lastOpenedAt: Date.now() - 1000 * 60 * 12,
    isEmergencyAllowed: true,
    description: 'SMS and direct emergency communications'
  },
  {
    id: 'camera',
    name: 'Camera',
    packageName: 'com.android.camera',
    category: 'utility',
    isPinned: true,
    isHidden: false,
    dailyBudgetMinutes: 0,
    timeUsedTodaySeconds: 60,
    openCountToday: 2,
    isEmergencyAllowed: false,
    description: 'Hardware visual capture'
  },
  {
    id: 'notes',
    name: 'Notes',
    packageName: 'com.google.android.keep',
    category: 'utility',
    isPinned: true,
    isHidden: false,
    dailyBudgetMinutes: 0,
    timeUsedTodaySeconds: 210,
    openCountToday: 4,
    isEmergencyAllowed: false,
    description: 'Quick capture & thought dump'
  },
  {
    id: 'calendar',
    name: 'Calendar',
    packageName: 'com.google.android.calendar',
    category: 'utility',
    isPinned: true,
    isHidden: false,
    dailyBudgetMinutes: 0,
    timeUsedTodaySeconds: 90,
    openCountToday: 2,
    isEmergencyAllowed: false,
    description: 'Daily agenda and time blocks'
  },
  {
    id: 'playstore',
    name: 'Play Store',
    packageName: 'com.android.vending',
    category: 'essential',
    isPinned: true,
    isHidden: false,
    dailyBudgetMinutes: 0,
    timeUsedTodaySeconds: 95,
    openCountToday: 1,
    isEmergencyAllowed: false,
    description: 'Android application manager & updates'
  },
  {
    id: 'clock',
    name: 'Clock & Alarms',
    packageName: 'com.google.android.deskclock',
    category: 'utility',
    isPinned: false,
    isHidden: false,
    dailyBudgetMinutes: 0,
    timeUsedTodaySeconds: 45,
    openCountToday: 1,
    isEmergencyAllowed: true,
    description: 'Timers and wake alarms'
  },
  {
    id: 'maps',
    name: 'Maps & Transit',
    packageName: 'com.google.android.apps.maps',
    category: 'utility',
    isPinned: false,
    isHidden: false,
    dailyBudgetMinutes: 0,
    timeUsedTodaySeconds: 180,
    openCountToday: 1,
    isEmergencyAllowed: true,
    description: 'Turn-by-turn navigation'
  },

  // High-Friction Dopamine Intercepted Apps
  {
    id: 'instagram',
    name: 'Instagram',
    packageName: 'com.instagram.android',
    category: 'intercepted',
    isPinned: false,
    isHidden: false,
    dailyBudgetMinutes: 15,
    timeUsedTodaySeconds: 420,
    openCountToday: 2,
    isEmergencyAllowed: false,
    description: 'Algorithmic media feed (High Friction)'
  },
  {
    id: 'youtube',
    name: 'YouTube',
    packageName: 'com.google.android.youtube',
    category: 'intercepted',
    isPinned: false,
    isHidden: false,
    dailyBudgetMinutes: 20,
    timeUsedTodaySeconds: 600,
    openCountToday: 1,
    isEmergencyAllowed: false,
    description: 'Streaming video platform (High Friction)'
  },
  {
    id: 'tiktok',
    name: 'TikTok',
    packageName: 'com.zhiliaoapp.musically',
    category: 'intercepted',
    isPinned: false,
    isHidden: false,
    dailyBudgetMinutes: 10,
    timeUsedTodaySeconds: 0,
    openCountToday: 0,
    isEmergencyAllowed: false,
    description: 'Micro-video infinite feed (High Friction)'
  },
  {
    id: 'reddit',
    name: 'Reddit',
    packageName: 'com.reddit.frontpage',
    category: 'intercepted',
    isPinned: false,
    isHidden: false,
    dailyBudgetMinutes: 15,
    timeUsedTodaySeconds: 300,
    openCountToday: 1,
    isEmergencyAllowed: false,
    description: 'Community threads & endless scroll (High Friction)'
  },
  {
    id: 'x',
    name: 'X (Twitter)',
    packageName: 'com.twitter.android',
    category: 'intercepted',
    isPinned: false,
    isHidden: false,
    dailyBudgetMinutes: 15,
    timeUsedTodaySeconds: 240,
    openCountToday: 1,
    isEmergencyAllowed: false,
    description: 'Microblogging & hot takes (High Friction)'
  },
  {
    id: 'chrome',
    name: 'Chrome Browser',
    packageName: 'com.android.chrome',
    category: 'intercepted',
    isPinned: false,
    isHidden: false,
    dailyBudgetMinutes: 30,
    timeUsedTodaySeconds: 540,
    openCountToday: 3,
    isEmergencyAllowed: false,
    description: 'Open web navigation (High Friction)'
  },
  {
    id: 'calculator',
    name: 'Calculator',
    packageName: 'com.google.android.calculator',
    category: 'utility',
    isPinned: false,
    isHidden: false,
    dailyBudgetMinutes: 0,
    timeUsedTodaySeconds: 30,
    openCountToday: 1,
    isEmergencyAllowed: false,
    description: 'Math calculations'
  },
  {
    id: 'settings',
    name: 'System Settings',
    packageName: 'com.android.settings',
    category: 'system',
    isPinned: false,
    isHidden: false,
    dailyBudgetMinutes: 0,
    timeUsedTodaySeconds: 85,
    openCountToday: 2,
    isEmergencyAllowed: true,
    description: 'Device configuration'
  }
];

export const DEFAULT_FRICTION_CONFIG: FrictionConfig = {
  breathingDurationSeconds: 10,
  requireIntentText: true,
  frictionChallenge: 'none',
  dailyHighFrictionLimitMinutes: 45,
  strictLockoutOnExpiry: true,
  soundEnabled: true,
  hapticEnabled: true,
  quickIntents: [
    'Reply to urgent incoming message',
    'Look up specific reference/article',
    'Post scheduled content and leave',
    'Coordinate meeting / location',
    'Verify two-factor code or banking'
  ]
};
