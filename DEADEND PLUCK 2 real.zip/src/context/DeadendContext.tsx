/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import {
  AppItem,
  FrictionConfig,
  DeadlockState,
  UsageLogEntry,
  DayStats,
  ActiveSession,
  ThemeStyle,
  SystemHealthState,
  OEMManufacturer,
  NavigationMode,
  DigestConfig,
  BatchNotification,
  PendingLimitUnlock,
  SupporterAesthetics,
  PermissionRationale
} from '../types/deadend';
import { DEFAULT_APPS, DEFAULT_FRICTION_CONFIG } from '../data/defaultApps';
import { audio } from '../utils/audio';

export type ViewModeType = 'launcher' | 'dashboard' | 'android-spec' | 'settings' | 'health-check' | 'digest';

interface DeadendContextType {
  apps: AppItem[];
  frictionConfig: FrictionConfig;
  deadlockState: DeadlockState;
  activeSession: ActiveSession | null;
  dayStats: DayStats;
  viewMode: ViewModeType;
  phoneFrameMode: boolean;
  theme: ThemeStyle;
  interceptorTargetApp: AppItem | null;
  searchQuery: string;
  mostRecentApp: AppItem | null;

  // OEM & Subsystem Diagnostics
  systemHealth: SystemHealthState;
  digestConfig: DigestConfig;
  pendingLimitUnlocks: PendingLimitUnlock[];
  supporterAesthetics: SupporterAesthetics;
  permissionRationaleModal: PermissionRationale | null;

  // Actions
  setViewMode: (mode: ViewModeType) => void;
  setPhoneFrameMode: (enabled: boolean) => void;
  setTheme: (theme: ThemeStyle) => void;
  setSearchQuery: (query: string) => void;
  handleAppClick: (app: AppItem) => void;
  cancelInterception: () => void;
  abortInterception: (app: AppItem, estimatedSavedMinutes?: number) => void;
  proceedInterception: (app: AppItem, intent: string, minutes: number) => void;
  endActiveSession: (early?: boolean) => void;
  armDeadlock: (durationMinutes: number, reason?: string) => void;
  disarmDeadlock: () => void;
  togglePinApp: (appId: string) => void;
  toggleInterceptApp: (appId: string) => void;
  toggleHideApp: (appId: string) => void;
  updateAppBudget: (appId: string, minutes: number) => void;
  updateFrictionConfig: (config: Partial<FrictionConfig>) => void;
  simulateMidnightReset: () => void;
  recordPickup: () => void;
  activeSimulatedApp: AppItem | null;
  closeSimulatedApp: () => void;

  // OEM & System Health actions
  setSystemHealth: React.Dispatch<React.SetStateAction<SystemHealthState>>;
  requestHomeRole: () => void;
  dismissHomeBanner: () => void;
  dismissOemGestureWarning: () => void;
  toggleSystemPermissionWithRationale: (key: keyof SystemHealthState) => void;
  closeRationaleModal: () => void;
  confirmRationaleAction: () => void;

  // Notification Digest Actions
  toggleDigestEnabled: () => void;
  releaseDigestNow: () => void;
  dismissBatchNotification: (id: string) => void;
  simulateIncomingNotification: () => void;

  // 15-Minute Intentional Delay Actions
  queueLimitUnlock: (appId: string, newMinutes: number, actionType: 'increase_budget' | 'remove_friction') => void;
  cancelLimitUnlock: (appId: string) => void;
  applyLimitUnlock: (appId: string) => void;

  // Supporter Aesthetics Actions
  unlockSupporterTier: () => void;
  updateSupporterAesthetics: (settings: Partial<SupporterAesthetics>) => void;

  // ESP32 "The Monolith" BLE Desk Node & Auto-Disarm on Disconnect
  isMonolithBleConnected: boolean;
  toggleMonolithBle: () => void;
  setMonolithBleConnected: (connected: boolean) => void;
  autoDisarmedNotice: string | null;
  clearAutoDisarmedNotice: () => void;
}

const STORAGE_KEYS = {
  APPS: 'deadend_apps_v2',
  CONFIG: 'deadend_config_v2',
  STATS: 'deadend_stats_v2',
  DEADLOCK: 'deadend_deadlock_v2',
  THEME: 'deadend_theme_v2',
  HEALTH: 'deadend_health_v2',
  DIGEST: 'deadend_digest_v2',
  LIMIT_UNLOCKS: 'deadend_limit_unlocks_v2',
  SUPPORTER: 'deadend_supporter_v2'
};

const getTodayKey = () => new Date().toISOString().split('T')[0];

const INITIAL_NOTIFICATIONS: BatchNotification[] = [
  {
    id: 'notif-1',
    appName: 'Instagram',
    packageName: 'com.instagram.android',
    title: 'Alex and 4 others liked your story',
    body: 'Tap to view new reactions and comments.',
    timestamp: Date.now() - 1000 * 60 * 42,
    isPriority: false,
    category: 'social'
  },
  {
    id: 'notif-2',
    appName: 'X (Twitter)',
    packageName: 'com.twitter.android',
    title: 'Trending in Tech',
    body: 'Developers praise Zero-Internet on-device launchers.',
    timestamp: Date.now() - 1000 * 60 * 25,
    isPriority: false,
    category: 'social'
  },
  {
    id: 'notif-3',
    appName: 'Reddit',
    packageName: 'com.reddit.frontpage',
    title: 'r/digitalminimalism',
    body: 'How I reduced my screen time from 6 hours to 45 minutes.',
    timestamp: Date.now() - 1000 * 60 * 12,
    isPriority: false,
    category: 'social'
  }
];

const DeadendContext = createContext<DeadendContextType | null>(null);

export const DeadendProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Apps List
  const [apps, setApps] = useState<AppItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.APPS);
      return saved ? JSON.parse(saved) : DEFAULT_APPS;
    } catch {
      return DEFAULT_APPS;
    }
  });

  // 2. Friction Configuration
  const [frictionConfig, setFrictionConfig] = useState<FrictionConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CONFIG);
      return saved ? JSON.parse(saved) : DEFAULT_FRICTION_CONFIG;
    } catch {
      return DEFAULT_FRICTION_CONFIG;
    }
  });

  // 3. Theme
  const [theme, setTheme] = useState<ThemeStyle>(() => {
    try {
      return (localStorage.getItem(STORAGE_KEYS.THEME) as ThemeStyle) || 'oled_pure';
    } catch {
      return 'oled_pure';
    }
  });

  // 4. Deadlock State
  const [deadlockState, setDeadlockState] = useState<DeadlockState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DEADLOCK);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.isActive && parsed.endsAt && parsed.endsAt > Date.now()) {
          return parsed;
        }
      }
    } catch {}
    return {
      isActive: false,
      startedAt: null,
      endsAt: null,
      durationMinutes: 60,
      reason: 'Deep work & digital silence'
    };
  });

  // 5. Day Stats
  const [dayStats, setDayStats] = useState<DayStats>(() => {
    const today = getTodayKey();
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.STATS);
      if (saved) {
        const parsed: DayStats = JSON.parse(saved);
        if (parsed.date === today) {
          return parsed;
        }
      }
    } catch {}
    return {
      date: today,
      pickupsCount: 14,
      interceptionsAborted: 5,
      interceptionsProceeded: 2,
      totalScreenTimeSeconds: 4320,
      distractingTimeSeconds: 1560,
      timeSavedSeconds: 4500,
      logs: [
        {
          id: 'log-init-1',
          timestamp: Date.now() - 3600000 * 2,
          appId: 'instagram',
          appName: 'Instagram',
          packageName: 'com.instagram.android',
          type: 'intercepted_aborted',
          timeSavedSeconds: 900
        },
        {
          id: 'log-init-2',
          timestamp: Date.now() - 3600000,
          appId: 'reddit',
          appName: 'Reddit',
          packageName: 'com.reddit.frontpage',
          type: 'session_started',
          declaredIntent: 'Check technical bug resolution',
          allocatedMinutes: 5,
          actualDurationSeconds: 280
        }
      ]
    };
  });

  // 6. OEM & System Diagnostics State
  const [systemHealth, setSystemHealth] = useState<SystemHealthState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.HEALTH);
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      isRoleHomeHeld: false, // Intentionally false on first boot to showcase RoleManager restore banner
      isAccessibilityGranted: true,
      isNotificationListenerGranted: true,
      isUsageStatsGranted: true,
      isBatteryOptimizationIgnored: false,
      isKeepAliveForegroundActive: true,
      detectedManufacturer: 'xiaomi', // Default to OEM testing mode (Xiaomi/MIUI)
      navigationMode: 'gestural',
      oemGestureWarningDismissed: false,
      roleHomeBannerDismissed: false
    };
  });

  // 7. Notification Digest Engine
  const [digestConfig, setDigestConfig] = useState<DigestConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DIGEST);
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      enabled: true,
      scheduledTimes: ['12:00', '18:00'],
      whitelistPackages: [
        'com.google.android.dialer',
        'com.google.android.apps.messaging',
        'com.google.android.calendar',
        'com.google.android.deskclock'
      ],
      batchedNotifications: INITIAL_NOTIFICATIONS,
      lastDeliveredAt: null
    };
  });

  // 8. 15-Minute Intentional Limit Unlocks Queue
  const [pendingLimitUnlocks, setPendingLimitUnlocks] = useState<PendingLimitUnlock[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.LIMIT_UNLOCKS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // 9. Supporter Aesthetics (Monetization: Core remains 100% free forever)
  const [supporterAesthetics, setSupporterAesthetics] = useState<SupporterAesthetics>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SUPPORTER);
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      isUnlocked: false,
      selectedFont: 'jetbrains_mono',
      selectedAccent: 'pure_white'
    };
  });

  // UI Navigation states
  const [viewMode, setViewMode] = useState<ViewModeType>('launcher');
  const [phoneFrameMode, setPhoneFrameMode] = useState<boolean>(true);
  const [interceptorTargetApp, setInterceptorTargetApp] = useState<AppItem | null>(null);
  const [activeSession, setActiveSession] = useState<ActiveSession | null>(null);
  const [activeSimulatedApp, setActiveSimulatedApp] = useState<AppItem | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [permissionRationaleModal, setPermissionRationaleModal] = useState<PermissionRationale | null>(null);

  // 10. Monolith BLE Desk Node connection state
  const [isMonolithBleConnected, setIsMonolithBleConnected] = useState<boolean>(false);
  const [autoDisarmedNotice, setAutoDisarmedNotice] = useState<string | null>(null);

  // Most recently opened app calculation
  const mostRecentApp = useMemo(() => {
    const opened = apps.filter(a => a.lastOpenedAt && a.lastOpenedAt > 0);
    if (opened.length > 0) {
      return [...opened].sort((a, b) => (b.lastOpenedAt || 0) - (a.lastOpenedAt || 0))[0];
    }
    const withOpens = apps.filter(a => a.openCountToday > 0);
    if (withOpens.length > 0) {
      return [...withOpens].sort((a, b) => b.openCountToday - a.openCountToday)[0];
    }
    return apps[0] || null;
  }, [apps]);

  // Sync audio enabled state with friction config
  useEffect(() => {
    audio.setEnabled(frictionConfig.soundEnabled);
  }, [frictionConfig.soundEnabled]);

  // Persist State
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.APPS, JSON.stringify(apps));
    } catch {}
  }, [apps]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(frictionConfig));
    } catch {}
  }, [frictionConfig]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.STATS, JSON.stringify(dayStats));
    } catch {}
  }, [dayStats]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.DEADLOCK, JSON.stringify(deadlockState));
    } catch {}
  }, [deadlockState]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.THEME, theme);
    } catch {}
  }, [theme]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.HEALTH, JSON.stringify(systemHealth));
    } catch {}
  }, [systemHealth]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.DIGEST, JSON.stringify(digestConfig));
    } catch {}
  }, [digestConfig]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.LIMIT_UNLOCKS, JSON.stringify(pendingLimitUnlocks));
    } catch {}
  }, [pendingLimitUnlocks]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SUPPORTER, JSON.stringify(supporterAesthetics));
    } catch {}
  }, [supporterAesthetics]);

  // Deadlock countdown ticker
  useEffect(() => {
    if (!deadlockState.isActive || !deadlockState.endsAt) return;

    const interval = setInterval(() => {
      const remaining = deadlockState.endsAt! - Date.now();
      if (remaining <= 0) {
        setDeadlockState(prev => ({ ...prev, isActive: false, endsAt: null }));
        audio.playVictory();
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [deadlockState]);

  // Active Session countdown ticker
  useEffect(() => {
    if (!activeSession) return;

    const interval = setInterval(() => {
      setActiveSession(prev => {
        if (!prev) return null;
        if (prev.remainingSeconds <= 1) {
          audio.playWarning();
          return { ...prev, remainingSeconds: 0, isExpired: true };
        }

        if (prev.remainingSeconds === 60) {
          audio.playWarning();
        }

        return { ...prev, remainingSeconds: prev.remainingSeconds - 1 };
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [activeSession]);

  // Screen Pickup recorder
  const recordPickup = useCallback(() => {
    setDayStats(prev => ({
      ...prev,
      pickupsCount: prev.pickupsCount + 1
    }));
  }, []);

  // Launch app handler with Graduated & Persistent Friction
  const handleAppClick = useCallback((app: AppItem) => {
    audio.playClick();

    // 1. Check Deadlock
    if (deadlockState.isActive) {
      if (!app.isEmergencyAllowed) {
        audio.playWarning();
        return;
      }
    }

    // 2. Check if Intercepted category
    if (app.category === 'intercepted') {
      setInterceptorTargetApp(app);
      return;
    }

    // 3. Normal / Essential App: open simulated app view
    setActiveSimulatedApp(app);
    setApps(prev => prev.map(a => a.id === app.id ? { ...a, openCountToday: a.openCountToday + 1, lastOpenedAt: Date.now() } : a));
  }, [deadlockState]);

  // Cancel / Dismiss Interception gate
  const cancelInterception = useCallback(() => {
    audio.playClick();
    setInterceptorTargetApp(null);
  }, []);

  // User aborts urge! "Abort & Save My Time"
  const abortInterception = useCallback((app: AppItem, estimatedSavedMinutes: number = 15) => {
    audio.playVictory();
    const savedSecs = estimatedSavedMinutes * 60;
    const newLog: UsageLogEntry = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
      appId: app.id,
      appName: app.name,
      packageName: app.packageName,
      type: 'intercepted_aborted',
      timeSavedSeconds: savedSecs
    };

    setDayStats(prev => ({
      ...prev,
      interceptionsAborted: prev.interceptionsAborted + 1,
      timeSavedSeconds: prev.timeSavedSeconds + savedSecs,
      logs: [newLog, ...prev.logs]
    }));

    setInterceptorTargetApp(null);
  }, []);

  // User proceeds with allocated budget & flags Persistent Friction for remainder of day
  const proceedInterception = useCallback((app: AppItem, intent: string, minutes: number) => {
    audio.playClick();
    const sessionSeconds = minutes * 60;
    const newSession: ActiveSession = {
      app,
      declaredIntent: intent,
      allocatedMinutes: minutes,
      remainingSeconds: sessionSeconds,
      startedAt: Date.now(),
      isExpired: false
    };

    const newLog: UsageLogEntry = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
      appId: app.id,
      appName: app.name,
      packageName: app.packageName,
      type: 'session_started',
      declaredIntent: intent,
      allocatedMinutes: minutes
    };

    setActiveSession(newSession);
    setActiveSimulatedApp(app);
    setInterceptorTargetApp(null);

    setDayStats(prev => ({
      ...prev,
      interceptionsProceeded: prev.interceptionsProceeded + 1,
      logs: [newLog, ...prev.logs]
    }));

    // Mark persistent friction for remainder of day
    setApps(prev => prev.map(a => a.id === app.id ? {
      ...a,
      openCountToday: a.openCountToday + 1,
      lastOpenedAt: Date.now(),
      hasPersistentFrictionToday: true
    } : a));
  }, []);

  // End active session
  const endActiveSession = useCallback((early: boolean = false) => {
    audio.playClick();
    if (activeSession) {
      const elapsedSeconds = (activeSession.allocatedMinutes * 60) - activeSession.remainingSeconds;
      const completedLog: UsageLogEntry = {
        id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        timestamp: Date.now(),
        appId: activeSession.app.id,
        appName: activeSession.app.name,
        packageName: activeSession.app.packageName,
        type: 'session_completed',
        declaredIntent: activeSession.declaredIntent,
        allocatedMinutes: activeSession.allocatedMinutes,
        actualDurationSeconds: Math.max(1, elapsedSeconds)
      };

      setDayStats(prev => ({
        ...prev,
        distractingTimeSeconds: prev.distractingTimeSeconds + elapsedSeconds,
        logs: [completedLog, ...prev.logs]
      }));

      setApps(prev => prev.map(a => a.id === activeSession.app.id ? { ...a, timeUsedTodaySeconds: a.timeUsedTodaySeconds + elapsedSeconds } : a));
    }

    setActiveSession(null);
    setActiveSimulatedApp(null);
    if (early) {
      audio.playVictory();
    }
  }, [activeSession]);

  // Deadlock controls
  const armDeadlock = useCallback((durationMinutes: number, reason: string = 'Deep work & digital silence') => {
    audio.playDeadlockArm();
    const now = Date.now();
    const endsAt = now + durationMinutes * 60 * 1000;

    const newLog: UsageLogEntry = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: now,
      appId: 'deadlock',
      appName: 'Deadlock Emergency Lock',
      packageName: 'io.deadend.deadlock',
      type: 'deadlock_entered',
      allocatedMinutes: durationMinutes,
      declaredIntent: reason
    };

    setDeadlockState({
      isActive: true,
      startedAt: now,
      endsAt,
      durationMinutes,
      reason
    });

    setDayStats(prev => ({
      ...prev,
      logs: [newLog, ...prev.logs]
    }));

    setActiveSimulatedApp(null);
    setActiveSession(null);
    setInterceptorTargetApp(null);
  }, []);

  const disarmDeadlock = useCallback(() => {
    audio.playClick();
    setDeadlockState(prev => ({
      ...prev,
      isActive: false,
      endsAt: null
    }));
  }, []);

  const clearAutoDisarmedNotice = useCallback(() => {
    setAutoDisarmedNotice(null);
  }, []);

  // When Bluetooth connection goes out or puck is removed (UUID turns off): automatically disarm lockdown mode
  // When puck is detected (UUID turns on): directly enter Deadlock mode
  const setMonolithBleConnected = useCallback((connected: boolean) => {
    audio.playClick();
    setIsMonolithBleConnected(connected);
    if (!connected) {
      // Puck removed (UUID turns off): turn off deadlock and return to launcher interface
      setDeadlockState(currentDeadlock => {
        if (currentDeadlock.isActive) {
          audio.playVictory();
          const log: UsageLogEntry = {
            id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            timestamp: Date.now(),
            appId: 'monolith_ble',
            appName: 'The Monolith Desk Node',
            packageName: 'io.deadend.monolith',
            type: 'deadlock_disarmed',
            declaredIntent: 'DEADEND_PUCK removed (UUID turned off): Lockdown mode automatically disarmed.'
          };
          setDayStats(prev => ({
            ...prev,
            logs: [log, ...prev.logs]
          }));
          setAutoDisarmedNotice('DEADEND_PUCK removed (UUID turned off): Lockdown mode disarmed. Restored DEADEND launcher.');
          return {
            ...currentDeadlock,
            isActive: false,
            endsAt: null
          };
        }
        return currentDeadlock;
      });
    } else {
      // Puck detected (UUID active): directly enter new Deadlock mode!
      armDeadlock(60, 'DEADEND_PUCK Detected (UUID: 4fafc201-1fb5-459e-8fcc-c5c9c331914b)');
      setAutoDisarmedNotice(null);
    }
  }, [armDeadlock]);

  const toggleMonolithBle = useCallback(() => {
    audio.playClick();
    setIsMonolithBleConnected(prev => {
      const next = !prev;
      if (!next) {
        // BLE disconnected / puck removed - UUID turned off
        setDeadlockState(currentDeadlock => {
          if (currentDeadlock.isActive) {
            audio.playVictory();
            const log: UsageLogEntry = {
              id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
              timestamp: Date.now(),
              appId: 'monolith_ble',
              appName: 'The Monolith Desk Node',
              packageName: 'io.deadend.monolith',
              type: 'deadlock_disarmed',
              declaredIntent: 'DEADEND_PUCK removed (UUID turned off): Lockdown mode automatically disarmed.'
            };
            setDayStats(stats => ({
              ...stats,
              logs: [log, ...stats.logs]
            }));
            setAutoDisarmedNotice('DEADEND_PUCK removed (UUID turned off): Lockdown mode disarmed. Restored DEADEND launcher.');
            return {
              ...currentDeadlock,
              isActive: false,
              endsAt: null
            };
          }
          return currentDeadlock;
        });
      } else {
        // Puck detected / UUID active: directly enter new Deadlock mode!
        armDeadlock(60, 'DEADEND_PUCK Detected (UUID: 4fafc201-1fb5-459e-8fcc-c5c9c331914b)');
        setAutoDisarmedNotice(null);
      }
      return next;
    });
  }, [armDeadlock]);

  // Home Role handshake
  const requestHomeRole = useCallback(() => {
    audio.playClick();
    setSystemHealth(prev => ({
      ...prev,
      isRoleHomeHeld: true,
      roleHomeBannerDismissed: true
    }));
  }, []);

  const dismissHomeBanner = useCallback(() => {
    audio.playClick();
    setSystemHealth(prev => ({ ...prev, roleHomeBannerDismissed: true }));
  }, []);

  const dismissOemGestureWarning = useCallback(() => {
    audio.playClick();
    setSystemHealth(prev => ({ ...prev, oemGestureWarningDismissed: true }));
  }, []);

  // Dynamic Permission Onboarding with Just-In-Time Rationale
  const toggleSystemPermissionWithRationale = useCallback((key: keyof SystemHealthState) => {
    const isCurrentlyGranted = Boolean(systemHealth[key]);
    if (isCurrentlyGranted) {
      // Toggle off directly
      setSystemHealth(prev => ({ ...prev, [key]: false }));
      audio.playClick();
      return;
    }

    // Show educational rationale card prior to granting
    const rationales: Record<string, PermissionRationale> = {
      isRoleHomeHeld: {
        permissionKey: 'isRoleHomeHeld',
        title: 'Home Launcher Role (ROLE_HOME)',
        subtitle: 'Replaces your default home screen',
        rationale: 'DEADEND needs to handle Home intent requests so your device opens directly to the distraction-free text launcher.',
        privacyGuarantee: 'Zero telemetry. Your home screen layout and app shortcuts remain 100% on-device.',
        actionLabel: 'Confirm Role Handshake'
      },
      isAccessibilityGranted: {
        permissionKey: 'isAccessibilityGranted',
        title: 'Accessibility Service Interceptor',
        subtitle: 'Detects opening packages before they display',
        rationale: 'Listens for TYPE_WINDOW_STATE_CHANGED events to enforce the non-skippable breathing countdown when social apps enter the foreground.',
        privacyGuarantee: 'Does not read keystrokes or screen text. Only inspects the foreground package identifier.',
        actionLabel: 'Enable Service'
      },
      isNotificationListenerGranted: {
        permissionKey: 'isNotificationListenerGranted',
        title: 'Notification Listener Service',
        subtitle: 'Intercepts non-essential notifications',
        rationale: 'Suppresses distracting alerts during deep focus and caches them for scheduled morning and evening digests.',
        privacyGuarantee: 'Never leaves device. Emergency calls and alarms always bypass the digest immediately.',
        actionLabel: 'Allow Notification Access'
      },
      isUsageStatsGranted: {
        permissionKey: 'isUsageStatsGranted',
        title: 'Usage Access (PACKAGE_USAGE_STATS)',
        subtitle: 'Tracks on-device minute budgets',
        rationale: 'Calculates daily app time limits and computes your daily willpower and impulse-abort scores.',
        privacyGuarantee: 'No internet permission exists in this launcher. All stats are archived locally.',
        actionLabel: 'Grant Usage Access'
      },
      isBatteryOptimizationIgnored: {
        permissionKey: 'isBatteryOptimizationIgnored',
        title: 'Ignore Battery Optimizations',
        subtitle: 'Prevents OEM background termination',
        rationale: 'Keeps the focus shield active on aggressive OEM task killers (MIUI, HyperOS, ColorOS, One UI).',
        privacyGuarantee: 'Runs at minimal battery consumption with zero background network polling.',
        actionLabel: 'Whitelist in Battery Manager'
      }
    };

    const targetRationale = rationales[key as string];
    if (targetRationale) {
      setPermissionRationaleModal(targetRationale);
    } else {
      setSystemHealth(prev => ({ ...prev, [key]: true }));
    }
  }, [systemHealth]);

  const closeRationaleModal = useCallback(() => {
    setPermissionRationaleModal(null);
  }, []);

  const confirmRationaleAction = useCallback(() => {
    if (!permissionRationaleModal) return;
    const key = permissionRationaleModal.permissionKey;
    setSystemHealth(prev => ({ ...prev, [key]: true }));
    audio.playVictory();
    setPermissionRationaleModal(null);
  }, [permissionRationaleModal]);

  // Notification Digest Actions
  const toggleDigestEnabled = useCallback(() => {
    audio.playClick();
    setDigestConfig(prev => ({ ...prev, enabled: !prev.enabled }));
  }, []);

  const releaseDigestNow = useCallback(() => {
    audio.playVictory();
    setDigestConfig(prev => ({
      ...prev,
      lastDeliveredAt: Date.now(),
      batchedNotifications: []
    }));
  }, []);

  const dismissBatchNotification = useCallback((id: string) => {
    audio.playClick();
    setDigestConfig(prev => ({
      ...prev,
      batchedNotifications: prev.batchedNotifications.filter(n => n.id !== id)
    }));
  }, []);

  const simulateIncomingNotification = useCallback(() => {
    const appsPool = [
      { name: 'Instagram', pkg: 'com.instagram.android', text: 'Sarah sent you a photo' },
      { name: 'YouTube', pkg: 'com.google.android.youtube', text: 'New upload: Deep Work Masterclass' },
      { name: 'Reddit', pkg: 'com.reddit.frontpage', text: 'Popular in r/productivity' },
      { name: 'Chrome', pkg: 'com.android.chrome', text: 'Breaking news alert' }
    ];
    const picked = appsPool[Math.floor(Math.random() * appsPool.length)];
    const newNotif: BatchNotification = {
      id: `notif-${Date.now()}`,
      appName: picked.name,
      packageName: picked.pkg,
      title: `${picked.name} Notification`,
      body: picked.text,
      timestamp: Date.now(),
      isPriority: false,
      category: 'social'
    };

    setDigestConfig(prev => ({
      ...prev,
      batchedNotifications: [newNotif, ...prev.batchedNotifications]
    }));
    audio.playWarning();
  }, []);

  // 15-Minute Anti-Self-Sabotage Delay Controls
  const queueLimitUnlock = useCallback((appId: string, newMinutes: number, actionType: 'increase_budget' | 'remove_friction') => {
    audio.playDeadlockArm();
    const app = apps.find(a => a.id === appId);
    if (!app) return;

    const unlocksAt = Date.now() + 15 * 60 * 1000; // 15-minute cool-down
    const item: PendingLimitUnlock = {
      appId,
      appName: app.name,
      requestedAt: Date.now(),
      unlocksAt,
      newBudgetMinutes: newMinutes,
      actionType
    };

    setPendingLimitUnlocks(prev => [...prev.filter(u => u.appId !== appId), item]);

    const newLog: UsageLogEntry = {
      id: `log-${Date.now()}`,
      timestamp: Date.now(),
      appId,
      appName: app.name,
      packageName: app.packageName,
      type: 'limit_unlock_queued',
      declaredIntent: '15-minute cool-down intentional pause triggered'
    };
    setDayStats(prev => ({ ...prev, logs: [newLog, ...prev.logs] }));
  }, [apps]);

  const cancelLimitUnlock = useCallback((appId: string) => {
    audio.playClick();
    setPendingLimitUnlocks(prev => prev.filter(u => u.appId !== appId));
  }, []);

  const applyLimitUnlock = useCallback((appId: string) => {
    audio.playVictory();
    const unlock = pendingLimitUnlocks.find(u => u.appId === appId);
    if (!unlock) return;

    if (unlock.actionType === 'remove_friction') {
      setApps(prev => prev.map(a => a.id === appId ? { ...a, category: 'utility' } : a));
    } else {
      setApps(prev => prev.map(a => a.id === appId ? { ...a, dailyBudgetMinutes: unlock.newBudgetMinutes } : a));
    }

    setPendingLimitUnlocks(prev => prev.filter(u => u.appId !== appId));
  }, [pendingLimitUnlocks]);

  // Supporter Aesthetics (Monetization: Core features 100% free forever)
  const unlockSupporterTier = useCallback(() => {
    audio.playVictory();
    setSupporterAesthetics(prev => ({ ...prev, isUnlocked: true }));
  }, []);

  const updateSupporterAesthetics = useCallback((settings: Partial<SupporterAesthetics>) => {
    audio.playClick();
    setSupporterAesthetics(prev => ({ ...prev, ...settings }));
  }, []);

  // App management actions
  const togglePinApp = useCallback((appId: string) => {
    audio.playClick();
    setApps(prev => prev.map(a => a.id === appId ? { ...a, isPinned: !a.isPinned } : a));
  }, []);

  const toggleInterceptApp = useCallback((appId: string) => {
    const app = apps.find(a => a.id === appId);
    if (!app) return;

    // If removing friction, enforce 15-minute cool-down delay!
    if (app.category === 'intercepted') {
      queueLimitUnlock(appId, app.dailyBudgetMinutes, 'remove_friction');
      return;
    }

    // Adding friction is immediate
    audio.playClick();
    setApps(prev => prev.map(a => a.id === appId ? { ...a, category: 'intercepted' } : a));
  }, [apps, queueLimitUnlock]);

  const toggleHideApp = useCallback((appId: string) => {
    audio.playClick();
    setApps(prev => prev.map(a => a.id === appId ? { ...a, isHidden: !a.isHidden } : a));
  }, []);

  const updateAppBudget = useCallback((appId: string, minutes: number) => {
    const app = apps.find(a => a.id === appId);
    if (!app) return;

    // If increasing budget (loosening limits), enforce 15-minute cool-down delay!
    if (minutes > app.dailyBudgetMinutes && app.dailyBudgetMinutes > 0) {
      queueLimitUnlock(appId, minutes, 'increase_budget');
      return;
    }

    // Tightening budget is immediate
    audio.playClick();
    setApps(prev => prev.map(a => a.id === appId ? { ...a, dailyBudgetMinutes: minutes } : a));
  }, [apps, queueLimitUnlock]);

  const updateFrictionConfig = useCallback((newConfig: Partial<FrictionConfig>) => {
    audio.playClick();
    setFrictionConfig(prev => ({ ...prev, ...newConfig }));
  }, []);

  // Midnight Reset Simulator
  const simulateMidnightReset = useCallback(() => {
    audio.playClick();
    const today = getTodayKey();
    setDayStats({
      date: today,
      pickupsCount: 0,
      interceptionsAborted: 0,
      interceptionsProceeded: 0,
      totalScreenTimeSeconds: 0,
      distractingTimeSeconds: 0,
      timeSavedSeconds: 0,
      logs: []
    });
    setApps(prev => prev.map(a => ({
      ...a,
      timeUsedTodaySeconds: 0,
      openCountToday: 0,
      hasPersistentFrictionToday: false
    })));
    setDeadlockState(prev => ({ ...prev, isActive: false, endsAt: null }));
    setActiveSession(null);
    setActiveSimulatedApp(null);
  }, []);

  const closeSimulatedApp = useCallback(() => {
    audio.playClick();
    setActiveSimulatedApp(null);
  }, []);

  return (
    <DeadendContext.Provider
      value={{
        apps,
        frictionConfig,
        deadlockState,
        activeSession,
        dayStats,
        viewMode,
        phoneFrameMode,
        theme,
        interceptorTargetApp,
        searchQuery,
        mostRecentApp,
        systemHealth,
        digestConfig,
        pendingLimitUnlocks,
        supporterAesthetics,
        permissionRationaleModal,
        setViewMode,
        setPhoneFrameMode,
        setTheme,
        setSearchQuery,
        handleAppClick,
        cancelInterception,
        abortInterception,
        proceedInterception,
        endActiveSession,
        armDeadlock,
        disarmDeadlock,
        togglePinApp,
        toggleInterceptApp,
        toggleHideApp,
        updateAppBudget,
        updateFrictionConfig,
        simulateMidnightReset,
        recordPickup,
        activeSimulatedApp,
        closeSimulatedApp,
        setSystemHealth,
        requestHomeRole,
        dismissHomeBanner,
        dismissOemGestureWarning,
        toggleSystemPermissionWithRationale,
        closeRationaleModal,
        confirmRationaleAction,
        toggleDigestEnabled,
        releaseDigestNow,
        dismissBatchNotification,
        simulateIncomingNotification,
        queueLimitUnlock,
        cancelLimitUnlock,
        applyLimitUnlock,
        unlockSupporterTier,
        updateSupporterAesthetics,
        isMonolithBleConnected,
        toggleMonolithBle,
        setMonolithBleConnected,
        autoDisarmedNotice,
        clearAutoDisarmedNotice
      }}
    >
      {children}
    </DeadendContext.Provider>
  );
};

export const useDeadend = () => {
  const context = useContext(DeadendContext);
  if (!context) {
    throw new Error('useDeadend must be used within a DeadendProvider');
  }
  return context;
};
