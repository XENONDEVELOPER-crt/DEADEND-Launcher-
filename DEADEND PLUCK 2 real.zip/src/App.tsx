/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { DeadendProvider } from './context/DeadendContext';
import { PhoneContainer } from './components/PhoneContainer';

export default function App() {
  return (
    <DeadendProvider>
      <PhoneContainer />
    </DeadendProvider>
  );
}
